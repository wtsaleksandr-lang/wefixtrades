import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token } = await req.json();

    if (!token) return Response.json({ error: 'Token required' }, { status: 400 });

    const results = await base44.asServiceRole.entities.Calculator.filter({ edit_token: token });
    if (!results.length) return Response.json({ error: 'Invalid token' }, { status: 404 });

    const calc = results[0];
    const { edit_token, ...publicCalc } = calc;
    const isExpired = new Date() > new Date(calc.token_expires_at);

    const leads = await base44.asServiceRole.entities.Lead.filter({ calculator_id: calc.id }, '-created_date', 500);

    return Response.json({ calculator: { ...publicCalc, is_token_expired: isExpired }, leads });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});