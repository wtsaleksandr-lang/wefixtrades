import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { calculator_id } = await req.json();

    if (!calculator_id) return Response.json({ ok: true });

    const calcs = await base44.asServiceRole.entities.Calculator.filter({ id: calculator_id });
    if (!calcs.length) return Response.json({ ok: true });

    const calc = calcs[0];
    await base44.asServiceRole.entities.Calculator.update(calculator_id, {
      total_views: (calc.total_views || 0) + 1,
      last_activity_at: new Date().toISOString()
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});