import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const url = new URL(req.url);
    const toolId = url.searchParams.get('id');

    if (!toolId) {
      return Response.json({ error: 'Missing tool id' }, { status: 400 });
    }

    const tool = await base44.asServiceRole.entities.Calculator.read(toolId);
    if (!tool) {
      return Response.json({ error: 'Tool not found' }, { status: 404 });
    }

    return Response.json({
      id: tool.id,
      business_name: tool.business_name,
      tagline: tool.tagline,
      logo_url: tool.logo_url,
      primary_color: tool.primary_color,
      template: tool.template,
      template_config: tool.template_config,
      cta_button_text: tool.cta_button_text,
      lead_capture_fields: tool.lead_capture_fields,
      lead_required_fields: tool.lead_required_fields,
      lead_thank_you_message: tool.lead_thank_you_message,
      website_url: tool.website_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});