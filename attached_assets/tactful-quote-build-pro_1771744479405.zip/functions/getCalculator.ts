import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { slug, token } = await req.json();

    if (!slug && !token) {
      return Response.json({ error: 'slug or token required' }, { status: 400 });
    }

    if (token) {
      const results = await base44.asServiceRole.entities.Calculator.filter({ edit_token: token });
      if (!results.length) return Response.json({ error: 'Invalid token' }, { status: 404 });
      const calc = results[0];
      const { edit_token, ...calcWithoutToken } = calc;
      const isExpired = new Date() > new Date(calc.token_expires_at);
      return Response.json({ calculator: { ...calcWithoutToken, is_token_expired: isExpired } });
    }

    const results = await base44.asServiceRole.entities.Calculator.filter({ slug });
    if (!results.length) return Response.json({ error: 'Calculator not found' }, { status: 404 });
    const { edit_token, ...publicData } = results[0];
    return Response.json({ calculator: publicData });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});