import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

async function hashIP(ip) {
  const encoder = new TextEncoder();
  const data = encoder.encode(ip + 'qq_salt_2024');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 24);
}

function generateToken() {
  const array = new Uint8Array(24);
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function slugify(text) {
  return (text || 'my-calculator')
    .toLowerCase().replace(/[^a-z0-9\s-]/g, '').trim()
    .replace(/\s+/g, '-').replace(/-+/g, '-').substring(0, 40) || 'my-calculator';
}

function randomSuffix() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from(crypto.getRandomValues(new Uint8Array(5))).map(b => chars[b % chars.length]).join('');
}

async function checkRateLimit(base44, key, max, windowMs) {
  const records = await base44.asServiceRole.entities.RateLimit.filter({ key });
  const now = Date.now();
  if (!records.length) {
    await base44.asServiceRole.entities.RateLimit.create({ key, count: 1, window_start: new Date().toISOString() });
    return true;
  }
  const rec = records[0];
  if (now - new Date(rec.window_start).getTime() > windowMs) {
    await base44.asServiceRole.entities.RateLimit.update(rec.id, { count: 1, window_start: new Date().toISOString() });
    return true;
  }
  if (rec.count >= max) return false;
  await base44.asServiceRole.entities.RateLimit.update(rec.id, { count: rec.count + 1 });
  return true;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const ipHash = await hashIP(ip);

    const allowed = await checkRateLimit(base44, `create:${ipHash}`, 5, 24 * 60 * 60 * 1000);
    if (!allowed) {
      return Response.json({ error: "You've reached the daily limit of 5 calculators. Please try again tomorrow.", code: 'RATE_LIMIT' }, { status: 429 });
    }

    const body = await req.json();
    const { business_name, business_type, tagline, primary_color, logo_url, template, template_config, lead_capture_fields, lead_required_fields, lead_thank_you_message, cta_button_text, custom_slug, owner_email } = body;

    if (!business_name?.trim()) {
      return Response.json({ error: 'Business name is required' }, { status: 400 });
    }

    let baseSlug = custom_slug ? slugify(custom_slug) : slugify(business_name);
    let finalSlug = baseSlug;
    for (let i = 0; i < 10; i++) {
      const existing = await base44.asServiceRole.entities.Calculator.filter({ slug: finalSlug });
      if (!existing.length) break;
      finalSlug = `${baseSlug}-${randomSuffix()}`;
    }

    const editToken = generateToken();
    const tokenExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const trialEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    const calculator = await base44.asServiceRole.entities.Calculator.create({
      slug: finalSlug,
      business_name: business_name.trim(),
      business_type: business_type || 'other',
      tagline: tagline || '',
      primary_color: primary_color || '#6366f1',
      logo_url: logo_url || '',
      template: template || business_type || 'cleaning',
      template_config: template_config || {},
      lead_capture_fields: lead_capture_fields || ['name', 'email'],
      lead_required_fields: lead_required_fields || ['name', 'email'],
      lead_thank_you_message: lead_thank_you_message || "Thanks! We'll be in touch shortly.",
      cta_button_text: cta_button_text || 'Get My Free Quote',
      edit_token: editToken,
      token_expires_at: tokenExpiresAt,
      owner_email: owner_email || '',
      status: 'trial',
      trial_ends_at: trialEndsAt,
      show_powered_by_badge: true,
      total_views: 0,
      total_leads: 0,
      last_activity_at: new Date().toISOString(),
      is_duplicated: false
    });

    if (owner_email?.includes('@')) {
      const origin = req.headers.get('origin') || 'https://your-app.com';
      const calcUrl = `${origin}/Calculator?slug=${finalSlug}`;
      const editUrl = `${origin}/EditCalculator?token=${editToken}`;
      const leadsUrl = `${origin}/Leads?token=${editToken}`;
      const expiry = new Date(tokenExpiresAt).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: owner_email,
        subject: `🎉 Your ${business_name} calculator is live!`,
        body: `Your QuickQuote™ calculator is ready!\n\n🔗 SHARE THIS LINK:\n${calcUrl}\n\n✏️ EDIT YOUR CALCULATOR (expires ${expiry}):\n${editUrl}\n\n📊 VIEW YOUR LEADS:\n${leadsUrl}\n\n⚠️ Save your edit link! After it expires, you can use it once to duplicate your calculator with a fresh 7-day edit period.\n\n— QuickQuote™`
      });
    }

    return Response.json({ success: true, slug: finalSlug, edit_token: editToken, token_expires_at: tokenExpiresAt, calculator_id: calculator.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});