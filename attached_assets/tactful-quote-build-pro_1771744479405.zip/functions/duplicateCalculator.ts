import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function generateToken() {
  const array = new Uint8Array(24);
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function randomSuffix() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from(crypto.getRandomValues(new Uint8Array(5))).map(b => chars[b % chars.length]).join('');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token, owner_email } = await req.json();

    if (!token) return Response.json({ error: 'Token required' }, { status: 400 });

    const results = await base44.asServiceRole.entities.Calculator.filter({ edit_token: token });
    if (!results.length) return Response.json({ error: 'Invalid token' }, { status: 404 });

    const original = results[0];

    if (new Date() <= new Date(original.token_expires_at)) {
      return Response.json({ error: 'Calculator is still active. Use edit instead.' }, { status: 400 });
    }

    if (original.is_duplicated) {
      return Response.json({ error: 'This calculator has already been duplicated. Each expired calculator can only be duplicated once.' }, { status: 400 });
    }

    // Generate unique slug
    let newSlug = `${original.slug}-copy`;
    for (let i = 0; i < 10; i++) {
      const existing = await base44.asServiceRole.entities.Calculator.filter({ slug: newSlug });
      if (!existing.length) break;
      newSlug = `${original.slug}-${randomSuffix()}`;
    }

    const newToken = generateToken();
    const newExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const { id, created_date, updated_date, edit_token, token_expires_at, total_views, total_leads, last_activity_at, slug, is_duplicated, ...baseData } = original;

    const newCalc = await base44.asServiceRole.entities.Calculator.create({
      ...baseData,
      slug: newSlug,
      edit_token: newToken,
      token_expires_at: newExpiry,
      owner_email: owner_email || original.owner_email || '',
      status: 'active',
      total_views: 0,
      total_leads: 0,
      last_activity_at: new Date().toISOString(),
      is_duplicated: false
    });

    // Mark original as duplicated
    await base44.asServiceRole.entities.Calculator.update(original.id, { is_duplicated: true });

    const email = owner_email || original.owner_email;
    if (email?.includes('@')) {
      const origin = req.headers.get('origin') || 'https://your-app.com';
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: `Your "${original.business_name}" calculator has been duplicated ✅`,
        body: `Your calculator was duplicated successfully.\n\nNew Calculator URL: ${origin}/Calculator?slug=${newSlug}\nEdit Link (7 days): ${origin}/EditCalculator?token=${newToken}\nLeads: ${origin}/Leads?token=${newToken}\n\nThe original calculator remains live at its original URL.\n\n— QuickQuote™`
      });
    }

    return Response.json({ success: true, new_slug: newSlug, new_token: newToken, new_expires_at: newExpiry, calculator_id: newCalc.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});