import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

async function hashIP(ip) {
  const encoder = new TextEncoder();
  const data = encoder.encode(ip + 'qq_lead_salt_2024');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 24);
}

async function checkLeadRateLimit(base44, ipHash, calculatorId) {
  const key = `lead:${ipHash}:${calculatorId}`;
  const records = await base44.asServiceRole.entities.RateLimit.filter({ key });
  const now = Date.now();
  const windowMs = 60 * 60 * 1000; // 1 hour
  const max = 5;

  if (!records.length) {
    await base44.asServiceRole.entities.RateLimit.create({ key, count: 1, window_start: new Date().toISOString() });
    return true;
  }
  const rec = records[0];
  if (now - new Date(rec.window_start).getTime() > windowMs) {
    await base44.asServiceRole.entities.RateLimit.update(rec.id, { count: 1, window_start: new Date().toISOString() });
    return true;
  }
  if (rec.count >= max) return false;
  await base44.asServiceRole.entities.RateLimit.update(rec.id, { count: rec.count + 1 });
  return true;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const ipHash = await hashIP(ip);

    const body = await req.json();
    const { calculator_id, calculator_slug, name, email, phone, company, quote_amount, quote_inputs, honeypot } = body;

    if (!calculator_id) return Response.json({ error: 'calculator_id required' }, { status: 400 });

    // Honeypot — silent reject
    if (honeypot && honeypot.length > 0) return Response.json({ success: true });

    const allowed = await checkLeadRateLimit(base44, ipHash, calculator_id);
    if (!allowed) {
      return Response.json({ error: 'Too many submissions. Please try again later.' }, { status: 429 });
    }

    const calcs = await base44.asServiceRole.entities.Calculator.filter({ id: calculator_id });
    if (!calcs.length) return Response.json({ error: 'Calculator not found' }, { status: 404 });
    const calc = calcs[0];

    await base44.asServiceRole.entities.Lead.create({
      calculator_id,
      calculator_slug: calculator_slug || calc.slug,
      name: name || '',
      email: email || '',
      phone: phone || '',
      company: company || '',
      quote_amount: quote_amount || 0,
      quote_inputs: quote_inputs || {},
      ip_hash: ipHash
    });

    await base44.asServiceRole.entities.Calculator.update(calculator_id, {
      total_leads: (calc.total_leads || 0) + 1,
      last_activity_at: new Date().toISOString()
    });

    if (calc.owner_email?.includes('@')) {
      const origin = req.headers.get('origin') || 'https://your-app.com';
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: calc.owner_email,
        subject: `New lead from your ${calc.business_name} calculator!`,
        body: `You have a new quote request!\n\nName: ${name || 'N/A'}\nEmail: ${email || 'N/A'}\nPhone: ${phone || 'N/A'}\nCompany: ${company || 'N/A'}\nEstimated Quote: $${(quote_amount || 0).toLocaleString()}\n\nView all leads: ${origin}/Leads?token=${calc.edit_token}`
      });
    }

    return Response.json({ success: true, thank_you_message: calc.lead_thank_you_message });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});