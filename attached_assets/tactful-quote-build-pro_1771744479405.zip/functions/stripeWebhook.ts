import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
    if (!webhookSecret) {
      return Response.json({ error: 'Webhook secret not configured' }, { status: 500 });
    }

    const signature = req.headers.get('stripe-signature');
    const body = await req.text();

    // For local testing, skip signature validation
    // In production, uncomment the signature validation
    // const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

    // Parse event
    const event = JSON.parse(body);

    const base44 = createClientFromRequest(req);

    // Handle checkout.session.completed
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const toolId = session.metadata?.tool_id;

      if (toolId) {
        const subData = session.subscription;
        const subscriptions = await base44.asServiceRole.entities.Subscription.filter({ calculator_id: toolId });

        if (subscriptions.length > 0) {
          await base44.asServiceRole.entities.Subscription.update(subscriptions[0].id, {
            stripe_customer_id: session.customer,
            stripe_subscription_id: subData,
            status: 'active',
          });
        } else {
          await base44.asServiceRole.entities.Subscription.create({
            calculator_id: toolId,
            stripe_customer_id: session.customer,
            stripe_subscription_id: subData,
            status: 'active',
          });
        }

        // Update tool status
        await base44.asServiceRole.entities.Calculator.update(toolId, { status: 'active' });
      }
    }

    // Handle invoice.payment_failed
    if (event.type === 'invoice.payment_failed') {
      const invoice = event.data.object;
      const customerId = invoice.customer;

      const subscriptions = await base44.asServiceRole.entities.Subscription.filter({ stripe_customer_id: customerId });
      if (subscriptions.length > 0) {
        const sub = subscriptions[0];
        await base44.asServiceRole.entities.Subscription.update(sub.id, { status: 'past_due' });
        await base44.asServiceRole.entities.Calculator.update(sub.calculator_id, { status: 'past_due' });
      }
    }

    // Handle customer.subscription.deleted
    if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object;
      const customerId = subscription.customer;

      const subscriptions = await base44.asServiceRole.entities.Subscription.filter({ stripe_customer_id: customerId });
      if (subscriptions.length > 0) {
        const sub = subscriptions[0];
        await base44.asServiceRole.entities.Subscription.update(sub.id, { status: 'canceled' });
        await base44.asServiceRole.entities.Calculator.update(sub.calculator_id, { status: 'canceled' });
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});