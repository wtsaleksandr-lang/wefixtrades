import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

    const calculators = await base44.asServiceRole.entities.Calculator.filter({ status: 'active' }, '-created_date', 500);

    let archivedCount = 0;
    for (const calc of calculators) {
      const lastActivity = calc.last_activity_at || calc.created_date;
      if (lastActivity < thirtyDaysAgo) {
        await base44.asServiceRole.entities.Calculator.update(calc.id, { status: 'inactive' });
        archivedCount++;
      }
    }

    return Response.json({ success: true, archived: archivedCount, checked: calculators.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});