import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const url = new URL(req.url);
    const toolId = url.searchParams.get('id');

    if (!toolId) {
      return Response.json({ error: 'Missing tool id' }, { status: 400 });
    }

    const tool = await base44.asServiceRole.entities.Calculator.read(toolId);
    if (!tool) {
      return Response.json({ error: 'Tool not found' }, { status: 404 });
    }

    const now = new Date();
    const trialEndsAt = tool.trial_ends_at ? new Date(tool.trial_ends_at) : null;
    const trialDaysLeft = trialEndsAt ? Math.ceil((trialEndsAt - now) / (1000 * 60 * 60 * 24)) : 0;

    // Determine if submission is allowed
    let canSubmit = false;
    let bannerMessage = null;

    if (tool.status === 'trial') {
      if (trialDaysLeft > 0) {
        canSubmit = true;
      } else {
        // Trial ended
        canSubmit = false;
        bannerMessage = 'Trial ended — activate to keep receiving leads.';
      }
    } else if (tool.status === 'active') {
      canSubmit = true;
    } else {
      canSubmit = false;
      bannerMessage = 'Your subscription is inactive. Please reactivate to continue.';
    }

    return Response.json({
      status: tool.status,
      trial_days_left: Math.max(0, trialDaysLeft),
      can_submit: canSubmit,
      banner_message: bannerMessage,
      business_name: tool.business_name,
      logo_url: tool.logo_url,
      primary_color: tool.primary_color,
      tagline: tool.tagline,
      website_url: tool.website_url,
      show_powered_by_badge: tool.show_powered_by_badge,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});