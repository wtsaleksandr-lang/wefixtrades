import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token, updates } = await req.json();

    if (!token) return Response.json({ error: 'Token required' }, { status: 400 });

    const results = await base44.asServiceRole.entities.Calculator.filter({ edit_token: token });
    if (!results.length) return Response.json({ error: 'Invalid token' }, { status: 404 });

    const calc = results[0];
    if (new Date() > new Date(calc.token_expires_at)) {
      return Response.json({ error: 'Edit token has expired.', expired: true }, { status: 403 });
    }

    // Strip protected fields
    const { edit_token, slug, id, created_date, updated_date, is_duplicated, total_views, total_leads, ...safeUpdates } = updates || {};
    await base44.asServiceRole.entities.Calculator.update(calc.id, safeUpdates);

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});