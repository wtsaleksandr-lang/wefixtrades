import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const url = new URL(req.url);
    const toolId = url.searchParams.get('tool_id');
    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');

    if (!toolId) {
      return Response.json({ error: 'Missing tool_id' }, { status: 400 });
    }

    if (!stripeKey) {
      return Response.json({ error: 'Stripe not configured' }, { status: 500 });
    }

    // Fetch tool
    const tool = await base44.asServiceRole.entities.Calculator.read(toolId);
    if (!tool) {
      return Response.json({ error: 'Tool not found' }, { status: 404 });
    }

    // Check/create Stripe customer
    let subscription = null;
    const subs = await base44.asServiceRole.entities.Subscription.filter({ calculator_id: toolId });
    if (subs.length > 0) {
      subscription = subs[0];
    }

    let customerId = subscription?.stripe_customer_id;

    // Create or retrieve Stripe customer
    if (!customerId) {
      const customerResp = await fetch('https://api.stripe.com/v1/customers', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${stripeKey}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          email: tool.owner_email || `calc-${toolId}@quickquote.tools`,
          description: `QuickQuote - ${tool.business_name}`,
          metadata: JSON.stringify({ tool_id: toolId }),
        }),
      });

      if (!customerResp.ok) {
        throw new Error(`Stripe customer creation failed: ${customerResp.statusText}`);
      }

      const customer = await customerResp.json();
      customerId = customer.id;

      // Store subscription record
      if (subscription) {
        await base44.asServiceRole.entities.Subscription.update(subscription.id, { stripe_customer_id: customerId });
      } else {
        await base44.asServiceRole.entities.Subscription.create({
          calculator_id: toolId,
          stripe_customer_id: customerId,
        });
      }
    }

    // Create Checkout session
    const origin = req.headers.get('origin') || 'https://quickquote.tools';
    const sessionResp = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${stripeKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        customer: customerId,
        mode: 'subscription',
        line_items: JSON.stringify([{
          price: 'price_1QsgkzLDZLWj0eJLBz9cAW9D', // Replace with actual price ID
          quantity: 1,
        }]),
        success_url: `${origin}/success?tool_id=${toolId}`,
        cancel_url: `${origin}/EditCalculator?token=${tool.edit_token}`,
        subscription_data: JSON.stringify({
          metadata: { tool_id: toolId },
        }),
      }),
    });

    if (!sessionResp.ok) {
      throw new Error(`Stripe session creation failed: ${sessionResp.statusText}`);
    }

    const session = await sessionResp.json();
    return Response.json({ checkout_url: session.url });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});