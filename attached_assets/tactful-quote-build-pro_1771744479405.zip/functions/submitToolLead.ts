import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const { tool_id, lead_data } = await req.json();

    if (!tool_id) {
      return Response.json({ error: 'Missing tool_id' }, { status: 400 });
    }

    // Check tool status
    const tool = await base44.asServiceRole.entities.Calculator.read(tool_id);
    if (!tool) {
      return Response.json({ error: 'Tool not found' }, { status: 404 });
    }

    // Enforce submission gating on backend
    const now = new Date();
    const trialEndsAt = tool.trial_ends_at ? new Date(tool.trial_ends_at) : null;
    let canSubmit = false;

    if (tool.status === 'trial') {
      canSubmit = trialEndsAt && trialEndsAt > now;
    } else if (tool.status === 'active') {
      canSubmit = true;
    }

    if (!canSubmit) {
      return Response.json({ 
        error: 'Trial ended or subscription inactive',
        message: 'This calculator is no longer accepting leads. Please activate to continue.'
      }, { status: 403 });
    }

    // Create lead
    const lead = await base44.asServiceRole.entities.Lead.create({
      calculator_id: tool_id,
      calculator_slug: tool.slug,
      name: lead_data.name || '',
      email: lead_data.email || '',
      phone: lead_data.phone || '',
      company: lead_data.company || '',
      quote_amount: lead_data.quote_amount || 0,
      quote_inputs: lead_data.quote_inputs || {},
    });

    // Update calculator stats
    await base44.asServiceRole.entities.Calculator.update(tool_id, {
      total_leads: (tool.total_leads || 0) + 1,
      last_activity_at: new Date().toISOString(),
    });

    // Send notification email (fire and forget)
    if (tool.owner_email) {
      base44.integrations.Core.SendEmail({
        to: tool.owner_email,
        subject: `New Lead: ${lead_data.name || 'Anonymous'}`,
        body: `New lead for ${tool.business_name}:\n\nName: ${lead_data.name}\nEmail: ${lead_data.email}\nPhone: ${lead_data.phone}\nQuote: $${lead_data.quote_amount}`,
      }).catch(() => {});
    }

    return Response.json({ success: true, lead_id: lead.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});