import React from 'react';
import { motion } from 'framer-motion';
import { designTokens } from '@/components/designTokens';

/**
 * PremiumButton — Premium CTA component with gradient, layered shadows, and highlight overlay.
 * 
 * Props:
 *   children — button text/content
 *   onClick — click handler
 *   disabled — disabled state
 *   icon — optional icon element (right-aligned)
 *   loading — show spinner instead of text
 *   className — additional classes
 *   ...rest — standard button attributes
 */
export default function PremiumButton({
  children,
  onClick,
  disabled = false,
  icon = null,
  loading = false,
  className = '',
  ...rest
}) {
  const prefersReducedMotion = typeof window !== 'undefined' && 
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  return (
    <motion.button
      type="button"
      onClick={onClick}
      disabled={disabled || loading}
      className={`relative flex items-center justify-center gap-2.5 text-white font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed ${className}`}
      style={{
        height: '40px',
        borderRadius: designTokens.radius.md,
        background: 'linear-gradient(180deg, #3B82F6 0%, #2563EB 100%)',
        border: '1px solid rgba(255,255,255,0.22)',
        boxShadow: '0 15px 40px rgba(37,99,235,0.35), 0 5px 15px rgba(37,99,235,0.25)',
        fontSize: '14px',
        fontWeight: 600,
        paddingLeft: '18px',
        paddingRight: '18px',
        overflow: 'hidden',
      }}
      whileHover={prefersReducedMotion ? {} : {
        y: -3,
        boxShadow: '0 25px 60px rgba(37,99,235,0.45), inset 0 1px 0 rgba(255,255,255,0.24)',
      }}
      whileTap={prefersReducedMotion ? {} : {
        scale: 0.985,
        y: 0,
        boxShadow: `0 8px 20px rgba(30,64,175,0.50), inset 0 1px 0 rgba(255,255,255,0.18)`,
      }}
      transition={designTokens.transitions.normal}
      {...rest}
    >
      {/* Specular highlight overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 35%)',
          borderRadius: designTokens.radius.md,
        }}
      />

      {/* Content */}
      <span className="relative flex items-center justify-center gap-2.5 z-10">
        {loading ? (
          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
        ) : (
          <>
            {children}
            {icon && React.cloneElement(icon, {
              className: 'w-4 h-4',
              style: { width: '16px', height: '16px' },
            })}
          </>
        )}
      </span>
    </motion.button>
  );
}