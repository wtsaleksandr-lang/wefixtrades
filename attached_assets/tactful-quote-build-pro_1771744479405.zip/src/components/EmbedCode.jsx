import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { designTokens } from './designTokens';

export default function EmbedCode({ slug, hosted_url }) {
  const t = designTokens;
  const [copied, setCopied] = useState(false);

  const embedCode = `<div id="qqCalc_${slug}"></div>
<script src="${process.env.VITE_EMBED_URL || 'https://quickquote.tools/embed.js'}" data-tool="${slug}"></script>`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: t.spacing.md }}>
      <div
        style={{
          padding: t.spacing.md,
          backgroundColor: t.colors.backgroundLight,
          borderRadius: t.radius.md,
          fontFamily: 'monospace',
          fontSize: '12px',
          border: `1px solid ${t.colors.border}`,
          overflow: 'auto',
          maxHeight: '200px',
        }}
      >
        {embedCode}
      </div>
      <button
        onClick={copyToClipboard}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: t.spacing.sm,
          padding: `${t.spacing.sm} ${t.spacing.md}`,
          backgroundColor: t.colors.primary,
          color: 'white',
          border: 'none',
          borderRadius: t.radius.md,
          cursor: 'pointer',
          fontWeight: 600,
          fontSize: '14px',
        }}
      >
        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        {copied ? 'Copied!' : 'Copy Embed Code'}
      </button>
      {hosted_url && (
        <p style={{ ...t.typography.bodySm, color: t.colors.textMuted }}>
          Or use the hosted link: <code style={{ backgroundColor: t.colors.backgroundLight, padding: '2px 6px', borderRadius: '4px' }}>{hosted_url}</code>
        </p>
      )}
    </div>
  );
}