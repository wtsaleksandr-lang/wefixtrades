/**
 * Theme Utility Functions
 * Handles merging global default tokens with per-calculator overrides
 */

import { designTokens } from './designTokens';

/**
 * getEffectiveTheme
 * Merges global default tokens with calculator-specific overrides.
 * WIZARD UI always uses global designTokens.
 * CUSTOMER-FACING layers (CalculatorWidget, QuoteResult, LeadForm) use effectiveTheme.
 *
 * @param {Object} overrides - Calculator themeOverrides: { accent, font, buttonStyle, surfaceVariant, radius, logoUrl }
 * @returns {Object} Merged theme object
 */
export function getEffectiveTheme(overrides) {
  if (!overrides || Object.keys(overrides).length === 0) {
    return designTokens;
  }

  const effectiveTheme = { ...designTokens };

  // Accent color (primary)
  if (overrides.accent) {
    effectiveTheme.colors = {
      ...effectiveTheme.colors,
      primary: overrides.accent,
      primaryLight: `rgba(${hexToRgb(overrides.accent)},0.08)`,
      primaryLighter: `rgba(${hexToRgb(overrides.accent)},0.03)`,
      primaryShadow: `rgba(${hexToRgb(overrides.accent)},0.25)`,
      primaryHover: `rgba(${hexToRgb(overrides.accent)},0.1)`,
    };
    
    // Update shadows to use new accent
    effectiveTheme.shadows = {
      ...effectiveTheme.shadows,
      md: `0 8px 20px rgba(${hexToRgb(overrides.accent)},0.12)`,
      hover: `0 12px 35px rgba(${hexToRgb(overrides.accent)},0.3)`,
      focus: `0 10px 30px rgba(${hexToRgb(overrides.accent)},0.25)`,
      button: `0 6px 20px rgba(${hexToRgb(overrides.accent)},0.25)`,
    };
  }

  // Font
  if (overrides.font) {
    effectiveTheme.typography = {
      ...effectiveTheme.typography,
      fontFamily: overrides.font,
    };
  }

  // Button style
  effectiveTheme.buttonStyle = overrides.buttonStyle || 'rounded';

  // Surface style (solid, glass, elevated)
  effectiveTheme.surfaceVariant = overrides.surfaceVariant || 'solid';

  // Border radius
  if (overrides.radius) {
    const radiusMap = { sm: '8px', md: '12px', lg: '16px' };
    const radiusPx = radiusMap[overrides.radius] || radiusMap.md;
    effectiveTheme.radius = {
      sm: radiusPx,
      md: radiusPx,
      lg: radiusPx,
      xl: radiusPx,
    };
  }

  // Logo URL stored for components
  effectiveTheme.logoUrl = overrides.logoUrl || '';

  return effectiveTheme;
}

/**
 * Helper: Convert hex color to RGB string
 * Used for constructing rgba values with custom colors
 */
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return '13,148,136'; // fallback to teal
  const r = parseInt(result[1], 16);
  const g = parseInt(result[2], 16);
  const b = parseInt(result[3], 16);
  return `${r},${g},${b}`;
}