import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../designTokens';

const FIELD_LABELS = { name: 'Full Name', email: 'Email Address', phone: 'Phone Number', company: 'Company Name' };
const FIELD_TYPES = { email: 'email', phone: 'tel' };

export default function LeadForm({ calculator, quoteAmount, quoteInputs, effectiveTheme = designTokens, onSuccess }) {
  const t = effectiveTheme;
  const {
    id: calculator_id, slug: calculator_slug,
    lead_capture_fields = ['name', 'email'],
    lead_required_fields = ['name', 'email'],
  } = calculator;

  const [formData, setFormData] = useState({ name: '', email: '', phone: '', company: '' });
  const [honeypot, setHoneypot] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    for (const field of lead_required_fields) {
      if (!formData[field]?.trim()) {
        setError(`${FIELD_LABELS[field]} is required.`);
        return;
      }
    }

    setIsSubmitting(true);
    const res = await base44.functions.invoke('submitLead', {
      calculator_id, calculator_slug, ...formData,
      quote_amount: quoteAmount, quote_inputs: quoteInputs, honeypot
    });

    if (res.data?.success) {
      onSuccess();
    } else {
      setError(res.data?.error || 'Something went wrong. Please try again.');
    }
    setIsSubmitting(false);
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={getTransition('slow')}
      className="rounded-xl border p-6"
      style={{
        background: designTokens.colors.background,
        borderColor: designTokens.cardBorder,
        boxShadow: designTokens.shadows.card,
        display: 'flex',
        flexDirection: 'column',
        gap: t.spacing.md,
      }}
    >
      <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily }}>Get Your Custom Quote</h3>

      {/* Honeypot — hidden from real users */}
      <input type="text" name="website_url" value={honeypot} onChange={e => setHoneypot(e.target.value)}
        style={{ display: 'none' }} tabIndex={-1} autoComplete="off" />

      {lead_capture_fields.map((field, idx) => (
        <motion.div
          key={field}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={getTransition('normal', false)}
        >
          <Label style={{ ...t.typography.labelSm, color: t.colors.textSecondary, fontFamily: t.typography.fontFamily }}>
            {FIELD_LABELS[field]}
            {lead_required_fields.includes(field) && <span style={{ color: t.colors.danger, marginLeft: '4px' }}>*</span>}
          </Label>
          <Input
            className="mt-1.5 rounded-lg"
            style={{ ...t.typography.body, boxShadow: designTokens.shadows.input }}
            type={FIELD_TYPES[field] || 'text'}
            value={formData[field]}
            onChange={e => setFormData(prev => ({ ...prev, [field]: e.target.value }))}
            placeholder={`Your ${FIELD_LABELS[field].toLowerCase()}`}
          />
        </motion.div>
      ))}

      {error && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={getTransition('fast', false)}
          style={{ ...t.typography.bodySm, color: t.colors.danger, fontFamily: t.typography.fontFamily }}
        >
          {error}
        </motion.p>
      )}

      <motion.button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 rounded-lg text-white font-semibold flex items-center justify-center gap-2"
        style={{
          backgroundColor: t.colors.primary,
          boxShadow: designTokens.shadows.button,
          borderRadius: t.radius.md,
          ...t.typography.button,
          border: 'none',
          cursor: 'pointer',
          transition: 'all 150ms ease-out',
        }}
        whileHover={{ y: -2, boxShadow: designTokens.shadows.button }}
        whileTap={{ scale: 0.98 }}
        transition={getTransition('fast')}
      >
        {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
        {isSubmitting ? 'Submitting...' : 'Send My Quote Request →'}
      </motion.button>
    </motion.form>
  );
}