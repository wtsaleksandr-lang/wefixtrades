import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../../designTokens';

const t = designTokens;

const YARD_SIZES = [
  { id: 'small', label: 'Small', sublabel: '< ¼ acre', priceKey: 'small_price', default: 35 },
  { id: 'medium', label: 'Medium', sublabel: '¼–½ acre', priceKey: 'medium_price', default: 55 },
  { id: 'large', label: 'Large', sublabel: '½–1 acre', priceKey: 'large_price', default: 80 },
  { id: 'xlarge', label: 'X-Large', sublabel: '1+ acre', priceKey: 'xlarge_price', default: 120 },
];
const SERVICES = [
  { id: 'edging', label: 'Edging', priceKey: 'edging_fee', default: 20 },
  { id: 'fertilizing', label: 'Fertilizing', priceKey: 'fertilizing_fee', default: 40 },
  { id: 'weed_control', label: 'Weed Control', priceKey: 'weed_control_fee', default: 30 },
  { id: 'leaf_removal', label: 'Leaf Removal', priceKey: 'leaf_removal_fee', default: 50 },
];
const FREQUENCIES = [
  { id: 'onetime', label: 'One-time' },
  { id: 'biweekly', label: 'Bi-weekly', discountKey: 'biweekly_discount', default: 10 },
  { id: 'weekly', label: 'Weekly', discountKey: 'weekly_discount', default: 15 },
];

export default function LawnCareCalc({ config = {}, effectiveTheme = t, onQuoteUpdate }) {
  const [yardSize, setYardSize] = useState('medium');
  const [services, setServices] = useState([]);
  const [frequency, setFrequency] = useState('onetime');

  useEffect(() => {
    const sizeEntry = YARD_SIZES.find(s => s.id === yardSize);
    let total = config[sizeEntry.priceKey] ?? sizeEntry.default;
    services.forEach(id => {
      const s = SERVICES.find(x => x.id === id);
      total += config[s.priceKey] ?? s.default;
    });
    const freqEntry = FREQUENCIES.find(f => f.id === frequency);
    const discount = freqEntry.discountKey ? (config[freqEntry.discountKey] ?? freqEntry.default) / 100 : 0;
    onQuoteUpdate(Math.round(total * (1 - discount)), { yardSize, services, frequency });
  }, [yardSize, services, frequency]); // eslint-disable-line

  const sel = (active) => active
    ? { borderColor: t.colors.primary, backgroundColor: t.colors.primaryLight, borderWidth: '2px' }
    : { borderColor: t.colors.borderLight, borderWidth: '1px' };
  const toggleService = (id) => setServices(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: t.spacing.lg }}>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Yard Size</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))', gap: t.spacing.md }}>
          {YARD_SIZES.map(size => {
            const isSelected = yardSize === size.id;
            return (
              <motion.button
                key={size.id}
                onClick={() => setYardSize(size.id)}
                style={{
                  ...sel(isSelected),
                  background: isSelected ? t.colors.primaryLight : t.colors.surface,
                  color: isSelected ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isSelected ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{size.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>{size.sublabel}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Add-on Services</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: t.spacing.md }}>
          {SERVICES.map(svc => {
            const price = config[svc.priceKey] ?? svc.default;
            const isActive = services.includes(svc.id);
            return (
              <motion.button
                key={svc.id}
                onClick={() => toggleService(svc.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{svc.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>+${price}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Frequency</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))', gap: t.spacing.md }}>
          {FREQUENCIES.map(freq => {
            const discount = freq.discountKey ? (config[freq.discountKey] ?? freq.default) : 0;
            const isActive = frequency === freq.id;
            return (
              <motion.button
                key={freq.id}
                onClick={() => setFrequency(freq.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                  fontSize: t.typography.button.fontSize,
                  fontWeight: 600,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div>{freq.label}</div>
                {discount > 0 && <div style={{ ...t.typography.small, color: t.colors.success, marginTop: t.spacing.xs }}>Save {discount}%</div>}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}