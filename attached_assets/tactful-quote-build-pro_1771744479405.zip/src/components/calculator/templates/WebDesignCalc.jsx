import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../../designTokens';

const t = designTokens;

const FEATURES = [
  { id: 'blog', label: 'Blog / News', priceKey: 'blog_fee', default: 200 },
  { id: 'ecommerce', label: 'E-Commerce Store', priceKey: 'ecommerce_fee', default: 500 },
  { id: 'seo', label: 'SEO Package', priceKey: 'seo_fee', default: 300 },
  { id: 'cms', label: 'CMS Setup', priceKey: 'cms_fee', default: 400 },
  { id: 'mobile', label: 'Mobile Optimization', priceKey: 'mobile_fee', default: 200 },
];
const TIMELINES = [
  { id: 'flexible', label: 'Flexible', sublabel: '> 6 weeks', type: 'discount', key: 'flexible_discount', default: 10 },
  { id: 'standard', label: 'Standard', sublabel: '3–6 weeks' },
  { id: 'rush', label: 'Rush', sublabel: '< 3 weeks', type: 'multiplier', key: 'rush_multiplier', default: 1.5 },
];

export default function WebDesignCalc({ config = {}, effectiveTheme = designTokens, onQuoteUpdate }) {
  const t = effectiveTheme;
  const [pages, setPages] = useState(5);
  const [features, setFeatures] = useState([]);
  const [timeline, setTimeline] = useState('standard');

  useEffect(() => {
    const basePrice = config.base_price ?? 800;
    const perPage = config.per_page_price ?? 80;
    let total = basePrice + Math.max(0, pages - 5) * perPage;
    features.forEach(id => {
      const feat = FEATURES.find(f => f.id === id);
      total += config[feat.priceKey] ?? feat.default;
    });
    if (timeline === 'rush') {
      total = Math.round(total * (config.rush_multiplier ?? 1.5));
    } else if (timeline === 'flexible') {
      total = Math.round(total * (1 - (config.flexible_discount ?? 10) / 100));
    }
    onQuoteUpdate(Math.round(total), { pages, features, timeline });
  }, [pages, features, timeline]); // eslint-disable-line

  const sel = (active) => active
    ? { borderColor: t.colors.primary, backgroundColor: t.colors.primaryLight, borderWidth: '2px' }
    : { borderColor: t.colors.borderLight, borderWidth: '1px' };
  const toggleFeature = (id) => setFeatures(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: t.spacing.lg }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: t.spacing.md }}>
          <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily }}>Number of Pages</h3>
          <span style={{ ...t.typography.h3, color: t.colors.primary, fontFamily: t.typography.fontFamily }}>{pages}</span>
        </div>
        <input type="range" min={1} max={20} value={pages} onChange={e => setPages(Number(e.target.value))}
          className="w-full h-2 rounded-lg appearance-none cursor-pointer" style={{ accentColor: t.colors.primary }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: t.typography.small.fontSize, color: t.colors.textMuted, marginTop: t.spacing.sm }}>
          <span>1 page</span><span>20 pages</span>
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Features & Add-ons</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: t.spacing.md }}>
          {FEATURES.map(feat => {
            const price = config[feat.priceKey] ?? feat.default;
            const isActive = features.includes(feat.id);
            return (
              <motion.button
                key={feat.id}
                onClick={() => toggleFeature(feat.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{feat.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>+${price.toLocaleString()}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Timeline</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: t.spacing.md }}>
          {TIMELINES.map(timeline => {
            const isActive = timeline.id === this.timeline;
            return (
              <motion.button
                key={timeline.id}
                onClick={() => setTimeline(timeline.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{timeline.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>{timeline.sublabel}</div>
                {timeline.id === 'rush' && <div style={{ ...t.typography.small, color: t.colors.warning, marginTop: t.spacing.xs }}>+{Math.round(((config.rush_multiplier ?? 1.5) - 1) * 100)}%</div>}
                {timeline.id === 'flexible' && <div style={{ ...t.typography.small, color: t.colors.success, marginTop: t.spacing.xs }}>Save {config.flexible_discount ?? 10}%</div>}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}