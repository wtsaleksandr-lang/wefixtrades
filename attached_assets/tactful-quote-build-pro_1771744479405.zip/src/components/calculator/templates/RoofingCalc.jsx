import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../../designTokens';

const t = designTokens;

const MATERIALS = [
  { id: 'asphalt', label: 'Asphalt Shingles', sublabel: 'Most popular', priceKey: 'asphalt_per_sqft', default: 3.5 },
  { id: 'metal', label: 'Metal Roofing', sublabel: 'Long-lasting', priceKey: 'metal_per_sqft', default: 7.0 },
  { id: 'tile', label: 'Clay / Tile', sublabel: 'Premium look', priceKey: 'tile_per_sqft', default: 9.0 },
  { id: 'flat', label: 'Flat / TPO', sublabel: 'For flat roofs', priceKey: 'flat_per_sqft', default: 5.5 },
];
const ADDONS = [
  { id: 'tearoff', label: 'Tear-off Old Roof', priceKey: 'tearoff_per_sqft', perSqft: true, default: 1.0 },
  { id: 'gutters', label: 'Gutters Replacement', priceKey: 'gutters_fee', default: 500 },
  { id: 'skylight', label: 'Skylight Installation', priceKey: 'skylight_fee', default: 800 },
  { id: 'ventilation', label: 'Improved Ventilation', priceKey: 'ventilation_fee', default: 300 },
];

export default function RoofingCalc({ config = {}, effectiveTheme = designTokens, onQuoteUpdate }) {
  const t = effectiveTheme;
  const [sqft, setSqft] = useState(1500);
  const [material, setMaterial] = useState('asphalt');
  const [addons, setAddons] = useState([]);

  useEffect(() => {
    const mat = MATERIALS.find(m => m.id === material);
    let total = sqft * (config[mat.priceKey] ?? mat.default);
    addons.forEach(id => {
      const addon = ADDONS.find(a => a.id === id);
      total += addon.perSqft ? sqft * (config[addon.priceKey] ?? addon.default) : (config[addon.priceKey] ?? addon.default);
    });
    onQuoteUpdate(Math.round(total), { sqft, material, addons });
  }, [sqft, material, addons]); // eslint-disable-line

  const sel = (active) => active
    ? { borderColor: t.colors.blue, backgroundColor: t.colors.blueTint, borderWidth: '2px' }
    : { borderColor: t.colors.border, borderWidth: '1px' };
  const toggleAddon = (id) => setAddons(prev => prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: t.spacing.lg }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: t.spacing.md }}>
          <h3 style={{ fontSize: '18px', fontWeight: 600, color: t.colors.heading }}>Roof Area</h3>
          <span style={{ fontSize: '32px', fontWeight: 700, color: t.colors.blue }}>{sqft.toLocaleString()} sqft</span>
        </div>
        <input type="range" min={500} max={5000} step={100} value={sqft} onChange={e => setSqft(Number(e.target.value))}
          className="w-full h-2 rounded-lg appearance-none cursor-pointer" style={{ accentColor: t.colors.blue }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: t.colors.muted, marginTop: t.spacing.sm }}>
          <span>500 sqft</span><span>5,000+ sqft</span>
        </div>
      </div>
      <div>
        <h3 style={{ fontSize: '18px', fontWeight: 600, color: t.colors.heading, marginBottom: t.spacing.md }}>Roofing Material</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: t.spacing.md }}>
          {MATERIALS.map(mat => {
            const price = config[mat.priceKey] ?? mat.default;
            const isActive = material === mat.id;
            return (
              <motion.button
                key={mat.id}
                onClick={() => setMaterial(mat.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: '14px' }}>{mat.label}</div>
                <div style={{ fontSize: '12px', color: t.colors.muted, marginTop: t.spacing.xs }}>{mat.sublabel}</div>
                <div style={{ fontSize: '12px', color: t.colors.muted, marginTop: t.spacing.xs }}>${price}/sqft</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ fontSize: '18px', fontWeight: 600, color: t.colors.heading, marginBottom: t.spacing.md }}>Add-ons</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: t.spacing.md }}>
          {ADDONS.map(addon => {
            const price = config[addon.priceKey] ?? addon.default;
            const isActive = addons.includes(addon.id);
            return (
              <motion.button
                key={addon.id}
                onClick={() => toggleAddon(addon.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: '14px' }}>{addon.label}</div>
                <div style={{ fontSize: '12px', color: t.colors.muted, marginTop: t.spacing.xs }}>{addon.perSqft ? `$${price}/sqft` : `+$${price.toLocaleString()}`}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}