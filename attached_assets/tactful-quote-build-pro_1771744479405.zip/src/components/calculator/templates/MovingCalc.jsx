import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../../designTokens';

const t = designTokens;

const HOME_SIZES = [
  { id: 'studio', label: 'Studio', priceKey: 'studio_base', default: 200 },
  { id: 'one_bed', label: '1 Bedroom', priceKey: 'one_bed_base', default: 350 },
  { id: 'two_bed', label: '2 Bedrooms', priceKey: 'two_bed_base', default: 500 },
  { id: 'three_bed', label: '3 Bedrooms', priceKey: 'three_bed_base', default: 650 },
  { id: 'four_plus', label: '4+ Bedrooms', priceKey: 'four_plus_base', default: 900 },
];
const DISTANCES = [
  { id: 'local', label: 'Local', sublabel: '< 30 miles', multiplier: 1 },
  { id: 'medium', label: 'Medium', sublabel: '30–100 miles', multiplierKey: 'medium_distance_multiplier', default: 1.5 },
  { id: 'long', label: 'Long Distance', sublabel: '100+ miles', multiplierKey: 'long_distance_multiplier', default: 2.5 },
];
const ADDONS = [
  { id: 'packing', label: 'Packing Service', priceKey: 'packing_fee', default: 200 },
  { id: 'piano', label: 'Piano Moving', priceKey: 'piano_fee', default: 300 },
  { id: 'storage', label: 'Storage (1 week)', priceKey: 'storage_fee', default: 150 },
  { id: 'assembly', label: 'Assembly / Disassembly', priceKey: 'assembly_fee', default: 100 },
];

export default function MovingCalc({ config = {}, effectiveTheme = designTokens, onQuoteUpdate }) {
  const t = effectiveTheme;
  const [homeSize, setHomeSize] = useState('two_bed');
  const [distance, setDistance] = useState('local');
  const [addons, setAddons] = useState([]);

  useEffect(() => {
    const sizeEntry = HOME_SIZES.find(s => s.id === homeSize);
    let total = config[sizeEntry.priceKey] ?? sizeEntry.default;
    const distEntry = DISTANCES.find(d => d.id === distance);
    const multiplier = distEntry.multiplierKey ? (config[distEntry.multiplierKey] ?? distEntry.default) : 1;
    total *= multiplier;
    addons.forEach(id => {
      const addon = ADDONS.find(a => a.id === id);
      total += config[addon.priceKey] ?? addon.default;
    });
    onQuoteUpdate(Math.round(total), { homeSize, distance, addons });
  }, [homeSize, distance, addons]); // eslint-disable-line

  const sel = (active) => active
    ? { borderColor: t.colors.primary, backgroundColor: t.colors.primaryLight, borderWidth: '2px' }
    : { borderColor: t.colors.borderLight, borderWidth: '1px' };
  const toggleAddon = (id) => setAddons(prev => prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: t.spacing.lg }}>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Home Size</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))', gap: t.spacing.md }}>
          {HOME_SIZES.map(size => {
            const isSelected = homeSize === size.id;
            return (
              <motion.button
                key={size.id}
                onClick={() => setHomeSize(size.id)}
                style={{
                  ...sel(isSelected),
                  background: isSelected ? t.colors.primaryLight : t.colors.surface,
                  color: isSelected ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                  fontSize: t.typography.button.fontSize,
                  fontWeight: 600,
                }}
                animate={{ scale: isSelected ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                {size.label}
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Moving Distance</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: t.spacing.md }}>
          {DISTANCES.map(dist => {
            const isActive = distance === dist.id;
            return (
              <motion.button
                key={dist.id}
                onClick={() => setDistance(dist.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{dist.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>{dist.sublabel}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...t.typography.h4, color: t.colors.textPrimary, fontFamily: t.typography.fontFamily, marginBottom: t.spacing.md }}>Add-ons</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: t.spacing.md }}>
          {ADDONS.map(addon => {
            const price = config[addon.priceKey] ?? addon.default;
            const isActive = addons.includes(addon.id);
            return (
              <motion.button
                key={addon.id}
                onClick={() => toggleAddon(addon.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? t.colors.primaryLight : t.colors.surface,
                  color: isActive ? t.colors.primary : t.colors.textSecondary,
                  padding: `${t.spacing.md} ${t.spacing.sm}`,
                  borderRadius: t.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: t.typography.fontFamily,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: t.typography.button.fontSize }}>{addon.label}</div>
                <div style={{ ...t.typography.small, color: t.colors.textMuted, marginTop: t.spacing.xs }}>+${price.toLocaleString()}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}