import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../../designTokens';

const t = designTokens;

const HOME_SIZES = [
  { id: 'studio', label: 'Studio', priceKey: 'studio_price', default: 80 },
  { id: 'one_bed', label: '1 Bedroom', priceKey: 'one_bed_price', default: 100 },
  { id: 'two_bed', label: '2 Bedrooms', priceKey: 'two_bed_price', default: 130 },
  { id: 'three_bed', label: '3 Bedrooms', priceKey: 'three_bed_price', default: 160 },
  { id: 'four_plus', label: '4+ Bedrooms', priceKey: 'four_plus_price', default: 200 },
];
const EXTRAS = [
  { id: 'deep_clean', label: 'Deep Clean', priceKey: 'deep_clean_fee', default: 50 },
  { id: 'windows', label: 'Windows', priceKey: 'windows_fee', default: 30 },
  { id: 'oven', label: 'Oven Cleaning', priceKey: 'oven_fee', default: 25 },
  { id: 'fridge', label: 'Refrigerator', priceKey: 'fridge_fee', default: 20 },
];
const FREQUENCIES = [
  { id: 'onetime', label: 'One-time', sublabel: '' },
  { id: 'monthly', label: 'Monthly', discountKey: 'monthly_discount', default: 10 },
  { id: 'biweekly', label: 'Bi-weekly', discountKey: 'biweekly_discount', default: 15 },
  { id: 'weekly', label: 'Weekly', discountKey: 'weekly_discount', default: 20 },
];

export default function CleaningCalc({ config = {}, effectiveTheme = t, onQuoteUpdate }) {
  const [homeSize, setHomeSize] = useState('one_bed');
  const [extras, setExtras] = useState([]);
  const [frequency, setFrequency] = useState('onetime');

  useEffect(() => {
    const sizeEntry = HOME_SIZES.find(s => s.id === homeSize);
    let total = config[sizeEntry.priceKey] ?? sizeEntry.default;
    extras.forEach(id => {
      const e = EXTRAS.find(x => x.id === id);
      total += config[e.priceKey] ?? e.default;
    });
    const freqEntry = FREQUENCIES.find(f => f.id === frequency);
    const discount = freqEntry.discountKey ? (config[freqEntry.discountKey] ?? freqEntry.default) / 100 : 0;
    onQuoteUpdate(Math.round(total * (1 - discount)), { homeSize, extras, frequency });
  }, [homeSize, extras, frequency]); // eslint-disable-line

  const sel = (active) => active
    ? { borderColor: effectiveTheme.colors.blue, backgroundColor: effectiveTheme.colors.blueTint, borderWidth: '2px' }
    : { borderColor: effectiveTheme.colors.border, borderWidth: '1px' };

  const toggleExtra = (id) => setExtras(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: effectiveTheme.spacing.lg }}>
      <div>
        <h3 style={{ ...effectiveTheme.typography.h4, color: effectiveTheme.colors.textPrimary, fontFamily: effectiveTheme.typography.fontFamily, marginBottom: effectiveTheme.spacing.md }}>Home Size</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))', gap: effectiveTheme.spacing.md }}>
          {HOME_SIZES.map(size => {
            const isSelected = homeSize === size.id;
            return (
              <motion.button
                key={size.id}
                onClick={() => setHomeSize(size.id)}
                style={{
                  ...sel(isSelected),
                  background: isSelected ? effectiveTheme.colors.blueTint : effectiveTheme.colors.surface,
                  color: isSelected ? effectiveTheme.colors.blue : effectiveTheme.colors.muted,
                  padding: `${effectiveTheme.spacing.md} ${effectiveTheme.spacing.sm}`,
                  borderRadius: effectiveTheme.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 600,
                }}
                animate={{ scale: isSelected ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                {size.label}
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...effectiveTheme.typography.h4, color: effectiveTheme.colors.textPrimary, fontFamily: effectiveTheme.typography.fontFamily, marginBottom: effectiveTheme.spacing.md }}>Add-ons</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: effectiveTheme.spacing.md }}>
          {EXTRAS.map(extra => {
            const price = config[extra.priceKey] ?? extra.default;
            const isActive = extras.includes(extra.id);
            return (
              <motion.button
                key={extra.id}
                onClick={() => toggleExtra(extra.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? effectiveTheme.colors.blueTint : effectiveTheme.colors.surface,
                  color: isActive ? effectiveTheme.colors.blue : effectiveTheme.colors.muted,
                  padding: `${effectiveTheme.spacing.md} ${effectiveTheme.spacing.sm}`,
                  borderRadius: effectiveTheme.radius.lg,
                  textAlign: 'left',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div style={{ fontWeight: 500, fontSize: '14px' }}>{extra.label}</div>
                <div style={{ fontSize: '12px', color: effectiveTheme.colors.muted, marginTop: effectiveTheme.spacing.xs }}>+${price}</div>
              </motion.button>
            );
          })}
        </div>
      </div>
      <div>
        <h3 style={{ ...effectiveTheme.typography.h4, color: effectiveTheme.colors.textPrimary, fontFamily: effectiveTheme.typography.fontFamily, marginBottom: effectiveTheme.spacing.md }}>Frequency</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: effectiveTheme.spacing.md }}>
          {FREQUENCIES.map(freq => {
            const discount = freq.discountKey ? (config[freq.discountKey] ?? freq.default) : 0;
            const isActive = frequency === freq.id;
            return (
              <motion.button
                key={freq.id}
                onClick={() => setFrequency(freq.id)}
                style={{
                  ...sel(isActive),
                  background: isActive ? effectiveTheme.colors.blueTint : effectiveTheme.colors.surface,
                  color: isActive ? effectiveTheme.colors.blue : effectiveTheme.colors.muted,
                  padding: `${effectiveTheme.spacing.md} ${effectiveTheme.spacing.sm}`,
                  borderRadius: effectiveTheme.radius.lg,
                  textAlign: 'center',
                  transition: 'all 150ms ease-out',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 600,
                }}
                animate={{ scale: isActive ? 1.02 : 1 }}
                transition={getTransition('fast')}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <div>{freq.label}</div>
                {discount > 0 && <div style={{ fontSize: '12px', color: effectiveTheme.colors.success, marginTop: effectiveTheme.spacing.xs }}>Save {discount}%</div>}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}