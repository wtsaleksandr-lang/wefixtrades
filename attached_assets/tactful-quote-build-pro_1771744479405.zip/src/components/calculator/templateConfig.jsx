export const TEMPLATES = [
  {
    id: 'cleaning',
    name: 'House Cleaning',
    emoji: '🧹',
    description: 'Perfect for residential & commercial cleaning',
    defaultConfig: {
      studio_price: 80, one_bed_price: 100, two_bed_price: 130,
      three_bed_price: 160, four_plus_price: 200,
      deep_clean_fee: 50, windows_fee: 30, oven_fee: 25, fridge_fee: 20,
      weekly_discount: 20, biweekly_discount: 15, monthly_discount: 10,
    },
  },
  {
    id: 'lawn_care',
    name: 'Lawn Care',
    emoji: '🌱',
    description: 'Landscaping and lawn maintenance services',
    defaultConfig: {
      small_price: 35, medium_price: 55, large_price: 80, xlarge_price: 120,
      edging_fee: 20, fertilizing_fee: 40, weed_control_fee: 30, leaf_removal_fee: 50,
      weekly_discount: 15, biweekly_discount: 10,
    },
  },
  {
    id: 'web_design',
    name: 'Web Design',
    emoji: '💻',
    description: 'Website design and development projects',
    defaultConfig: {
      base_price: 800, per_page_price: 80,
      blog_fee: 200, ecommerce_fee: 500, seo_fee: 300, cms_fee: 400, mobile_fee: 200,
      rush_multiplier: 1.5, flexible_discount: 10,
    },
  },
  {
    id: 'roofing',
    name: 'Roofing',
    emoji: '🏠',
    description: 'Roofing installation and repair services',
    defaultConfig: {
      asphalt_per_sqft: 3.5, metal_per_sqft: 7.0, tile_per_sqft: 9.0, flat_per_sqft: 5.5,
      tearoff_per_sqft: 1.0, gutters_fee: 500, skylight_fee: 800, ventilation_fee: 300,
    },
  },
  {
    id: 'moving',
    name: 'Moving Service',
    emoji: '📦',
    description: 'Local and long-distance moving services',
    defaultConfig: {
      studio_base: 200, one_bed_base: 350, two_bed_base: 500, three_bed_base: 650, four_plus_base: 900,
      medium_distance_multiplier: 1.5, long_distance_multiplier: 2.5,
      packing_fee: 200, piano_fee: 300, storage_fee: 150, assembly_fee: 100,
    },
  },
];

export const getTemplate = (id) => TEMPLATES.find(t => t.id === id) || TEMPLATES[0];