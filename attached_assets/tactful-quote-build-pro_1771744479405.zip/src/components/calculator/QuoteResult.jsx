import React from 'react';
import { motion } from 'framer-motion';
import { designTokens, getTransition } from '../designTokens';

export default function QuoteResult({ amount, effectiveTheme = designTokens }) {
  const t = effectiveTheme;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={getTransition('slow')}
      className="rounded-xl border p-6 text-center"
      style={{
        borderColor: designTokens.cardBorder,
        boxShadow: designTokens.shadows.card,
        background: designTokens.colors.background,
      }}
    >
      <p style={{ ...t.typography.labelSm, color: t.colors.textTertiary, marginBottom: t.spacing.md, fontFamily: t.typography.fontFamily }}>
        Your Estimated Quote
      </p>
      <motion.p
        style={{
          fontSize: '48px',
          fontWeight: 700,
          color: t.colors.primary,
          fontFamily: t.typography.fontFamily,
          tabularNums: true,
        }}
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={getTransition('slow', true)}
      >
        ${amount.toLocaleString()}
      </motion.p>
      <p style={{
        ...t.typography.small,
        color: t.colors.textMuted,
        fontFamily: t.typography.fontFamily,
        marginTop: t.spacing.md,
        lineHeight: 1.5,
      }}>
        Estimate only — final price may vary based on your specific needs.
      </p>
    </motion.div>
  );
}