import React, { useState, useEffect, useRef } from 'react';
import CleaningCalc from './templates/CleaningCalc';
import LawnCareCalc from './templates/LawnCareCalc';
import WebDesignCalc from './templates/WebDesignCalc';
import RoofingCalc from './templates/RoofingCalc';
import MovingCalc from './templates/MovingCalc';
import LeadForm from './LeadForm';
import QuoteResult from './QuoteResult';
import { getEffectiveTheme } from '../themeUtils';
import { designTokens } from '../designTokens';

const TEMPLATE_MAP = {
  cleaning: CleaningCalc,
  lawn_care: LawnCareCalc,
  web_design: WebDesignCalc,
  roofing: RoofingCalc,
  moving: MovingCalc,
};

/**
 * CalculatorWidget
 * Standalone, portable calculator component.
 * Can be exported to any React/Vite/Next environment.
 * Accepts: calculator object, isEmbed flag, optional apiBaseUrl
 */
export default function CalculatorWidget({ calculator, isEmbed = false, apiBaseUrl = '' }) {
  const [quoteAmount, setQuoteAmount] = useState(0);
  const [quoteInputs, setQuoteInputs] = useState({});
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const containerRef = useRef(null);

  const {
    template,
    template_config = {},
    business_name,
    logo_url,
    tagline,
    cta_button_text,
    lead_thank_you_message,
    themeOverrides = {},
    slug,
  } = calculator;

  // Get effective theme (global default merged with calculator overrides)
  const effectiveTheme = getEffectiveTheme(themeOverrides);

  // Post height to parent for adaptive embed iframes (PORTABLE)
  useEffect(() => {
    if (!isEmbed) return;
    const postHeight = () => {
      const height = containerRef.current?.scrollHeight;
      if (height) {
        // Try postMessage, fallback for Replit/standalone environments
        try {
          window.parent.postMessage({ type: 'qqHeight', slug, height }, '*');
        } catch (e) {
          // Silently fail in non-iframe contexts
        }
      }
    };
    postHeight();
    const observer = new ResizeObserver(postHeight);
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [isEmbed, slug, showLeadForm, submitted]);

  const TemplateComponent = TEMPLATE_MAP[template] || CleaningCalc;
  
  // Use effective theme's primary color
  const headerColor = effectiveTheme.colors.primary;

  return (
    <div ref={containerRef} className="min-h-screen" style={{ background: designTokens.wizardBackground }}>
      {/* Branded Header */}
      <div className="px-6 py-8 text-white" style={{ backgroundColor: headerColor, fontFamily: effectiveTheme.typography.fontFamily }}>
        <div className="max-w-2xl mx-auto">
          {logo_url && <img src={logo_url} alt={business_name} className="h-10 mb-4 object-contain" onError={e => { e.target.style.display = 'none'; }} />}
          <h1 style={{ ...effectiveTheme.typography.h1, color: '#ffffff', lineHeight: 1.2 }}>{business_name}</h1>
          {tagline && <p style={{ ...effectiveTheme.typography.body, color: 'rgba(255,255,255,0.85)', marginTop: effectiveTheme.spacing.md }}>{tagline}</p>}
        </div>
      </div>

      {/* Calculator Content Container */}
      <div className="max-w-2xl mx-auto px-4 py-10 sm:py-16">
        <div className="rounded-lg" style={{ border: designTokens.cardBorder, boxShadow: designTokens.shadows.card, background: designTokens.colors.background }}>
          <div className="p-6 sm:p-8">
            {!submitted ? (
              <>
                <TemplateComponent
                  config={template_config}
                  effectiveTheme={effectiveTheme}
                  onQuoteUpdate={(amount, inputs) => { setQuoteAmount(amount); setQuoteInputs(inputs); }}
                  primaryColor={effectiveTheme.colors.primary}
                />

                <div className="mt-8">
                  <QuoteResult amount={quoteAmount} effectiveTheme={effectiveTheme} />
                </div>

                {!showLeadForm ? (
                  <button
                    onClick={() => setShowLeadForm(true)}
                    disabled={quoteAmount === 0}
                    className="mt-8 w-full py-3 sm:py-4 rounded-lg text-white font-semibold text-base transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed hover:-translate-y-1 active:scale-98"
                    style={{
                      backgroundColor: effectiveTheme.colors.primary,
                      boxShadow: designTokens.shadows.button,
                      fontFamily: effectiveTheme.typography.fontFamily,
                    }}
                  >
                    {cta_button_text || 'Get My Free Quote'}
                  </button>
                ) : (
                  <div className="mt-8">
                    <LeadForm
                      calculator={calculator}
                      quoteAmount={quoteAmount}
                      quoteInputs={quoteInputs}
                      effectiveTheme={effectiveTheme}
                      onSuccess={() => setSubmitted(true)}
                    />
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-16" style={{ fontFamily: effectiveTheme.typography.fontFamily }}>
                <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: effectiveTheme.colors.primaryLight }}>
                  <svg className="w-8 h-8" style={{ color: effectiveTheme.colors.primary }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 style={{ ...effectiveTheme.typography.h2, color: effectiveTheme.colors.textPrimary, marginBottom: effectiveTheme.spacing.md }}>Quote Request Sent!</h2>
                <p style={{ ...effectiveTheme.typography.body, color: effectiveTheme.colors.textSecondary }}>{lead_thank_you_message || "We'll be in touch shortly."}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return '13,148,136';
  const r = parseInt(result[1], 16);
  const g = parseInt(result[2], 16);
  const b = parseInt(result[3], 16);
  return `${r},${g},${b}`;
}