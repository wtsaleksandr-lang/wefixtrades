import React, { useState } from 'react';
import { designTokens, getTransition } from './designTokens';

export default function AnalyticsDashboard({ metrics }) {
  const [hoveredCard, setHoveredCard] = useState(null);

  if (!metrics) {
    return (
      <div style={{ padding: designTokens.spacing.lg, textAlign: 'center', color: designTokens.colors.muted }}>
        No data available
      </div>
    );
  }

  const {
    total_views = 0,
    total_leads = 0,
    quote_completions = 0,
  } = metrics;

  const conversionRate = total_views > 0 
    ? ((quote_completions / total_views) * 100).toFixed(1)
    : 0;

  const leadRate = quote_completions > 0
    ? ((total_leads / quote_completions) * 100).toFixed(1)
    : 0;

  const cards = [
    { label: 'Page Views', value: total_views, icon: '📊' },
    { label: 'Quote Completions', value: quote_completions, icon: '✓' },
    { label: 'Lead Submissions', value: total_leads, icon: '📧' },
    { label: 'Quote Completion Rate', value: `${conversionRate}%`, icon: '%' },
    { label: 'Lead Conversion Rate', value: `${leadRate}%`, icon: '🎯' },
  ];

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: designTokens.layout.sectionGap }}>
      {cards.map((card, idx) => (
        <div
          key={card.label}
          onMouseEnter={() => setHoveredCard(idx)}
          onMouseLeave={() => setHoveredCard(null)}
          style={{
            padding: designTokens.layout.cardPadding,
            backgroundColor: designTokens.colors.surface,
            border: `1px solid ${designTokens.colors.border}`,
            borderRadius: designTokens.radius.xl,
            boxShadow: hoveredCard === idx ? designTokens.shadows.sm : designTokens.shadows.xs,
            transition: getTransition('fast'),
            cursor: 'default',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: designTokens.spacing.lg }}>
            <p style={{ ...designTokens.typography.caption, color: designTokens.colors.muted }}>
              {card.label}
            </p>
            <span style={{ fontSize: '20px' }}>{card.icon}</span>
          </div>
          <p style={{ ...designTokens.typography.metric, color: designTokens.colors.heading }}>
            {card.value}
          </p>
        </div>
      ))}
    </div>
  );
}