/**
 * Centralized Design Token System
 * Premium SaaS Design System (Stripe/Linear/Webflow inspired)
 * Single source of truth for all visual constants
 */

// ═══════════════════════════════════════════════════════════════════════════
// SPACING SCALE (8px base)
// ═══════════════════════════════════════════════════════════════════════════
const SPACING = {
  xs: '4px',    // 4
  sm: '8px',    // 8
  md: '12px',   // 12
  lg: '16px',   // 16
  xl: '20px',   // 20
  '2xl': '24px', // 24
  '3xl': '32px', // 32
  '4xl': '48px', // 48
};

// ═══════════════════════════════════════════════════════════════════════════
// COLOR SYSTEM
// ═══════════════════════════════════════════════════════════════════════════
const COLORS = {
  // Primary
  blue: '#2563EB',
  blueHover: '#1E40AF',
  blueLighter: '#EFF6FF',
  blueTint: 'rgba(37, 99, 235, 0.05)',
  
  // Status
  success: '#16A34A',
  danger: '#DC2626',
  warning: '#F97316',
  
  // Neutral
  background: '#F9FAFB',
  surface: '#FFFFFF',
  
  // Text
  heading: '#111827',
  body: '#374151',
  muted: '#6B7280',
  subtle: '#9CA3AF',
  
  // Borders & Dividers
  border: '#E5E7EB',
  borderLight: '#F3F4F6',
};

// ═══════════════════════════════════════════════════════════════════════════
// BORDER RADIUS
// ═══════════════════════════════════════════════════════════════════════════
const RADIUS = {
  sm: '8px',      // inputs
  md: '12px',     // buttons, small inputs
  lg: '16px',     // cards
  xl: '18px',     // primary cards
  pill: '999px',  // badges
};

// ═══════════════════════════════════════════════════════════════════════════
// SHADOWS (Subtle & professional)
// ═══════════════════════════════════════════════════════════════════════════
const SHADOWS = {
  // Level 1: Default card shadow
  xs: '0 1px 2px rgba(0, 0, 0, 0.04), 0 4px 10px rgba(0, 0, 0, 0.04)',
  // Level 2: Hover / elevated
  sm: '0 8px 20px rgba(0, 0, 0, 0.06)',
  // Interactive elements
  md: '0 12px 28px rgba(0, 0, 0, 0.08)',
  lg: '0 20px 40px rgba(0, 0, 0, 0.1)',
};

// ═══════════════════════════════════════════════════════════════════════════
// TYPOGRAPHY
// ═══════════════════════════════════════════════════════════════════════════
const TYPOGRAPHY = {
  h1: {
    fontSize: '28px',
    fontWeight: 600,
    lineHeight: 1.4,
    color: COLORS.heading,
  },
  h2: {
    fontSize: '22px',
    fontWeight: 600,
    lineHeight: 1.4,
    color: COLORS.heading,
  },
  h3: {
    fontSize: '18px',
    fontWeight: 600,
    lineHeight: 1.4,
    color: COLORS.heading,
  },
  body: {
    fontSize: '14px',
    fontWeight: 400,
    lineHeight: 1.6,
    color: COLORS.body,
  },
  caption: {
    fontSize: '12px',
    fontWeight: 500,
    lineHeight: 1.4,
    color: COLORS.muted,
  },
  metric: {
    fontSize: '32px',
    fontWeight: 700,
    lineHeight: 1.2,
    color: COLORS.heading,
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// MAIN DESIGN TOKENS EXPORT
// ═══════════════════════════════════════════════════════════════════════════
export const designTokens = {
  // Colors
  colors: COLORS,

  // Spacing
  spacing: SPACING,

  // Border radius
  radius: RADIUS,

  // Shadows
  shadows: SHADOWS,

  // Typography
  typography: TYPOGRAPHY,

  // Transitions (smooth, no bounce)
  transitions: {
    fast: 'all 0.15s ease-out',
    normal: 'all 0.2s ease-out',
    slow: 'all 0.3s ease-out',
  },

  // Layout
  layout: {
    desktopPadding: SPACING['3xl'],   // 32px
    mobilePadding: SPACING['2xl'],     // 24px (reduced from 20px for consistency)
    cardPadding: SPACING['2xl'],       // 24px
    sectionGap: SPACING['3xl'],        // 32px between sections
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// HELPER UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export const getTransition = (speed = 'normal') => {
  if (prefersReducedMotion()) return 'none';
  return designTokens.transitions[speed] || designTokens.transitions.normal;
};

// Shared button styles
export const buttonStyles = {
  primary: {
    backgroundColor: COLORS.blue,
    color: 'white',
    padding: `${SPACING.md} ${SPACING.xl}`,
    fontSize: '14px',
    fontWeight: 600,
    border: 'none',
    borderRadius: RADIUS.md,
    cursor: 'pointer',
    transition: getTransition('fast'),
    ':hover': {
      backgroundColor: COLORS.blueHover,
      boxShadow: SHADOWS.sm,
    },
  },
  secondary: {
    backgroundColor: 'transparent',
    color: COLORS.blue,
    padding: `${SPACING.md} ${SPACING.xl}`,
    fontSize: '14px',
    fontWeight: 600,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md,
    cursor: 'pointer',
    transition: getTransition('fast'),
    ':hover': {
      backgroundColor: COLORS.blueTint,
      borderColor: COLORS.blue,
    },
  },
};

// Card styles
export const cardStyles = {
  container: {
    backgroundColor: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.xl,
    padding: designTokens.layout.cardPadding,
    boxShadow: SHADOWS.xs,
    transition: getTransition('fast'),
  },
  hover: {
    boxShadow: SHADOWS.sm,
  },
};

// Input field styles
export const inputStyles = {
  base: {
    padding: `${SPACING.md} ${SPACING.lg}`,
    fontSize: '14px',
    fontWeight: 400,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md,
    backgroundColor: COLORS.surface,
    color: COLORS.body,
    transition: getTransition('fast'),
    ':focus': {
      outline: 'none',
      borderColor: COLORS.blue,
      boxShadow: `0 0 0 3px ${COLORS.blueTint}`,
    },
  },
};