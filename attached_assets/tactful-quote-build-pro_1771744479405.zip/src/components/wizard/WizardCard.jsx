/**
 * WizardCard — self-contained, portable wizard component.
 *
 * Props:
 *   embed (bool) — when true, removes outer padding/background so the card
 *                  fits cleanly inside a parent div or iframe.
 *   onInvoke (fn) — async (functionName, payload) => data
 *                   Abstracts the API call so this component works outside Base44.
 *                   In Base44: (name, payload) => base44.functions.invoke(name, payload).then(r => r.data)
 */

import React, { useState, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Rocket, Loader2, CircleHelp, X, ChevronDown } from 'lucide-react';
import { designTokens, getTransition } from '@/components/designTokens';
import PremiumButton from '@/components/PremiumButton';

import StepBusinessDetails from './StepBusinessDetails';
import StepDesign from './StepDesign';
import StepPricing from './StepPricing';
import StepLeadCapture from './StepLeadCapture';
import StepPreview from './StepPreview';
import StepLaunch from './StepLaunch';
import SuccessScreen from './SuccessScreen';
import LivePreviewPanel from './LivePreviewPanel';
import FullPreviewModal from './FullPreviewModal';

const STEPS = [
  { label: 'Business' },
  { label: 'Design' },
  { label: 'Pricing' },
  { label: 'Lead Form' },
  { label: 'Preview' },
  { label: 'Launch' },
];

const DEFAULT_DATA = {
  business_name: '', business_type: 'cleaning', tagline: '', logo_url: '',
  template: 'cleaning', template_config: {},
  primary_color: '#6366f1', font: 'Inter', button_style: 'rounded',
  cta_button_text: 'Get My Free Quote',
  lead_capture_fields: ['name', 'email', 'phone'],
  lead_required_fields: ['name', 'email'],
  lead_thank_you_message: "Thanks! We'll be in touch within 24 hours.",
  custom_slug: '', owner_email: '',
};

const prefersReducedMotion = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const variants = {
  enter: (dir) => prefersReducedMotion 
    ? { opacity: 1 }
    : { x: dir > 0 ? 40 : -40, opacity: 0, y: 8 },
  center: { x: 0, y: 0, opacity: 1 },
  exit: (dir) => prefersReducedMotion
    ? { opacity: 0 }
    : { x: dir > 0 ? -40 : 40, opacity: 0, y: -8 },
};

const FAQ_ITEMS = [
  { q: 'Do I need an account?', a: 'No. You can create and publish instantly.' },
  { q: 'How do I add this to my website?', a: 'In Step 6 you can install it or use a hosted quote page.' },
  {
    q: "What if I don't have a website?",
    a: (
      <>
        Use the hosted quote page or{' '}
        <a
          href="https://quickquote.tools/website-builder"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-700 underline transition-colors"
        >
          request a website service from us
        </a>
        .
      </>
    ),
  },
  { q: 'How do I receive leads?', a: 'Leads are sent to your email and phone.' },
  { q: 'Can I edit later?', a: 'Yes. Use your edit link anytime.' },
];

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-slate-100 last:border-0">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between py-3 text-left gap-3 group hover:bg-slate-50 px-0 -mx-0 transition-colors"
      >
        <span className="text-[13px] font-medium text-slate-800 group-hover:text-blue-600 transition-colors">{q}</span>
        <ChevronDown
          className="w-4 h-4 text-slate-400 flex-shrink-0 transition-transform duration-200"
          style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }}
        />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="overflow-hidden"
          >
            <div className="pb-3 pt-1 text-[13px] text-slate-600 leading-relaxed">{a}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function HelpDrawer({ onClose, onRequestCustom }) {
  return (
    <div className="absolute inset-0 z-50 flex items-start justify-end" style={{ borderRadius: 28, overflow: 'hidden' }} onClick={onClose}>
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        style={{ background: 'rgba(15,23,42,0.22)', backdropFilter: 'blur(2px)' }}
      />
      {/* Floating panel */}
      <motion.div
        initial={{ opacity: 0, y: -8, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -8, scale: 0.97 }}
        transition={{ duration: 0.18, ease: 'easeOut' }}
        className="relative z-10 w-full max-w-[300px] bg-white flex flex-col overflow-hidden rounded-2xl mt-12 mr-4 sm:mr-6"
        style={{ boxShadow: '0 20px 60px rgba(0,0,0,0.18)', maxHeight: 'calc(100vh - 80px)' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-slate-100">
          <h3 className="text-[15px] font-semibold text-slate-800 tracking-tight">How it works</h3>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
          <div className="flex-1 overflow-y-auto px-5 py-5 space-y-7">
            {/* Steps */}
             <div className="space-y-3.5">
               {[
                 { n: 1, text: 'Customize your instant quote tool' },
                 { n: 2, text: 'Set your pricing logic' },
                 { n: 3, text: 'Publish and start receiving qualified leads' },
               ].map(({ n, text }) => (
                <div key={n} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0 font-bold text-[11px]" style={{ background: 'rgba(37,99,235,0.12)', color: '#2563EB' }}>
                  {n}
                  </div>
                  <p className="text-[13px] text-slate-600 leading-relaxed pt-0.5">{text}</p>
                </div>
              ))}
            </div>

            {/* FAQ */}
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-[0.08em] mb-3">Questions</p>
            <div>
              {FAQ_ITEMS.map(item => <FaqItem key={item.q} {...item} />)}
            </div>
          </div>
        </div>

        {/* Footer CTA */}
        <div className="px-5 py-5 border-t border-slate-100 bg-slate-50">
          <p className="text-[12px] text-slate-600 font-medium mb-3">Need something custom?</p>
          <button
            type="button"
            onClick={() => { onRequestCustom(); onClose(); }}
            className="w-full py-2.5 rounded-xl text-[13px] font-semibold transition-all active:scale-95"
            style={{ color: '#2563EB', background: 'rgba(37,99,235,0.08)', border: '1px solid rgba(37,99,235,0.25)' }}
          >
            Request Custom Tool →
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export default function WizardCard({ embed = false, onInvoke }) {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [data, setData] = useState(DEFAULT_DATA);
  const [result, setResult] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [showHelp, setShowHelp] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [saveIndicator, setSaveIndicator] = useState(false);
  const [autoPreview, setAutoPreview] = useState(true);
  const [showFullPreview, setShowFullPreview] = useState(false);
  const stepRef = useRef(null);
  const saveTimeoutRef = useRef(null);

  const handleRequestCustom = () => {
    setStep(0);
    setDirection(-1);
    // Signal step 0 to select custom category — via a small delay so StepBusinessDetails mounts
    setTimeout(() => {
      stepRef.current?.selectCustomCategory?.();
    }, 50);
  };

  // Auto-save progress to localStorage
  const merge = (updates) => {
    setData(prev => {
      const newData = { ...prev, ...updates };
      // Save to localStorage
      try {
        localStorage.setItem('qqWizardProgress', JSON.stringify(newData));
        // Show "Saved" indicator
        setSaveIndicator(true);
        if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
        saveTimeoutRef.current = setTimeout(() => setSaveIndicator(false), 1500);
      } catch (e) {
        // Silently fail if localStorage unavailable
      }
      return newData;
    });
  };

  // Load saved progress on mount
  React.useEffect(() => {
    try {
      const saved = localStorage.getItem('qqWizardProgress');
      if (saved) {
        const savedData = JSON.parse(saved);
        setData(savedData);
      }
    } catch (e) {
      // Silently fail if can't parse
    }
  }, []);

  const goNext = async () => {
    // Block progression if custom category is selected
    if (step === 0 && stepRef.current?.isCustomCategory?.()) return;
    if (stepRef.current?.getData) {
      const stepData = stepRef.current.getData();
      if (!stepData) return;
      merge(stepData);
    }
    if (step === STEPS.length - 1) {
      await doSubmit();
      return;
    }
    setDirection(1);
    setStep(s => s + 1);
  };

  const goBack = () => {
    setDirection(-1);
    setStep(s => s - 1);
    setError(null);
  };

  const doSubmit = async () => {
    const launch = stepRef.current?.getData?.() || {};
    const finalData = { ...data, ...launch };
    setIsSubmitting(true);
    setError(null);
    const responseData = await onInvoke('createCalculator', finalData);
    if (responseData?.success) {
      setResult(responseData);
    } else {
      setError(responseData?.error || 'Something went wrong. Please try again.');
    }
    setIsSubmitting(false);
  };

  const progress = (step / (STEPS.length - 1)) * 100;
  const isLastStep = step === STEPS.length - 1;
  const stepProps = { data, onChange: merge };

  if (result) {
    return (
      <div style={{ padding: embed ? 0 : `${designTokens.layout.mobilePadding} ${designTokens.layout.mobilePadding}` }}>
        <SuccessScreen result={result} wizardData={data} />
      </div>
    );
  }

  // Desktop layout: 2-column
  const isDesktop = typeof window !== 'undefined' && window.innerWidth >= 1280;

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <AnimatePresence>
        {showFullPreview && (
          <FullPreviewModal data={data} onClose={() => setShowFullPreview(false)} />
        )}
      </AnimatePresence>

      <div
        className="flex flex-col lg:flex-row w-full lg:gap-8"
        style={{
          position: 'relative',
          gap: designTokens.spacing.lg,
          isolation: 'isolate',
        }}
      >
        {/* Left column — Configuration Panel */}
        <div
          className="flex-1 lg:w-3/5 flex flex-col"
          style={{
            backgroundColor: designTokens.colors.surface,
            border: `1px solid ${designTokens.colors.border}`,
            boxShadow: designTokens.shadows.xs,
            borderRadius: designTokens.radius.xl,
            overflow: 'hidden',
          }}
        >
        <AnimatePresence>
          {showHelp && (
            <HelpDrawer
              key="help-drawer"
              onClose={() => setShowHelp(false)}
              onRequestCustom={handleRequestCustom}
            />
          )}
        </AnimatePresence>

        {/* Progress bar */}
        <div
          style={{
            height: '2px',
            background: designTokens.colors.borderLight,
            overflow: 'hidden',
          }}
        >
          <motion.div
            style={{
              width: `${progress}%`,
              background: designTokens.colors.blue,
              height: '100%',
            }}
            animate={{ width: `${progress}%` }}
            transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.32, ease: 'easeOut' }}
          />
        </div>

        {/* Step meta row — step counter + save indicator + help icon + preview toggle */}
        <div style={{ padding: `${designTokens.spacing['2xl']}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${designTokens.colors.border}`, backgroundColor: designTokens.colors.borderLight }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: designTokens.spacing.md }}>
            <span style={{ ...designTokens.typography.caption, textTransform: 'uppercase', letterSpacing: '0.12em' }}>
              Step {step + 1} of {STEPS.length}
            </span>
            <AnimatePresence>
              {saveIndicator && (
                <motion.span
                  initial={{ opacity: 0, x: -4 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 4 }}
                  transition={{ duration: 0.15 }}
                  style={{ ...designTokens.typography.caption, color: designTokens.colors.success, letterSpacing: '0.08em' }}
                >
                  Saved
                </motion.span>
              )}
            </AnimatePresence>
          </div>
          {/* Right controls: auto preview toggle + help icon */}
          <div style={{ display: 'flex', alignItems: 'center', gap: designTokens.spacing.md }}>
            <div style={{ display: 'none', gap: designTokens.spacing.xs, padding: designTokens.spacing.xs, borderRadius: designTokens.radius.md, backgroundColor: designTokens.colors.borderLight, border: `1px solid ${designTokens.colors.border}` }} className="lg:flex">
              <button
                type="button"
                onClick={() => setAutoPreview(!autoPreview)}
                style={{
                  padding: `${designTokens.spacing.sm} ${designTokens.spacing.lg}`,
                  borderRadius: designTokens.radius.sm,
                  ...designTokens.typography.caption,
                  background: autoPreview ? designTokens.colors.surface : 'transparent',
                  color: autoPreview ? designTokens.colors.blue : designTokens.colors.muted,
                  boxShadow: autoPreview ? designTokens.shadows.xs : 'none',
                  transition: getTransition('fast'),
                  cursor: 'pointer',
                  border: 'none',
                }}
              >
                {autoPreview ? '✓ Auto' : 'Auto'}
              </button>
            </div>
            <div style={{ position: 'relative' }}>
               <button
                 type="button"
                 onClick={() => setShowHelp(true)}
                 onMouseEnter={() => setShowTooltip(true)}
                 onMouseLeave={() => setShowTooltip(false)}
                 style={{
                   width: '32px',
                   height: '32px',
                   display: 'flex',
                   alignItems: 'center',
                   justifyContent: 'center',
                   borderRadius: designTokens.radius.md,
                   transition: getTransition('fast'),
                   cursor: 'pointer',
                   color: designTokens.colors.muted,
                   background: showTooltip ? designTokens.colors.blueTint : 'transparent',
                   border: 'none',
                   padding: 0,
                 }}
                 aria-label="Help"
               >
                 <CircleHelp className="w-[18px] h-[18px]" strokeWidth={1.6} />
               </button>
              <AnimatePresence>
                {showTooltip && (
                  <motion.div
                    initial={{ opacity: 0, y: 2 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 2 }}
                    transition={{ duration: 0.12 }}
                    className="absolute right-0 top-full mt-1.5 px-2 py-1 rounded-md text-[11px] font-medium text-white pointer-events-none whitespace-nowrap"
                    style={{ background: 'rgba(11,18,32,0.8)' }}
                  >
                    Help
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Step content */}
        <div style={{ overflow: 'hidden' }}>
          <AnimatePresence custom={direction} mode="wait" initial={false}>
            <motion.div
              key={step}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.25, ease: 'easeOut' }}
              style={{
                padding: `${designTokens.spacing.lg} ${designTokens.layout.cardPadding}`,
                minHeight: '400px',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              {step === 0 && <StepBusinessDetails {...stepProps} ref={stepRef} />}
              {step === 1 && <StepDesign {...stepProps} ref={stepRef} />}
              {step === 2 && <StepPricing {...stepProps} ref={stepRef} />}
              {step === 3 && <StepLeadCapture {...stepProps} ref={stepRef} />}
              {step === 4 && <StepPreview {...stepProps} ref={stepRef} />}
              {step === 5 && <StepLaunch {...stepProps} ref={stepRef} />}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Error banner */}
        {error && (
          <div style={{
            margin: `0 ${designTokens.spacing['2xl']} ${designTokens.spacing.md}`,
            padding: `${designTokens.spacing.md} ${designTokens.spacing.lg}`,
            backgroundColor: '#FEE2E2',
            border: `1px solid ${designTokens.colors.danger}`,
            borderRadius: designTokens.radius.md,
            color: designTokens.colors.danger,
            ...designTokens.typography.body,
          }}>
            {error}
          </div>
        )}

        {/* Navigation footer */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: designTokens.spacing['2xl'],
            borderTop: `1px solid ${designTokens.colors.border}`,
            backgroundColor: designTokens.colors.borderLight,
          }}
        >
          <button
            onClick={goBack}
            disabled={step === 0 || isSubmitting}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: designTokens.spacing.md,
              ...designTokens.typography.body,
              fontWeight: 600,
              color: step === 0 || isSubmitting ? designTokens.colors.subtle : designTokens.colors.body,
              background: 'transparent',
              border: 'none',
              cursor: step === 0 || isSubmitting ? 'not-allowed' : 'pointer',
              transition: getTransition('fast'),
              opacity: step === 0 || isSubmitting ? 0.5 : 1,
            }}
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>

          <div className="flex gap-1.5 items-center">
            {/* Progress dots via top bar */}
          </div>

          <PremiumButton
            onClick={goNext}
            disabled={isSubmitting}
            loading={isSubmitting}
            icon={
              isSubmitting ? null : isLastStep ? (
                <Rocket className="w-4 h-4" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )
            }
          >
            {isSubmitting ? 'Creating...' : isLastStep ? 'Launch' : 'Continue'}
          </PremiumButton>
          </div>
          </div>

          {/* Right column — Live Preview (desktop only) */}
          <div className="hidden lg:flex lg:w-2/5 flex-col py-6">
          <LivePreviewPanel data={data} onOpenFullPreview={() => setShowFullPreview(true)} />
          </div>
          </div>

          {/* Mobile: Collapsible preview drawer */}
          <div style={{ marginTop: designTokens.spacing['2xl'], padding: `0 ${designTokens.spacing.lg}` }} className="lg:hidden">
          <MobilePreviewDrawer data={data} onOpenFull={() => setShowFullPreview(true)} />
          </div>
          </div>
          );
}

function MobilePreviewDrawer({ data, onOpenFull }) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{ borderRadius: designTokens.radius.xl, border: `1px solid ${designTokens.colors.border}`, backgroundColor: designTokens.colors.surface, overflow: 'hidden' }}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        style={{
          width: '100%',
          padding: `${designTokens.spacing['2xl']} ${designTokens.spacing['2xl']}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          textAlign: 'left',
          backgroundColor: 'transparent',
          border: 'none',
          cursor: 'pointer',
          transition: getTransition('fast'),
        }}
        onMouseEnter={(e) => e.target.style.backgroundColor = designTokens.colors.borderLight}
        onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
      >
        <span style={{ ...designTokens.typography.body, fontWeight: 600, color: designTokens.colors.heading }}>Live Preview</span>
        <ChevronDown className="w-4 h-4" style={{ color: designTokens.colors.muted, transition: getTransition('fast'), transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            style={{ overflow: 'hidden', borderTop: `1px solid ${designTokens.colors.border}` }}
          >
            <div style={{ padding: `${designTokens.spacing.lg} ${designTokens.spacing['2xl']} ${designTokens.spacing['2xl']}` }}>
              <button
                type="button"
                onClick={onOpenFull}
                style={{
                  width: '100%',
                  padding: `${designTokens.spacing.md} ${designTokens.spacing.lg}`,
                  borderRadius: designTokens.radius.md,
                  ...designTokens.typography.body,
                  fontWeight: 600,
                  color: designTokens.colors.blue,
                  backgroundColor: designTokens.colors.blueTint,
                  border: `1px solid ${designTokens.colors.border}`,
                  cursor: 'pointer',
                  transition: getTransition('fast'),
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = designTokens.colors.blueLighter;
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = designTokens.colors.blueTint;
                }}
              >
                Open Full Preview
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}