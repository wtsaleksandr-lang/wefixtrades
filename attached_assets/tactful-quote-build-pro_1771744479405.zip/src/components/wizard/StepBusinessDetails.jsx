import React, { useState, useImperativeHandle, forwardRef, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { base44 } from '@/api/base44Client';
import { designTokens } from '@/components/designTokens';
import StepShell from './StepShell';
import {
  Search, X, Upload, Check, Sparkles, Hammer, Layers, Wrench,
  AlertTriangle, Car, Briefcase, Plus, Loader2, CheckCircle2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// ── Category → trades mapping ──────────────────────────────────────────────────
export const CATEGORIES = [
  {
    value: 'cleaning',
    label: 'Cleaning & Maintenance',
    icon: Sparkles,
    trades: [
      { value: 'house_cleaning', label: 'House Cleaning', template: 'cleaning' },
      { value: 'deep_cleaning', label: 'Deep Cleaning', template: 'cleaning' },
      { value: 'move_in_out_cleaning', label: 'Move-In / Move-Out Cleaning', template: 'cleaning' },
      { value: 'commercial_cleaning', label: 'Commercial Cleaning', template: 'cleaning' },
      { value: 'post_construction_cleaning', label: 'Post-Construction Cleaning', template: 'cleaning' },
      { value: 'carpet_cleaning', label: 'Carpet Cleaning', template: 'cleaning' },
      { value: 'window_cleaning', label: 'Window Cleaning', template: 'cleaning' },
      { value: 'pressure_washing', label: 'Pressure Washing', template: 'cleaning' },
      { value: 'gutter_cleaning', label: 'Gutter Cleaning', template: 'cleaning' },
      { value: 'pool_cleaning', label: 'Pool Cleaning & Maintenance', template: 'cleaning' },
      { value: 'chimney_sweep', label: 'Chimney Sweep', template: 'cleaning' },
      { value: 'dryer_vent_cleaning', label: 'Dryer Vent Cleaning', template: 'cleaning' },
    ],
  },
  {
    value: 'construction',
    label: 'Home Construction & Renovation',
    icon: Hammer,
    trades: [
      { value: 'kitchen_remodeling', label: 'Kitchen Remodeling', template: 'roofing' },
      { value: 'bathroom_remodeling', label: 'Bathroom Remodeling', template: 'roofing' },
      { value: 'basement_finishing', label: 'Basement Finishing', template: 'roofing' },
      { value: 'home_addition', label: 'Home Addition / Extension', template: 'roofing' },
      { value: 'interior_painting', label: 'Interior Painting', template: 'roofing' },
      { value: 'exterior_painting', label: 'Exterior Painting', template: 'roofing' },
      { value: 'cabinet_refinishing', label: 'Cabinet Refinishing', template: 'roofing' },
      { value: 'flooring_installation', label: 'Flooring Installation', template: 'roofing' },
      { value: 'tile_installation', label: 'Tile Installation', template: 'roofing' },
      { value: 'drywall_plaster', label: 'Drywall & Plaster', template: 'roofing' },
      { value: 'insulation_installation', label: 'Insulation Installation', template: 'roofing' },
      { value: 'deck_construction', label: 'Deck Construction (Wood / Composite)', template: 'roofing' },
      { value: 'patio_installation', label: 'Patio Installation', template: 'roofing' },
      { value: 'fence_installation', label: 'Fence Installation', template: 'roofing' },
      { value: 'shed_installation', label: 'Shed Installation & Assembly', template: 'roofing' },
      { value: 'roofing_installation', label: 'Roofing Installation', template: 'roofing' },
      { value: 'siding_installation', label: 'Siding Installation', template: 'roofing' },
      { value: 'window_replacement', label: 'Window Replacement', template: 'roofing' },
      { value: 'door_installation', label: 'Door Installation', template: 'roofing' },
    ],
  },
  {
    value: 'driveway',
    label: 'Driveway & Concrete',
    icon: Layers,
    trades: [
      { value: 'asphalt_driveway', label: 'Asphalt Driveway Paving', template: 'roofing' },
      { value: 'driveway_sealing', label: 'Driveway Sealing', template: 'roofing' },
      { value: 'concrete_driveway', label: 'Concrete Driveway Installation', template: 'roofing' },
      { value: 'stamped_concrete', label: 'Stamped Concrete', template: 'roofing' },
      { value: 'interlocking_paver', label: 'Interlocking / Paver Installation', template: 'roofing' },
      { value: 'concrete_slab', label: 'Concrete Slab Installation', template: 'roofing' },
      { value: 'retaining_wall', label: 'Retaining Wall Construction', template: 'roofing' },
    ],
  },
  {
    value: 'mechanical',
    label: 'Mechanical & Systems',
    icon: Wrench,
    trades: [
      { value: 'hvac_installation', label: 'HVAC Installation', template: 'roofing' },
      { value: 'hvac_repair', label: 'HVAC Repair', template: 'roofing' },
      { value: 'furnace_replacement', label: 'Furnace Replacement', template: 'roofing' },
      { value: 'water_heater_installation', label: 'Water Heater Installation', template: 'roofing' },
      { value: 'plumbing', label: 'Plumbing Services', template: 'roofing' },
      { value: 'electrical', label: 'Electrical Services', template: 'roofing' },
      { value: 'ev_charger', label: 'EV Charger Installation', template: 'roofing' },
      { value: 'solar_installation', label: 'Solar Panel Installation', template: 'roofing' },
      { value: 'solar_battery', label: 'Solar Battery Storage', template: 'roofing' },
      { value: 'generator_installation', label: 'Generator Installation', template: 'roofing' },
      { value: 'security_system', label: 'Security System Installation', template: 'roofing' },
      { value: 'cctv_installation', label: 'CCTV Installation', template: 'roofing' },
      { value: 'garage_door_installation', label: 'Garage Door Installation', template: 'roofing' },
      { value: 'appliance_repair', label: 'Appliance Repair', template: 'roofing' },
    ],
  },
  {
    value: 'emergency',
    label: 'Emergency Services',
    icon: AlertTriangle,
    trades: [
      { value: 'emergency_plumbing', label: 'Emergency Plumbing', template: 'roofing' },
      { value: 'water_damage_restoration', label: 'Water Damage Restoration', template: 'roofing' },
      { value: 'mold_remediation', label: 'Mold Remediation', template: 'roofing' },
      { value: 'fire_damage_restoration', label: 'Fire Damage Restoration', template: 'roofing' },
      { value: 'locksmith', label: 'Locksmith Services', template: 'roofing' },
      { value: 'emergency_hvac_repair', label: 'Emergency HVAC Repair', template: 'roofing' },
      { value: 'emergency_electrical', label: 'Emergency Electrical Repair', template: 'roofing' },
    ],
  },
  {
    value: 'auto',
    label: 'Auto & Mobile Services',
    icon: Car,
    trades: [
      { value: 'mobile_car_detailing', label: 'Mobile Car Detailing', template: 'cleaning' },
      { value: 'auto_detailing', label: 'Auto Detailing', template: 'cleaning' },
      { value: 'window_tinting', label: 'Window Tinting', template: 'roofing' },
      { value: 'windshield_repair', label: 'Windshield Repair', template: 'roofing' },
      { value: 'mobile_mechanic', label: 'Mobile Mechanic', template: 'roofing' },
      { value: 'vehicle_wrap', label: 'Vehicle Wrap', template: 'roofing' },
      { value: 'paint_protection_film', label: 'Paint Protection Film', template: 'roofing' },
    ],
  },
  {
    value: 'professional',
    label: 'Professional Services',
    icon: Briefcase,
    trades: [
      { value: 'web_design', label: 'Web Design', template: 'web_design' },
      { value: 'it_services', label: 'IT Services', template: 'web_design' },
      { value: 'marketing_agency', label: 'Marketing Agency', template: 'web_design' },
      { value: 'mortgage_broker', label: 'Mortgage Broker', template: 'web_design' },
      { value: 'insurance_broker', label: 'Insurance Broker', template: 'web_design' },
      { value: 'real_estate_agent', label: 'Real Estate Agent', template: 'web_design' },
      { value: 'home_inspection', label: 'Home Inspection', template: 'web_design' },
      { value: 'land_surveying', label: 'Land Surveying', template: 'web_design' },
      { value: 'photography', label: 'Photography', template: 'web_design' },
      { value: 'videography', label: 'Videography', template: 'web_design' },
      { value: 'drone_services', label: 'Drone Services', template: 'web_design' },
    ],
  },
];

// Custom category sentinel — not in CATEGORIES array so it doesn't need trades
export const CUSTOM_CATEGORY = { value: 'custom', label: 'Custom / Not Listed', icon: Plus };

export function getTemplateForTrade(tradeValue) {
  for (const cat of CATEGORIES) {
    const trade = cat.trades.find(t => t.value === tradeValue);
    if (trade) return trade.template;
  }
  return 'cleaning';
}

export function getTradeLabelForValue(tradeValue) {
  for (const cat of CATEGORIES) {
    const trade = cat.trades.find(t => t.value === tradeValue);
    if (trade) return trade.label;
  }
  return tradeValue;
}

// ── TradeDropdown ─────────────────────────────────────────────────────────────
function TradeDropdown({ trades, value, onChange }) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const filtered = query
    ? trades.filter(t => t.label.toLowerCase().includes(query.toLowerCase()))
    : trades;

  const selected = trades.find(t => t.value === value);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => { setOpen(o => !o); setTimeout(() => document.getElementById('trade-search')?.focus(), 50); }}
        className={`w-full flex items-center justify-between px-3.5 py-2.5 border rounded-xl bg-white/70 backdrop-blur-sm text-sm shadow-sm transition-all ${
          open ? 'border-blue-500 ring-1 ring-blue-400' : 'border-slate-200 hover:border-blue-400'
        }`}
      >
        <span className={selected ? 'text-slate-800 font-medium' : 'text-slate-400'}>
          {selected ? selected.label : 'Select the exact service…'}
        </span>
        <svg className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 mt-1.5 w-full bg-white/95 backdrop-blur-md border border-slate-200 rounded-xl shadow-xl overflow-hidden"
          >
            <div className="p-2 border-b border-slate-100">
              <div className="relative">
              <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
              <input
                id="trade-search"
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search services…"
                className="w-full pl-7 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-100 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              </div>
            </div>
            <div className="max-h-52 overflow-y-auto">
              {filtered.length === 0 ? (
                <div className="px-4 py-3 text-sm text-slate-400 text-center">No results</div>
              ) : (
                filtered.map(trade => (
                  <button
                    key={trade.value}
                    type="button"
                    onClick={() => { onChange(trade); setOpen(false); setQuery(''); }}
                    className={`w-full flex items-center justify-between px-4 py-2.5 text-sm text-left transition-colors ${
                                  value === trade.value ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-700 hover:bg-slate-50'
                                }`}
                  >
                    <span>{trade.label}</span>
                    {value === trade.value && <Check className="w-3.5 h-3.5 text-blue-600" />}
                  </button>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── CategoryTile ──────────────────────────────────────────────────────────────
function CategoryTile({ cat, isSelected, isCustom, onClick }) {
  const Icon = cat.icon;
  const [isHovered, setIsHovered] = useState(false);
  const prefersReducedMotion = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  return (
    <motion.button
      type="button"
      onClick={() => onClick(cat)}
      className="relative flex flex-col items-center justify-center gap-2.5 px-3 py-4 text-center text-xs font-medium select-none outline-none h-[100px]"
      style={{
        borderRadius: 14,
        border: isCustom
          ? isSelected ? '2px dashed #2563EB' : '1.5px dashed rgba(15,23,42,0.15)'
          : isSelected ? '2px solid #2563EB' : '1px solid rgba(15,23,42,0.08)',
        background: isSelected ? 'rgba(37,99,235,0.06)' : '#FFFFFF',
        color: isSelected ? '#2563EB' : isCustom ? '#94a3b8' : '#475569',
        boxShadow: isSelected
          ? '0 6px 18px rgba(37,99,235,0.16), 0 0 0 3px rgba(37,99,235,0.09)'
          : isHovered
            ? '0 20px 40px rgba(15,23,42,0.15)'
            : '0 6px 18px rgba(15,23,42,0.06)',
        transition: prefersReducedMotion ? 'none' : 'box-shadow 0.18s ease, background 0.18s ease, border-color 0.18s ease',
      }}
      animate={{
        scale: isSelected ? 1.02 : isHovered ? 1.03 : 1,
        y: isSelected ? -2 : isHovered ? -4 : 0,
      }}
      transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.17, ease: 'easeOut' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileTap={{ scale: 0.97 }}
    >
      <motion.div
        animate={{
            scale: isSelected ? 1.12 : isHovered ? 1.06 : 1,
            color: isSelected ? '#2563EB' : isHovered ? '#1E293B' : '#64748B',
          }}
        transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.16, ease: 'easeOut' }}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <Icon className="w-6 h-6" strokeWidth={2} />
      </motion.div>
      <span className="leading-tight px-1 font-medium text-[12px]">{cat.label}</span>
      <AnimatePresence>
        {isSelected && (
          <motion.span
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.28, ease: 'easeOut' }}
            className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center"
            style={{ background: '#2563EB', boxShadow: '0 3px 8px rgba(37,99,235,0.30)' }}
          >
            <Check className="w-2.5 h-2.5 text-white" strokeWidth={3.5} />
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

// ── CustomRequestPanel ────────────────────────────────────────────────────────
function CustomRequestPanel() {
  const [form, setForm] = useState({ description: '', pricing: '', website: '', email: '' });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    const errs = {};
    if (!form.description.trim()) errs.description = 'Please describe your service.';
    if (!form.email.trim()) errs.email = 'Please enter your email.';
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSubmitting(true);
    // Store request via Base44 LLM integration as a simple notification
    await base44.integrations.Core.SendEmail({
      to: 'hello@quickquote.app',
      subject: 'Custom Quote Tool Request',
      body: `Service: ${form.description}\nPricing: ${form.pricing}\nWebsite: ${form.website}\nEmail: ${form.email}`,
    }).catch(() => {}); // fire-and-forget
    setSubmitting(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center gap-3 py-6 text-center"
      >
        <CheckCircle2 className="w-9 h-9 text-emerald-500" strokeWidth={1.5} />
        <p className="text-sm font-medium text-slate-700">Thanks. We'll review your request and contact you shortly.</p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.22, ease: 'easeOut' }}
      className="overflow-hidden"
    >
      <div
      className="mt-1 rounded-2xl p-4 space-y-3.5"
      style={{ background: '#f8fafc', border: '1px solid rgba(37,99,235,0.15)' }}
      >
        <div>
          <p className="text-[13px] font-semibold text-slate-700">Request a Custom Quote Tool</p>
          <p className="text-xs text-slate-400 mt-0.5">Tell us about your service and we'll build it for you.</p>
        </div>

        <div>
          <Label className="text-xs font-medium text-slate-600">What service do you offer? <span className="text-red-400">*</span></Label>
          <textarea
            className="mt-1 w-full text-sm rounded-xl border border-slate-200 bg-white px-3 py-2 resize-none focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder:text-slate-400"
            rows={2}
            placeholder="e.g. Residential solar panel installation"
            value={form.description}
            onChange={e => { setForm(f => ({ ...f, description: e.target.value })); setErrors(er => ({ ...er, description: null })); }}
          />
          {errors.description && <p className="text-red-500 text-xs mt-0.5">{errors.description}</p>}
        </div>

        <div>
          <Label className="text-xs font-medium text-slate-600">How do you calculate pricing? <span className="text-slate-400 font-normal">(optional)</span></Label>
          <textarea
            className="mt-1 w-full text-sm rounded-xl border border-slate-200 bg-white px-3 py-2 resize-none focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder:text-slate-400"
            rows={2}
            placeholder="e.g. By panel count, roof type, and install complexity"
            value={form.pricing}
            onChange={e => setForm(f => ({ ...f, pricing: e.target.value }))}
          />
        </div>

        <div>
          <Label className="text-xs font-medium text-slate-600">Your website <span className="text-slate-400 font-normal">(optional)</span></Label>
          <Input
            className="mt-1 rounded-xl border-slate-200 bg-white text-sm"
            placeholder="https://yoursite.com"
            value={form.website}
            onChange={e => setForm(f => ({ ...f, website: e.target.value }))}
          />
        </div>

        <div>
          <Label className="text-xs font-medium text-slate-600">Your email <span className="text-red-400">*</span></Label>
          <Input
            className="mt-1 rounded-xl border-slate-200 bg-white text-sm"
            placeholder="you@example.com"
            type="email"
            value={form.email}
            onChange={e => { setForm(f => ({ ...f, email: e.target.value })); setErrors(er => ({ ...er, email: null })); }}
          />
          {errors.email && <p className="text-red-500 text-xs mt-0.5">{errors.email}</p>}
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-white transition-all active:scale-95 disabled:opacity-60"
          style={{ background: '#2563EB', boxShadow: '0 4px 12px rgba(37,99,235,0.25)' }}
        >
          {submitting ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Sending…</> : 'Request Custom Quote Tool'}
        </button>
      </div>
    </motion.div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
const StepBusinessDetails = forwardRef(function StepBusinessDetails({ data, onChange }, ref) {
  const [businessName, setBusinessName] = useState(data.business_name || '');
  const [selectedCategory, setSelectedCategory] = useState(data.selected_category || '');
  const [selectedTrade, setSelectedTrade] = useState(data.selected_trade || null);
  const [logoUrl, setLogoUrl] = useState(data.logo_url || '');
  const [tagline, setTagline] = useState(data.tagline || '');
  const [errors, setErrors] = useState({});
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const isCustom = selectedCategory === 'custom';
  const activeCategoryData = CATEGORIES.find(c => c.value === selectedCategory);

  const handleCategorySelect = (cat) => {
    if (selectedCategory === cat.value) return;
    setSelectedCategory(cat.value);
    setSelectedTrade(null);
    setErrors(e => ({ ...e, category: null, trade: null }));
  };

  const handleTradeSelect = (trade) => {
    setSelectedTrade(trade);
    setErrors(e => ({ ...e, trade: null }));
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setLogoUrl(file_url);
    setUploading(false);
  };

  // Expose to parent: returns null if custom (blocks wizard progression)
  useImperativeHandle(ref, () => ({
    isCustomCategory: () => isCustom,
    selectCustomCategory: () => {
      setSelectedCategory('custom');
      setSelectedTrade(null);
      setErrors({});
    },
    getData() {
      if (isCustom) return null; // blocks Next in WizardCard
      const errs = {};
      if (!businessName.trim()) errs.name = 'Please enter your business name.';
      if (!selectedCategory) errs.category = 'Please choose a category.';
      if (!selectedTrade) errs.trade = 'Please choose the exact service.';
      if (Object.keys(errs).length) { setErrors(errs); return null; }

      return {
        business_name: businessName.trim(),
        business_type: selectedTrade.value,
        selected_category: selectedCategory,
        selected_trade: selectedTrade,
        tagline: tagline.trim(),
        logo_url: logoUrl,
        template: selectedTrade.template,
      };
    },
  }));

  const ALL_TILES = [...CATEGORIES, CUSTOM_CATEGORY];

  return (
    <StepShell title="Business Details" subtitle="This info appears on your quote page.">
      <div className="space-y-[20px]">
      {/* Business Name */}
      <div>
        <Label style={{ fontSize: '13px', fontWeight: 600, color: '#1E293B', fontFamily: 'Inter', letterSpacing: '0.02em', textTransform: 'uppercase' }}>
          Business Name <span className="text-red-400">*</span>
        </Label>
        <Input
          className="mt-1.5 rounded-xl focus:ring-blue-500"
          placeholder="e.g. Sunshine Cleaning Co."
          value={businessName}
          onChange={e => { setBusinessName(e.target.value); setErrors(er => ({ ...er, name: null })); }}
          autoFocus
        />
        {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
      </div>

      {/* Category Grid — 2 cols mobile, 4 cols desktop, always 8 tiles with consistent height */}
      <div style={{ marginTop: '20px' }}>
        <Label style={{ fontSize: '13px', fontWeight: 600, color: '#1E293B', fontFamily: 'Inter', letterSpacing: '0.02em', textTransform: 'uppercase' }}>
          Service category <span className="text-red-400">*</span>
        </Label>
        <p style={{ fontSize: '13px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', marginTop: '8px', marginBottom: '14px' }}>Select your primary service. We'll generate a tailored pricing structure.</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
          {ALL_TILES.map(cat => (
            <CategoryTile
              key={cat.value}
              cat={cat}
              isSelected={selectedCategory === cat.value}
              isCustom={cat.value === 'custom'}
              onClick={handleCategorySelect}
            />
          ))}
        </div>
        <AnimatePresence>
          {errors.category && (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
              style={{ fontSize: '12px', color: '#dc2626', marginTop: '10px', fontFamily: 'Inter' }}
            >
              {errors.category}
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {/* Trade Dropdown — normal categories only */}
      <AnimatePresence>
        {selectedCategory && !isCustom && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className="overflow-visible"
          >
            <div>
              <Label style={{ fontSize: '13px', fontWeight: 600, color: '#1E293B', fontFamily: 'Inter', letterSpacing: '0.02em', textTransform: 'uppercase' }}>
                Service Type <span className="text-red-400">*</span>
              </Label>
              <div className="mt-1.5">
                <TradeDropdown
                  trades={activeCategoryData?.trades || []}
                  value={selectedTrade?.value}
                  onChange={handleTradeSelect}
                />
              </div>
              {errors.trade && <p className="text-red-500 text-xs mt-1">{errors.trade}</p>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Request Panel */}
      <AnimatePresence>
        {isCustom && <CustomRequestPanel key="custom-panel" />}
      </AnimatePresence>

      {/* Logo Upload — only for normal flow */}
      {!isCustom && (
        <div style={{ marginTop: '24px' }}>
          <Label style={{ fontSize: '13px', fontWeight: 600, color: '#1E293B', fontFamily: 'Inter', letterSpacing: '0.02em', textTransform: 'uppercase' }}>
            Brand Logo <span className="text-slate-400 font-normal" style={{ fontSize: '12px', fontWeight: 400, textTransform: 'none' }}>(optional)</span>
          </Label>
          <div className="mt-1.5 flex items-center gap-3">
            {logoUrl ? (
              <>
                <img src={logoUrl} alt="Logo preview" className="w-12 h-12 rounded-xl object-contain border border-slate-200 bg-slate-50" />
                <button
                  type="button"
                  onClick={() => { setLogoUrl(''); if (fileInputRef.current) fileInputRef.current.value = ''; }}
                  className="text-xs text-red-400 hover:text-red-600 flex items-center gap-1 transition-colors"
                >
                  <X className="w-3 h-3" /> Remove
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="flex items-center gap-2 px-3 py-2.5 border border-dashed border-slate-200 rounded-xl text-sm text-slate-400 hover:border-indigo-300 hover:text-indigo-500 transition-colors"
              >
                {uploading ? (
                  <><div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" /> Uploading…</>
                ) : (
                  <><Upload className="w-4 h-4" /> Upload PNG, JPG or SVG</>
                )}
              </button>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/svg+xml"
              className="hidden"
              onChange={handleLogoUpload}
            />
          </div>
        </div>
      )}

      {/* Tagline — only for normal flow */}
      {!isCustom && (
        <div style={{ marginTop: '24px' }}>
          <Label style={{ fontSize: '13px', fontWeight: 600, color: '#1E293B', fontFamily: 'Inter', letterSpacing: '0.02em', textTransform: 'uppercase' }}>
            Tagline <span className="text-slate-400 font-normal" style={{ fontSize: '12px', fontWeight: 400, textTransform: 'none' }}>(optional)</span>
          </Label>
          <Input
            className="mt-1.5 rounded-xl"
            placeholder="e.g. Premium driveway paving in Toronto."
            value={tagline}
            onChange={e => setTagline(e.target.value)}
            maxLength={100}
          />
        </div>
      )}
      </div>
    </StepShell>
  );
});

export default StepBusinessDetails;