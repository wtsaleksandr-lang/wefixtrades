import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, X, Pencil, Check } from 'lucide-react';

const taStyle = (focused) => ({
  width: '100%', padding: '10px 12px', fontSize: 13, color: '#1E293B',
  background: '#ffffff', fontFamily: 'inherit', lineHeight: 1.5, resize: 'vertical',
  border: `1px solid ${focused ? '#2563eb' : 'rgba(15,23,42,0.13)'}`,
  borderRadius: 10, outline: 'none',
  boxShadow: focused ? '0 0 0 3px rgba(37,99,235,0.13)' : '0 2px 6px rgba(15,23,42,0.04)',
  transition: 'border-color 150ms ease, box-shadow 150ms ease',
});

function FocusTextarea({ value, onChange, placeholder, rows = 3 }) {
  const [focused, setFocused] = useState(false);
  return (
    <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows}
      style={taStyle(focused)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} />
  );
}

function ResultCard({ result, onAccept, onEdit }) {
  return (
    <div style={{ border: '1.5px solid rgba(37,99,235,0.25)', borderRadius: 14, overflow: 'hidden', background: '#ffffff', boxShadow: '0 4px 16px rgba(37,99,235,0.08)' }}>
      <div style={{ background: 'rgba(37,99,235,0.05)', padding: '12px 16px', borderBottom: '1px solid rgba(37,99,235,0.12)' }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#2563EB' }}>Generated pricing model</div>
      </div>
      <div style={{ padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { label: 'Type', value: result.pricingType },
          { label: 'Unit', value: result.unitName },
          { label: 'Base fee', value: result.baseFee ? `$${result.baseFee}` : '—' },
          { label: 'Per unit rate', value: result.perUnitRate ? `$${result.perUnitRate}` : '—' },
          { label: 'Minimum charge', value: result.minCharge ? `$${result.minCharge}` : '—' },
          { label: 'Output style', value: result.outputStyle },
        ].map(row => (
          <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
            <span style={{ fontSize: 12, color: '#64748B', flexShrink: 0 }}>{row.label}</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#1E293B', textAlign: 'right' }}>{row.value || '—'}</span>
          </div>
        ))}
        {(result.addOns || []).length > 0 && (
          <div>
            <div style={{ fontSize: 12, color: '#64748B', marginBottom: 5 }}>Add-ons</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {result.addOns.map((a, i) => (
                <div key={i} style={{ fontSize: 12, color: '#1E293B', background: '#f8fafc', borderRadius: 7, padding: '5px 10px' }}>
                  {a.name}: {a.type === 'pct' ? `+${a.value}%` : `+$${a.value}`}
                </div>
              ))}
            </div>
          </div>
        )}
        {result.notes && (
          <div style={{ fontSize: 11, color: '#94A3B8', fontStyle: 'italic', paddingTop: 4 }}>{result.notes}</div>
        )}
      </div>
      <div style={{ display: 'flex', gap: 8, padding: '12px 16px', borderTop: '1px solid rgba(15,23,42,0.06)' }}>
        <button
          type="button"
          onClick={onAccept}
          style={{ flex: 1, height: 42, borderRadius: 10, fontSize: 13, fontWeight: 700, color: '#ffffff', background: '#2563EB', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, transition: 'all 150ms' }}
        >
          <Check style={{ width: 15, height: 15 }} /> Accept
        </button>
        <button
          type="button"
          onClick={onEdit}
          style={{ flex: 1, height: 42, borderRadius: 10, fontSize: 13, fontWeight: 600, color: '#475569', background: '#f1f5f9', border: '1px solid rgba(15,23,42,0.1)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, transition: 'all 150ms' }}
        >
          <Pencil style={{ width: 13, height: 13 }} /> Edit fields
        </button>
      </div>
    </div>
  );
}

export default function AIMode({ tradeData, state, onChange, onEditInHybrid }) {
  const [status, setStatus] = useState('idle'); // idle | generating | done | error
  const [followUp, setFollowUp] = useState(null);
  const set = (key, val) => onChange({ ...state, [key]: val });

  const addAddon = () => {
    const addons = [...(state.aiAddons || []), { id: Date.now(), name: '', value: '', type: 'fixed' }];
    set('aiAddons', addons);
  };
  const updateAddon = (id, upd) => set('aiAddons', (state.aiAddons || []).map(a => a.id === id ? upd : a));
  const removeAddon = (id) => set('aiAddons', (state.aiAddons || []).filter(a => a.id !== id));

  const generate = async () => {
    if (!state.questionsText?.trim() || !state.formulaText?.trim()) return;
    setStatus('generating');
    setFollowUp(null);

    const prompt = `You are a pricing configuration generator for service businesses.

A ${tradeData.unitLabel}-based trade business answered:
Q1 "What do you ask customers before quoting?" → "${state.questionsText}"
Q2 "How do you calculate price?" → "${state.formulaText}"
Minimum charge: ${state.aiMinCharge || 'not specified'}
Add-ons: ${(state.aiAddons || []).map(a => `${a.name} +${a.type === 'pct' ? a.value + '%' : '$' + a.value}`).join(', ') || 'none'}

Produce a JSON pricing config. If the unit is ambiguous, set needsUnit=true with a clarifying question.

Return ONLY valid JSON matching this schema:
{
  "pricingType": "flat_rate|hourly|per_unit|base_per_unit|tiered_ranges",
  "unitName": "string",
  "baseFee": number_or_null,
  "perUnitRate": number_or_null,
  "minCharge": number_or_null,
  "outputStyle": "exact|price_range|starting_from|estimate",
  "addOns": [{"name":"string","type":"fixed|pct","value":number}],
  "notes": "short plain-English summary",
  "needsUnit": false,
  "followUpQuestion": null
}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          pricingType: { type: 'string' },
          unitName: { type: 'string' },
          baseFee: { type: 'number' },
          perUnitRate: { type: 'number' },
          minCharge: { type: 'number' },
          outputStyle: { type: 'string' },
          addOns: { type: 'array', items: { type: 'object' } },
          notes: { type: 'string' },
          needsUnit: { type: 'boolean' },
          followUpQuestion: { type: 'string' },
        },
      },
    });

    if (result?.needsUnit && result?.followUpQuestion) {
      setFollowUp(result.followUpQuestion);
      setStatus('idle');
    } else {
      set('generatedResult', result);
      setStatus('done');
    }
  };

  const handleAccept = () => {
    // result is already saved in state.generatedResult — parent reads it
    set('accepted', true);
  };

  const handleEditInHybrid = () => {
    onEditInHybrid(state.generatedResult);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ padding: '12px 14px', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.07)', borderRadius: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#1E293B', marginBottom: 3 }}>Assisted Setup</div>
        <div style={{ fontSize: 12, color: '#64748B' }}>Answer a few questions. We'll build the quote logic for you.</div>
      </div>

      {/* Q1 */}
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 6 }}>
          What do you ask customers before you quote? <span style={{ color: '#EF4444' }}>*</span>
        </div>
        <FocusTextarea
          value={state.questionsText || ''}
          onChange={v => set('questionsText', v)}
          placeholder={`Square footage, number of rooms, stairs, urgency, distance, material type…`}
          rows={3}
        />
      </div>

      {/* Q2 */}
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 6 }}>
          How do you usually calculate price? <span style={{ color: '#EF4444' }}>*</span>
        </div>
        <FocusTextarea
          value={state.formulaText || ''}
          onChange={v => set('formulaText', v)}
          placeholder={`e.g. (sqft × 2.75) + stairs × 50 + base 150. Deep clean +75.`}
          rows={3}
        />
      </div>

      {/* Min charge */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: '#64748B', flexShrink: 0 }}>Minimum charge (optional)</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1 }}>
          <span style={{ fontSize: 13, color: '#94A3B8' }}>$</span>
          <input
            type="number" min={0} value={state.aiMinCharge ?? ''}
            onChange={e => set('aiMinCharge', e.target.value)}
            placeholder="0"
            style={{ flex: 1, height: 40, padding: '0 10px', fontSize: 13, color: '#1E293B', background: '#ffffff', border: '1px solid rgba(15,23,42,0.13)', borderRadius: 9, outline: 'none' }}
          />
        </div>
      </div>

      {/* Add-ons */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: '#64748B' }}>Add-ons you offer (optional)</div>
          <button type="button" onClick={addAddon} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 600, color: '#2563EB', background: 'rgba(37,99,235,0.07)', border: '1.5px solid rgba(37,99,235,0.18)', borderRadius: 7, padding: '4px 9px', cursor: 'pointer' }}>
            <Plus style={{ width: 11, height: 11 }} /> Add
          </button>
        </div>
        {(state.aiAddons || []).map(a => (
          <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
            <input type="text" value={a.name} onChange={e => updateAddon(a.id, { ...a, name: e.target.value })} placeholder="Add-on name"
              style={{ flex: 2, height: 36, padding: '0 10px', fontSize: 12, color: '#1E293B', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.1)', borderRadius: 8, outline: 'none' }} />
            <input type="number" value={a.value} onChange={e => updateAddon(a.id, { ...a, value: e.target.value })} placeholder="$"
              style={{ width: 60, height: 36, padding: '0 8px', fontSize: 12, textAlign: 'center', color: '#1E293B', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.1)', borderRadius: 8, outline: 'none' }} />
            <button type="button" onClick={() => removeAddon(a.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CBD5E1' }}>
              <X style={{ width: 14, height: 14 }} />
            </button>
          </div>
        ))}
      </div>

      {/* Follow-up inline */}
      {followUp && (
        <div style={{ padding: '12px 14px', background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.25)', borderRadius: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#92400E', marginBottom: 6 }}>One quick detail:</div>
          <div style={{ fontSize: 13, color: '#1E293B', marginBottom: 10 }}>{followUp}</div>
          <input
            type="text"
            value={state.followUpAnswer || ''}
            onChange={e => set('followUpAnswer', e.target.value)}
            placeholder="Your answer…"
            style={{ width: '100%', height: 40, padding: '0 12px', fontSize: 13, color: '#1E293B', background: '#fff', border: '1px solid rgba(15,23,42,0.13)', borderRadius: 9, outline: 'none' }}
          />
        </div>
      )}

      {/* Generate button */}
      {status !== 'done' && (
        <button
          type="button"
          onClick={generate}
          disabled={status === 'generating' || !state.questionsText?.trim() || !state.formulaText?.trim()}
          style={{
            width: '100%', height: 48, borderRadius: 12, fontSize: 14, fontWeight: 700,
            color: '#ffffff', background: '#2563EB', border: 'none', cursor: 'pointer',
            opacity: (status === 'generating' || !state.questionsText?.trim() || !state.formulaText?.trim()) ? 0.5 : 1,
            transition: 'opacity 150ms',
          }}
        >
          {status === 'generating' ? 'Building your pricing model…' : 'Generate pricing model'}
        </button>
      )}

      {/* Result card */}
      {status === 'done' && state.generatedResult && (
        <ResultCard
          result={state.generatedResult}
          onAccept={handleAccept}
          onEdit={handleEditInHybrid}
        />
      )}

      {state.accepted && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderRadius: 10, background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.2)' }}>
          <Check style={{ width: 15, height: 15, color: '#10B981' }} />
          <span style={{ fontSize: 13, fontWeight: 600, color: '#059669' }}>Pricing model accepted.</span>
        </div>
      )}
    </div>
  );
}