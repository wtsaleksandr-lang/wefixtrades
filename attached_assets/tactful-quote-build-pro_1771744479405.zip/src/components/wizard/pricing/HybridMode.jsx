import React, { useState } from 'react';
import { Plus, X, ChevronDown } from 'lucide-react';
import { HYBRID_STRUCTURES, OUTPUT_STYLES } from './tradeData';

const inputStyle = (focused) => ({
  width: '100%', height: 44, padding: '0 12px', fontSize: 13, fontWeight: 500,
  color: '#1E293B', background: '#ffffff',
  border: `1px solid ${focused ? '#2563eb' : 'rgba(15,23,42,0.13)'}`,
  borderRadius: 10, outline: 'none',
  boxShadow: focused ? '0 0 0 3px rgba(37,99,235,0.13)' : '0 2px 6px rgba(15,23,42,0.04)',
  transition: 'border-color 150ms ease, box-shadow 150ms ease',
});

function NumInput({ prefix, suffix, value, onChange, placeholder = '0' }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {prefix && <span style={{ fontSize: 13, color: '#94A3B8', flexShrink: 0 }}>{prefix}</span>}
      <input type="number" min={0} value={value ?? ''} onChange={e => onChange(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder={placeholder}
        style={inputStyle(focused)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} />
      {suffix && <span style={{ fontSize: 13, color: '#94A3B8', flexShrink: 0 }}>{suffix}</span>}
    </div>
  );
}

function TextInput({ value, onChange, placeholder }) {
  const [focused, setFocused] = useState(false);
  return (
    <input type="text" value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={inputStyle(focused)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} />
  );
}

function FieldRow({ label, helper, children }) {
  return (
    <div>
      <div style={{ fontSize: 12, fontWeight: 500, color: '#64748B', marginBottom: 6 }}>{label}</div>
      {children}
      {helper && <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 4 }}>{helper}</div>}
    </div>
  );
}

function RadioGroup({ options, value, onChange }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {options.map(o => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          style={{
            padding: '7px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600,
            border: `1.5px solid ${value === o.id ? '#2563EB' : 'rgba(15,23,42,0.1)'}`,
            background: value === o.id ? 'rgba(37,99,235,0.07)' : '#ffffff',
            color: value === o.id ? '#2563EB' : '#64748B',
            cursor: 'pointer', transition: 'all 150ms ease',
          }}
        >{o.label}</button>
      ))}
    </div>
  );
}

function AddOnCard({ addon, onChange, onRemove }) {
  return (
    <div style={{ background: '#ffffff', border: '1px solid rgba(15,23,42,0.09)', borderRadius: 10, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <input
          type="text"
          value={addon.name}
          onChange={e => onChange({ ...addon, name: e.target.value })}
          placeholder="Add-on name (e.g. Deep Clean)"
          style={{ flex: 1, height: 36, padding: '0 10px', fontSize: 12, color: '#1E293B', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.1)', borderRadius: 8, outline: 'none' }}
        />
        <button type="button" onClick={onRemove} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CBD5E1', padding: 2 }}>
          <X style={{ width: 14, height: 14 }} />
        </button>
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <button type="button" onClick={() => onChange({ ...addon, type: 'fixed' })}
          style={{ padding: '4px 10px', borderRadius: 7, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: `1.5px solid ${addon.type === 'fixed' ? '#2563EB' : 'rgba(15,23,42,0.1)'}`, background: addon.type === 'fixed' ? 'rgba(37,99,235,0.07)' : '#f8fafc', color: addon.type === 'fixed' ? '#2563EB' : '#64748B', transition: 'all 120ms' }}>
          +$ fixed
        </button>
        <button type="button" onClick={() => onChange({ ...addon, type: 'pct' })}
          style={{ padding: '4px 10px', borderRadius: 7, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: `1.5px solid ${addon.type === 'pct' ? '#2563EB' : 'rgba(15,23,42,0.1)'}`, background: addon.type === 'pct' ? 'rgba(37,99,235,0.07)' : '#f8fafc', color: addon.type === 'pct' ? '#2563EB' : '#64748B', transition: 'all 120ms' }}>
          +% of total
        </button>
        <input
          type="number"
          min={0}
          value={addon.value ?? ''}
          onChange={e => onChange({ ...addon, value: e.target.value })}
          placeholder={addon.type === 'pct' ? '10' : '50'}
          style={{ width: 70, height: 32, padding: '0 8px', fontSize: 12, color: '#1E293B', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.1)', borderRadius: 8, outline: 'none', textAlign: 'center' }}
        />
        <span style={{ fontSize: 12, color: '#94A3B8' }}>{addon.type === 'pct' ? '%' : '$'}</span>
      </div>
    </div>
  );
}

export default function HybridMode({ tradeData, state, onChange }) {
  const [advOpen, setAdvOpen] = useState(false);
  const set = (key, val) => onChange({ ...state, [key]: val });

  const showBase = ['base_per_unit', 'custom_mixed'].includes(state.structure);
  const showPerUnit = !['flat_rate', 'tiered_ranges'].includes(state.structure);
  const showFlatRate = state.structure === 'flat_rate';

  const addAddon = () => {
    const addons = [...(state.addons || []), { id: Date.now(), name: '', type: 'fixed', value: '' }];
    set('addons', addons);
  };

  const updateAddon = (id, updated) => {
    set('addons', (state.addons || []).map(a => a.id === id ? updated : a));
  };

  const removeAddon = (id) => {
    set('addons', (state.addons || []).filter(a => a.id !== id));
  };

  const diffTiers = state.diffTiers || [
    { label: 'Standard', mult: 1.0 },
    { label: 'Moderate', mult: 1.2 },
    { label: 'Heavy', mult: 1.5 },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

      {/* Structure */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8', marginBottom: 10 }}>Pricing structure</div>
        <RadioGroup options={HYBRID_STRUCTURES} value={state.structure} onChange={v => set('structure', v)} />
      </div>

      {/* Core numbers */}
      <div style={{ background: '#f8fafc', border: '1px solid rgba(15,23,42,0.07)', borderRadius: 12, padding: '14px 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8' }}>Your numbers</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 14px' }}>
          {showBase && (
            <FieldRow label="Base / set-up fee">
              <NumInput prefix="$" value={state.baseFee} onChange={v => set('baseFee', v)} placeholder="e.g. 150" />
            </FieldRow>
          )}
          {showFlatRate && (
            <FieldRow label="Flat rate per job">
              <NumInput prefix="$" value={state.perUnitRate} onChange={v => set('perUnitRate', v)} placeholder="e.g. 300" />
            </FieldRow>
          )}
          {showPerUnit && (
            <>
              <FieldRow label="Unit name">
                <TextInput value={state.unitName} onChange={v => set('unitName', v)} placeholder={tradeData.unitLabel} />
              </FieldRow>
              <FieldRow label={`Price per ${state.unitName || tradeData.unitLabel}`}>
                <NumInput prefix="$" value={state.perUnitRate} onChange={v => set('perUnitRate', v)} placeholder="e.g. 45" />
              </FieldRow>
            </>
          )}
          <FieldRow label="Minimum charge">
            <NumInput prefix="$" value={state.minCharge} onChange={v => set('minCharge', v)} placeholder="0" />
          </FieldRow>
        </div>
      </div>

      {/* Add-ons */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8' }}>Add-ons <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0, color: '#CBD5E1', fontSize: 11 }}>(optional)</span></div>
          <button type="button" onClick={addAddon} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: '#2563EB', background: 'rgba(37,99,235,0.07)', border: '1.5px solid rgba(37,99,235,0.2)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', transition: 'all 120ms' }}>
            <Plus style={{ width: 13, height: 13 }} /> Add add-on
          </button>
        </div>
        {(state.addons || []).length === 0 && (
          <div style={{ fontSize: 12, color: '#CBD5E1', textAlign: 'center', padding: '12px 0' }}>No add-ons yet.</div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {(state.addons || []).map(a => (
            <AddOnCard key={a.id} addon={a} onChange={u => updateAddon(a.id, u)} onRemove={() => removeAddon(a.id)} />
          ))}
        </div>
      </div>

      {/* Difficulty toggle */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#1E293B' }}>Adjust price by job difficulty</div>
            <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 2 }}>Add a multiplier for harder jobs</div>
          </div>
          <button
            type="button"
            onClick={() => set('useDifficulty', !state.useDifficulty)}
            style={{
              width: 44, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
              background: state.useDifficulty ? '#2563EB' : '#E2E8F0',
              position: 'relative', transition: 'background 200ms ease', flexShrink: 0,
            }}
          >
            <div style={{
              position: 'absolute', top: 3, left: state.useDifficulty ? 23 : 3,
              width: 18, height: 18, borderRadius: '50%', background: '#fff',
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left 200ms ease',
            }} />
          </button>
        </div>
        {state.useDifficulty && (
          <div style={{ marginTop: 12, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            {diffTiers.map((tier, i) => (
              <div key={i} style={{ background: '#f8fafc', border: '1px solid rgba(15,23,42,0.08)', borderRadius: 10, padding: '10px 10px', textAlign: 'center' }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#475569', marginBottom: 6 }}>{tier.label}</div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                  <input
                    type="number"
                    min={0.5}
                    step={0.1}
                    value={tier.mult}
                    onChange={e => {
                      const updated = diffTiers.map((t, j) => j === i ? { ...t, mult: parseFloat(e.target.value) || t.mult } : t);
                      set('diffTiers', updated);
                    }}
                    style={{ width: 52, height: 32, fontSize: 13, fontWeight: 700, color: '#1E293B', border: '1px solid rgba(15,23,42,0.13)', borderRadius: 7, outline: 'none', textAlign: 'center', background: '#fff' }}
                  />
                  <span style={{ fontSize: 12, color: '#94A3B8' }}>×</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Output style */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8', marginBottom: 10 }}>Quote output style</div>
        <RadioGroup options={OUTPUT_STYLES} value={state.outputStyle} onChange={v => set('outputStyle', v)} />
      </div>

      {/* Advanced */}
      <div style={{ border: '1px solid rgba(15,23,42,0.08)', borderRadius: 12, overflow: 'hidden' }}>
        <button
          type="button"
          onClick={() => setAdvOpen(o => !o)}
          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', background: advOpen ? 'rgba(37,99,235,0.04)' : '#f8fafc', border: 'none', cursor: 'pointer' }}
        >
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8' }}>Advanced (optional)</span>
          <ChevronDown style={{ width: 15, height: 15, color: '#CBD5E1', transform: advOpen ? 'rotate(180deg)' : 'none', transition: 'transform 200ms' }} />
        </button>
        {advOpen && (
          <div style={{ padding: '12px 14px', borderTop: '1px solid rgba(15,23,42,0.07)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 14px' }}>
            {[
              { key: 'travelFee', label: 'Distance / travel fee', prefix: '$' },
              { key: 'afterHoursMult', label: 'After-hours multiplier', prefix: '×' },
              { key: 'callUsThreshold', label: '"Call us" above ($)', prefix: '$' },
            ].map(f => (
              <div key={f.key}>
                <div style={{ fontSize: 12, fontWeight: 500, color: '#64748B', marginBottom: 6 }}>{f.label}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: 13, color: '#94A3B8', flexShrink: 0 }}>{f.prefix}</span>
                  <input
                    type="number" min={0} value={state[f.key] ?? ''}
                    onChange={e => set(f.key, e.target.value)}
                    placeholder="—"
                    style={{ flex: 1, height: 40, padding: '0 10px', fontSize: 13, color: '#1E293B', background: '#f8fafc', border: '1px solid rgba(15,23,42,0.1)', borderRadius: 9, outline: 'none' }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}