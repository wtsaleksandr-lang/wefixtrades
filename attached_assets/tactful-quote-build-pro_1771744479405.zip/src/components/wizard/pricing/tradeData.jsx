// Trade-specific data for all 3 pricing modes

export const TRADE_DATA = {
  cleaning: {
    unitLabel: 'room',
    unitSuggestions: ['room', 'sq ft', 'hour', 'bedroom'],
    prebuiltModels: [
      {
        id: 'per_room',
        label: 'Per room / space',
        bullets: ['Price set per bedroom or space type', 'Add-ons for deep clean, windows, oven', 'Optional frequency discounts'],
        defaults: { baseFee: 0, perUnitRate: 100, unitName: 'bedroom', minCharge: 80 },
      },
      {
        id: 'flat_rate',
        label: 'Flat rate by home size',
        bullets: ['Fixed price per home size tier', 'Studio → 4+ bedrooms', 'Simple for customers to understand'],
        defaults: { baseFee: 0, perUnitRate: 0, unitName: 'home', minCharge: 80 },
      },
      {
        id: 'hourly',
        label: 'Hourly',
        bullets: ['Price per hour of cleaning', 'Minimum hours apply', 'Add-ons billed at same rate'],
        defaults: { baseFee: 0, perUnitRate: 45, unitName: 'hour', minCharge: 90 },
      },
    ],
    hybridDefaults: { structure: 'flat_rate', unitName: 'bedroom', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'price_range',
  },
  lawn_care: {
    unitLabel: 'sq ft',
    unitSuggestions: ['sq ft', 'acre', 'visit', 'hour'],
    prebuiltModels: [
      {
        id: 'tiered_ranges',
        label: 'Tiered by yard size',
        bullets: ['Small / Medium / Large / XL pricing tiers', 'Clean ranges for any property', 'Add-ons for edging, fertilizing, etc.'],
        defaults: { baseFee: 0, perUnitRate: 0, unitName: 'yard', minCharge: 35 },
      },
      {
        id: 'per_sqft',
        label: 'Per sq ft',
        bullets: ['Price calculated on lawn area', 'Scales automatically with property size', 'Accurate for large properties'],
        defaults: { baseFee: 0, perUnitRate: 0.008, unitName: 'sq ft', minCharge: 35 },
      },
      {
        id: 'flat_rate',
        label: 'Flat rate per visit',
        bullets: ['Single price per service visit', 'Easy to communicate', 'Discounts for weekly/bi-weekly'],
        defaults: { baseFee: 0, perUnitRate: 55, unitName: 'visit', minCharge: 35 },
      },
    ],
    hybridDefaults: { structure: 'tiered_ranges', unitName: 'sq ft', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'price_range',
  },
  roofing: {
    unitLabel: 'sq ft',
    unitSuggestions: ['sq ft', 'square (100 sqft)', 'panel', 'linear ft'],
    prebuiltModels: [
      {
        id: 'base_per_sqft',
        label: 'Base + per sq ft',
        bullets: ['Set-up / mobilization base fee', 'Material cost per square foot', 'Add-ons for tear-off, gutters, skylights'],
        defaults: { baseFee: 500, perUnitRate: 3.5, unitName: 'sq ft', minCharge: 1500 },
      },
      {
        id: 'per_sqft',
        label: 'Per sq ft only',
        bullets: ['All-in rate per square foot', 'Different rates by material type', 'Simple and transparent'],
        defaults: { baseFee: 0, perUnitRate: 4.5, unitName: 'sq ft', minCharge: 1000 },
      },
      {
        id: 'tiered_ranges',
        label: 'Tiered by roof area',
        bullets: ['Small / medium / large roof tiers', 'Easier for customer to self-qualify', 'Add-ons for complexity'],
        defaults: { baseFee: 0, perUnitRate: 0, unitName: 'sq ft', minCharge: 1500 },
      },
    ],
    hybridDefaults: { structure: 'base_per_unit', unitName: 'sq ft', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'price_range',
  },
  moving: {
    unitLabel: 'bedroom',
    unitSuggestions: ['bedroom', 'hour', 'mile', 'item'],
    prebuiltModels: [
      {
        id: 'base_per_size',
        label: 'Base by home size',
        bullets: ['Fixed base price per bedroom count', 'Distance multipliers for long moves', 'Add-ons for packing, piano, storage'],
        defaults: { baseFee: 350, perUnitRate: 0, unitName: 'bedroom', minCharge: 200 },
      },
      {
        id: 'hourly',
        label: 'Hourly rate',
        bullets: ['Minimum hours apply', 'Travel time included', 'Add-ons billed separately'],
        defaults: { baseFee: 0, perUnitRate: 120, unitName: 'hour', minCharge: 200 },
      },
      {
        id: 'flat_rate',
        label: 'Flat rate per move',
        bullets: ['Single all-in price per job', 'Based on estimated size', 'Simplest for customers'],
        defaults: { baseFee: 0, perUnitRate: 500, unitName: 'move', minCharge: 200 },
      },
    ],
    hybridDefaults: { structure: 'base_per_unit', unitName: 'bedroom', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'price_range',
  },
  web_design: {
    unitLabel: 'page',
    unitSuggestions: ['page', 'hour', 'project', 'feature'],
    prebuiltModels: [
      {
        id: 'fixed_package',
        label: 'Fixed package',
        bullets: ['Base price for standard package', 'Extra pages priced individually', 'Add-ons for e-commerce, SEO, CMS'],
        defaults: { baseFee: 800, perUnitRate: 80, unitName: 'page', minCharge: 500 },
      },
      {
        id: 'hourly',
        label: 'Hourly',
        bullets: ['Rate per hour of development', 'Estimate range shown to customer', 'Milestone-based billing'],
        defaults: { baseFee: 0, perUnitRate: 95, unitName: 'hour', minCharge: 500 },
      },
      {
        id: 'tiered_ranges',
        label: 'Tiered packages',
        bullets: ['Starter / Growth / Premium tiers', 'Clear scope per tier', 'Easy upsell path'],
        defaults: { baseFee: 0, perUnitRate: 0, unitName: 'project', minCharge: 500 },
      },
    ],
    hybridDefaults: { structure: 'base_per_unit', unitName: 'page', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'exact',
  },
  default: {
    unitLabel: 'unit',
    unitSuggestions: ['unit', 'hour', 'item', 'sq ft'],
    prebuiltModels: [
      {
        id: 'flat_rate',
        label: 'Flat rate',
        bullets: ['Fixed price per job', 'Simple and predictable', 'Optional add-ons'],
        defaults: { baseFee: 0, perUnitRate: 150, unitName: 'job', minCharge: 0 },
      },
      {
        id: 'hourly',
        label: 'Hourly',
        bullets: ['Price per hour of work', 'Minimum applies', 'Add-ons billed separately'],
        defaults: { baseFee: 0, perUnitRate: 75, unitName: 'hour', minCharge: 0 },
      },
      {
        id: 'base_per_unit',
        label: 'Base + per unit',
        bullets: ['Set-up fee plus variable rate', 'Scales with job size', 'Transparent for customers'],
        defaults: { baseFee: 100, perUnitRate: 25, unitName: 'unit', minCharge: 0 },
      },
    ],
    hybridDefaults: { structure: 'flat_rate', unitName: 'unit', baseFee: '', perUnitRate: '', minCharge: '' },
    outputStyleDefault: 'price_range',
  },
};

export function getTradeData(templateId) {
  return TRADE_DATA[templateId] || TRADE_DATA.default;
}

export const HYBRID_STRUCTURES = [
  { id: 'flat_rate', label: 'Flat rate' },
  { id: 'hourly', label: 'Per hour' },
  { id: 'per_unit', label: 'Per unit' },
  { id: 'base_per_unit', label: 'Base + per unit' },
  { id: 'tiered_ranges', label: 'Tiered ranges' },
  { id: 'custom_mixed', label: 'Custom / Mixed' },
];

export const OUTPUT_STYLES = [
  { id: 'exact', label: 'Exact price' },
  { id: 'price_range', label: 'Price range' },
  { id: 'starting_from', label: 'Starting from' },
  { id: 'estimate', label: 'Estimate (confirmed after review)' },
];