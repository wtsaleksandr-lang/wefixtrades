import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const inputStyle = (focused) => ({
  width: '100%',
  height: 44,
  padding: '0 12px',
  fontSize: 13,
  fontWeight: 500,
  color: '#1E293B',
  background: '#ffffff',
  border: `1px solid ${focused ? '#2563eb' : 'rgba(15,23,42,0.13)'}`,
  borderRadius: 10,
  outline: 'none',
  boxShadow: focused ? '0 0 0 3px rgba(37,99,235,0.13)' : '0 2px 6px rgba(15,23,42,0.04)',
  transition: 'border-color 150ms ease, box-shadow 150ms ease',
});

function NumInput({ prefix, suffix, value, onChange, placeholder = '0' }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {prefix && <span style={{ fontSize: 13, color: '#94A3B8', flexShrink: 0 }}>{prefix}</span>}
      <input
        type="number"
        min={0}
        value={value ?? ''}
        onChange={e => onChange(e.target.value === '' ? '' : parseFloat(e.target.value))}
        placeholder={placeholder}
        style={inputStyle(focused)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />
      {suffix && <span style={{ fontSize: 13, color: '#94A3B8', flexShrink: 0 }}>{suffix}</span>}
    </div>
  );
}

function FieldRow({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 12, fontWeight: 500, color: '#64748B', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

function calcExample(model, vals) {
  const base = parseFloat(vals.baseFee) || 0;
  const rate = parseFloat(vals.perUnitRate) || 0;
  const min = parseFloat(vals.minCharge) || 0;

  if (model?.id === 'hourly') {
    const low = Math.max(min, base + rate * 1);
    const high = base + rate * 3;
    return high > 0 ? `$${low.toFixed(0)}–$${high.toFixed(0)}` : null;
  }
  if (model?.id === 'per_sqft' || model?.id === 'per_unit') {
    const low = Math.max(min, base + rate * 100);
    const high = base + rate * 300;
    return high > 0 ? `$${low.toFixed(0)}–$${high.toFixed(0)}` : null;
  }
  if (model?.id === 'base_per_sqft' || model?.id === 'base_per_size' || model?.id === 'base_per_unit') {
    const ex = Math.max(min, base + rate * 200);
    return ex > 0 ? `from $${ex.toFixed(0)}` : null;
  }
  if (base > 0 || rate > 0) {
    const ex = Math.max(min, base + rate);
    return `from $${ex.toFixed(0)}`;
  }
  return null;
}

export default function PrebuiltMode({ tradeData, state, onChange }) {
  const { prebuiltModels } = tradeData;
  const selectedModel = prebuiltModels.find(m => m.id === state.modelId) || prebuiltModels[0];

  const handleModelChange = (id) => {
    const m = prebuiltModels.find(pm => pm.id === id);
    onChange({
      ...state,
      modelId: id,
      baseFee: m.defaults.baseFee,
      perUnitRate: m.defaults.perUnitRate,
      unitName: m.defaults.unitName,
      minCharge: m.defaults.minCharge,
    });
  };

  const set = (key, val) => onChange({ ...state, [key]: val });
  const example = calcExample(selectedModel, state);

  const showBase = !['per_sqft', 'per_unit', 'hourly'].includes(selectedModel?.id);
  const showPerUnit = !['tiered_ranges', 'base_per_size', 'flat_rate'].includes(selectedModel?.id) || selectedModel?.id === 'flat_rate';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Model selector */}
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 8 }}>Pricing model</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {prebuiltModels.map(m => (
            <button
              key={m.id}
              type="button"
              onClick={() => handleModelChange(m.id)}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: 12,
                padding: '12px 14px',
                borderRadius: 12,
                border: `1.5px solid ${state.modelId === m.id ? '#2563EB' : 'rgba(15,23,42,0.1)'}`,
                background: state.modelId === m.id ? 'rgba(37,99,235,0.04)' : '#ffffff',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 150ms ease',
              }}
            >
              <div
                style={{
                  width: 18, height: 18, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                  border: `2px solid ${state.modelId === m.id ? '#2563EB' : '#CBD5E1'}`,
                  background: state.modelId === m.id ? '#2563EB' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 150ms ease',
                }}
              >
                {state.modelId === m.id && <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff' }} />}
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#1E293B' }}>{m.label}</div>
                <ul style={{ margin: '4px 0 0', padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {m.bullets.map((b, i) => (
                    <li key={i} style={{ fontSize: 11, color: '#64748B', display: 'flex', alignItems: 'flex-start', gap: 5 }}>
                      <span style={{ color: '#94A3B8', flexShrink: 0 }}>·</span>{b}
                    </li>
                  ))}
                </ul>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Fields */}
      <div style={{ background: '#f8fafc', border: '1px solid rgba(15,23,42,0.07)', borderRadius: 12, padding: '14px 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: '#94A3B8' }}>Your rates</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 14px' }}>
          {showBase && (
            <FieldRow label="Base fee (optional)">
              <NumInput prefix="$" value={state.baseFee} onChange={v => set('baseFee', v)} placeholder="0" />
            </FieldRow>
          )}
          {showPerUnit && (
            <FieldRow label={`Price per ${state.unitName || 'unit'}`}>
              <NumInput prefix="$" value={state.perUnitRate} onChange={v => set('perUnitRate', v)} placeholder="0" />
            </FieldRow>
          )}
          <FieldRow label="Minimum charge">
            <NumInput prefix="$" value={state.minCharge} onChange={v => set('minCharge', v)} placeholder="0" />
          </FieldRow>
        </div>
      </div>

      {/* Example preview */}
      {example && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderRadius: 10, background: 'rgba(37,99,235,0.05)', border: '1px solid rgba(37,99,235,0.12)' }}>
          <span style={{ fontSize: 11, color: '#2563EB', fontWeight: 600 }}>Example quote</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#1E293B' }}>{example}</span>
        </div>
      )}
    </div>
  );
}