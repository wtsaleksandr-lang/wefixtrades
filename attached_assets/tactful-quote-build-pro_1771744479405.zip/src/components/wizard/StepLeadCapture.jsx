import React, { useState, useImperativeHandle, forwardRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import StepShell from './StepShell';

const FIELDS = [
  { id: 'name', label: 'Full Name', defaultOn: true },
  { id: 'email', label: 'Email Address', defaultOn: true },
  { id: 'phone', label: 'Phone Number', defaultOn: true },
  { id: 'company', label: 'Company / Business', defaultOn: false },
];

const StepLeadCapture = forwardRef(function StepLeadCapture({ data }, ref) {
  const [captureFields, setCaptureFields] = useState(data.lead_capture_fields || ['name', 'email', 'phone']);
  const [requiredFields, setRequiredFields] = useState(data.lead_required_fields || ['name', 'email']);
  const [thankYou, setThankYou] = useState(data.lead_thank_you_message || "Thanks! We'll be in touch within 24 hours.");
  const [ctaText, setCtaText] = useState(data.cta_button_text || 'Get My Free Quote');

  const toggleCapture = (id) => {
    if (captureFields.includes(id)) {
      setCaptureFields(p => p.filter(f => f !== id));
      setRequiredFields(p => p.filter(f => f !== id));
    } else {
      setCaptureFields(p => [...p, id]);
    }
  };

  const toggleRequired = (id) => {
    setRequiredFields(p => p.includes(id) ? p.filter(f => f !== id) : [...p, id]);
  };

  useImperativeHandle(ref, () => ({
    getData() {
      return {
        lead_capture_fields: captureFields,
        lead_required_fields: requiredFields,
        lead_thank_you_message: thankYou,
        cta_button_text: ctaText,
      };
    }
  }));

  return (
    <StepShell title="Lead form builder" subtitle="Choose what info to collect when someone requests a quote.">
      <div className="space-y-5">
      {/* Fields */}
       <div className="space-y-3">
        {FIELDS.map(field => {
          const isOn = captureFields.includes(field.id);
          const isReq = requiredFields.includes(field.id);
          return (
            <div
              key={field.id}
              className={`flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${isOn ? 'border-indigo-200 bg-indigo-50/50' : 'border-slate-200 bg-slate-50'}`}
            >
              <div className="flex items-center gap-3">
                <Switch checked={isOn} onCheckedChange={() => toggleCapture(field.id)} />
                <span className={`text-sm font-medium ${isOn ? 'text-slate-800' : 'text-slate-400'}`}>{field.label}</span>
              </div>
              {isOn && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Required</span>
                  <Switch checked={isReq} onCheckedChange={() => toggleRequired(field.id)} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* CTA text */}
      <div>
        <Label className="text-xs text-slate-500 uppercase tracking-wide">CTA Button Text</Label>
        <Input className="mt-1" value={ctaText} onChange={e => setCtaText(e.target.value)} placeholder="Get My Free Quote" />
      </div>

      {/* Thank you */}
      <div>
        <Label className="text-xs text-slate-500 uppercase tracking-wide">Thank You Message</Label>
        <Textarea className="mt-1" value={thankYou} onChange={e => setThankYou(e.target.value)} rows={2} />
      </div>
      </div>
    </StepShell>
  );
});

export default StepLeadCapture;