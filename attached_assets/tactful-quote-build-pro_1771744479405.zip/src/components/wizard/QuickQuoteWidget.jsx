/**
 * QuickQuoteWidget — fully self-contained, portable wizard widget.
 *
 * Safe for use in:
 *   - iframe embeds
 *   - div containers on external sites
 *   - any website builder (Wix, Squarespace, Webflow, etc.)
 *
 * Has zero dependency on page-level layout, background, or global styles.
 * Height auto-adjusts to content.
 */

import React from 'react';
import { base44 } from '@/api/base44Client';
import WizardCard from './WizardCard';

const onInvoke = async (functionName, payload) => {
  const res = await base44.functions.invoke(functionName, payload);
  return res.data;
};

export default function QuickQuoteWidget() {
  return (
    <div
      style={{
        width: '100%',
        maxWidth: '960px',
        margin: '0 auto',
        background: 'transparent',
        border: 'none',
        outline: 'none',
        boxSizing: 'border-box',
      }}
    >
      <WizardCard embed={false} onInvoke={onInvoke} />
    </div>
  );
}