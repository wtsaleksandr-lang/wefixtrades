import React, { useState, useImperativeHandle, forwardRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import StepShell from './StepShell';
import { getTemplate } from '../calculator/templateConfig';
import { Copy, Check, ExternalLink, Globe, Code2, Wrench, ChevronDown, ChevronUp, Loader2, CheckCircle2, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { AnimatePresence, motion } from 'framer-motion';

function slugify(str) {
  return (str || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      type="button"
      onClick={copy}
      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95"
      style={{ background: copied ? 'rgba(16,185,129,0.1)' : 'rgba(2,132,199,0.08)', color: copied ? '#059669' : '#0284c7', border: `1px solid ${copied ? 'rgba(16,185,129,0.25)' : 'rgba(2,132,199,0.2)'}` }}
    >
      {copied ? <><Check className="w-3 h-3" /> Copied</> : <><Copy className="w-3 h-3" /> Copy</>}
    </button>
  );
}

const PLATFORMS = ['WordPress', 'Wix', 'Shopify', 'Squarespace', 'Other'];

const platformInstructions = {
  WordPress: [
    'Go to your page editor and add a Custom HTML block.',
    'Paste the installation code below into the block.',
    'Save and preview — the quote tool will appear inline.',
  ],
  Wix: [
    'Open the Wix Editor and click Add → Embed → Custom Code.',
    'Paste the installation code into the HTML box.',
    'Click Apply and publish your site.',
  ],
  Shopify: [
    'Go to Online Store → Themes → Edit Code.',
    'Open the page template where you want the tool.',
    'Paste the installation code in the desired location.',
  ],
  Squarespace: [
    'Edit the page and add a Code Block.',
    'Paste the installation code into the block.',
    'Save and publish.',
  ],
  Other: [
    'Copy the installation code below.',
    'Paste it anywhere inside the <body> of your page.',
    'The quote tool will render automatically.',
  ],
};

const StepLaunch = forwardRef(function StepLaunch({ data }, ref) {
  const [customSlug, setCustomSlug] = useState(data.custom_slug || '');
  const [ownerEmail, setOwnerEmail] = useState(data.owner_email || '');
  const [showBadge, setShowBadge] = useState(true);
  const [selectedPlatform, setSelectedPlatform] = useState('WordPress');
  const [showInstall, setShowInstall] = useState(false);

  // Install request state
  const [installForm, setInstallForm] = useState({ website: '', admin_email: '', admin_notes: '' });
  const [installSubmitting, setInstallSubmitting] = useState(false);
  const [installDone, setInstallDone] = useState(false);

  const autoSlug = slugify(data.business_name) || 'my-business';
  const slug = customSlug || autoSlug;
  const hostedUrl = `https://quotes.${slug}.quickquote.tools`;
  const shareUrl = `https://quickquote.tools/calc/${slug}`;

  const embedSnippet = `<div id="quickquote" data-tool-id="{TOOL_ID}"></div>
<script async src="https://quickquote.tools/embed.js"><\/script>`;

  useImperativeHandle(ref, () => ({
    getData() {
      return { custom_slug: customSlug, owner_email: ownerEmail, show_powered_by_badge: showBadge };
    }
  }));

  const handleInstallSubmit = async () => {
    if (!installForm.website.trim() || !installForm.admin_email.trim()) return;
    setInstallSubmitting(true);
    await base44.integrations.Core.SendEmail({
      to: 'hello@quickquote.app',
      subject: 'Installation Request',
      body: `Business: ${data.business_name}\nSlug: ${slug}\nWebsite: ${installForm.website}\nAdmin Email: ${installForm.admin_email}\nNotes: ${installForm.admin_notes}`,
    }).catch(() => {});
    setInstallSubmitting(false);
    setInstallDone(true);
  };

  return (
    <StepShell title="Publish & Share" subtitle="Choose your distribution strategy.">
      <div className="space-y-6">
      {/* Trust Indicators */}
      <div className="flex flex-col gap-2 px-4 py-3 rounded-xl bg-slate-50 border border-slate-100">
        <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Why QuickQuote</p>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5 text-xs text-slate-600">
            <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(13,148,136,0.15)', color: '#0D9488', fontSize: '10px', fontWeight: 700 }}>✓</div>
            <span>No coding required</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-600">
            <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(13,148,136,0.15)', color: '#0D9488', fontSize: '10px', fontWeight: 700 }}>✓</div>
            <span>Works on any website</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-600">
            <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(13,148,136,0.15)', color: '#0D9488', fontSize: '10px', fontWeight: 700 }}>✓</div>
            <span>Cancel anytime</span>
          </div>
        </div>
      </div>

      {/* MODE A — Hosted Quote Page (Primary) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5" style={{ boxShadow: '0 4px 12px rgba(15,23,42,0.08)' }}>
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <Globe className="w-5 h-5 text-teal-600" strokeWidth={1.8} />
            <span className="text-[15px] font-semibold text-slate-900">Hosted Quote Page</span>
          </div>
          <p className="text-sm text-slate-600">We'll host your quote tool on a branded URL. Share anywhere—no website needed.</p>
        </div>

        {/* Slug editor */}
         <div>
           <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">Your branded URL</Label>
          <div className="flex items-center mt-1 rounded-xl border border-slate-200 bg-white overflow-hidden focus-within:ring-1 focus-within:ring-teal-300">
            <span className="px-2.5 text-[11px] text-slate-400 bg-slate-50 border-r border-slate-100 h-9 flex items-center flex-shrink-0 whitespace-nowrap">
              quotes.
            </span>
            <input
              className="flex-1 h-9 px-2 text-sm bg-white focus:outline-none text-slate-700 font-medium min-w-0"
              value={customSlug || autoSlug}
              onChange={e => setCustomSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-'))}
            />
            <span className="px-2.5 text-[11px] text-slate-400 bg-slate-50 border-l border-slate-100 h-9 flex items-center flex-shrink-0 whitespace-nowrap">
              .quickquote.tools
            </span>
          </div>
        </div>

        {/* Hosted URL row */}
        <div className="flex items-center gap-2 bg-white rounded-xl px-3 py-2 border border-teal-100">
          <span className="text-xs text-teal-700 flex-1 truncate font-medium">{hostedUrl}</span>
          <CopyBtn text={hostedUrl} />
          <a
            href={hostedUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all"
            style={{ background: 'rgba(13,148,136,0.08)', color: '#0D9488', border: '1px solid rgba(13,148,136,0.2)' }}
          >
            <ExternalLink className="w-3 h-3" /> Open
          </a>
        </div>

        {/* Positioning note */}
        <p className="text-xs text-slate-400 leading-relaxed">
          Add this link to your Google Business profile, Instagram bio, Facebook page, or send it directly to customers for instant quotes.
        </p>

        {/* Google Maps tip */}
        <div className="flex items-start gap-2.5 rounded-xl px-3 py-2.5 bg-white border border-amber-100">
          <MapPin className="w-3.5 h-3.5 text-amber-500 mt-0.5 flex-shrink-0" strokeWidth={2} />
          <p className="text-[11px] text-slate-500 leading-relaxed">
            <span className="font-semibold text-slate-600">Pro tip:</span> Add this link to your Google Business profile website field so customers can get instant quotes directly from Google.
          </p>
        </div>

        </div>

        {/* Install Your Quote Tool */}
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 space-y-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <Code2 className="w-5 h-5 text-slate-700" strokeWidth={1.8} />
              <span className="text-[15px] font-semibold text-slate-900">Install Your Quote Tool</span>
            </div>
            <p className="text-[13px] text-slate-500">Embed QuickQuote on your website in minutes — or let our team handle the setup.</p>
          </div>

          {/* Two cards */}
          <div className="flex flex-col gap-3">

            {/* Card 1 — Self Install */}
            <div className="rounded-xl border-2 bg-white p-4 space-y-3" style={{ borderColor: '#2563EB', boxShadow: '0 2px 10px rgba(37,99,235,0.07)' }}>
              <div>
                <p className="text-[13px] font-semibold text-slate-800 mb-0.5">Self Installation</p>
                <p className="text-[11px] text-slate-500 leading-relaxed">Add the quote widget to your site using a simple embed snippet. Works with WordPress, Webflow, Wix, Shopify, Squarespace, and custom HTML.</p>
              </div>
              <ul className="space-y-1">
                {['Copy & paste embed code', 'Takes ~5 minutes', 'No technical skills required', 'Full installation guide included'].map(b => (
                  <li key={b} className="flex items-center gap-2 text-[11px] text-slate-600">
                    <span className="w-3.5 h-3.5 rounded-full flex items-center justify-center flex-shrink-0 text-[9px] font-bold" style={{ background: 'rgba(37,99,235,0.1)', color: '#2563EB' }}>✓</span>
                    {b}
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => setShowInstall(o => !o)}
                className="w-full py-2 rounded-lg text-[12px] font-semibold transition-all active:scale-95"
                style={{ background: 'rgba(37,99,235,0.07)', color: '#2563EB', border: '1.5px solid rgba(37,99,235,0.2)' }}
              >
                {showInstall ? 'Hide Instructions' : 'View Installation Instructions'}
              </button>

              <AnimatePresence initial={false}>
                {showInstall && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.18, ease: 'easeOut' }}
                    className="overflow-hidden"
                  >
                    <div className="pt-3 border-t border-slate-100 space-y-3">
                      <div>
                        <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">Platform</p>
                        <div className="flex flex-wrap gap-1.5">
                          {PLATFORMS.map(p => (
                            <button
                              key={p}
                              type="button"
                              onClick={() => setSelectedPlatform(p)}
                              className="px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all"
                              style={selectedPlatform === p
                                ? { background: 'rgba(37,99,235,0.1)', color: '#2563EB', border: '1px solid rgba(37,99,235,0.25)' }
                                : { background: 'transparent', color: '#64748b', border: '1px solid #e2e8f0' }}
                            >{p}</button>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-2">
                        {platformInstructions[selectedPlatform].map((step, i) => (
                          <div key={i} className="flex items-start gap-2">
                            <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold mt-0.5" style={{ background: 'rgba(37,99,235,0.1)', color: '#2563EB' }}>{i + 1}</div>
                            <p className="text-[11px] text-slate-600 leading-relaxed">{step}</p>
                          </div>
                        ))}
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Embed code</span>
                          <CopyBtn text={embedSnippet} />
                        </div>
                        <div className="bg-slate-900 rounded-lg px-3 py-3 text-[10px] font-mono text-emerald-300 break-all leading-relaxed overflow-x-auto">
                          {embedSnippet}
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1.5">Replace <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-600 font-mono">{'{'}<strong>TOOL_ID</strong>{'}'}</code> with your calculator ID.</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Card 2 — Professional Setup */}
            <div className="rounded-xl border bg-white p-4 space-y-3 relative" style={{ borderColor: 'rgba(37,99,235,0.2)', background: '#F5F9FF', boxShadow: '0 4px 14px rgba(37,99,235,0.09)' }}>
              <div className="absolute top-3.5 right-3.5">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: 'rgba(37,99,235,0.1)', color: '#2563EB', border: '1px solid rgba(37,99,235,0.2)' }}>Pro Plan Included</span>
              </div>
              <div className="pr-24">
                <p className="text-[13px] font-semibold text-slate-800 mb-0.5">Professional Setup</p>
                <p className="text-[11px] text-slate-500 leading-relaxed">Our team installs and configures QuickQuote directly on your website.</p>
              </div>
              <ul className="space-y-1">
                {['Done-for-you installation', 'Placement & styling optimization', 'Mobile responsive adjustments', 'Basic testing before launch'].map(b => (
                  <li key={b} className="flex items-center gap-2 text-[11px] text-slate-600">
                    <span className="w-3.5 h-3.5 rounded-full flex items-center justify-center flex-shrink-0 text-[9px] font-bold" style={{ background: 'rgba(37,99,235,0.12)', color: '#2563EB' }}>✓</span>
                    {b}
                  </li>
                ))}
              </ul>
              <div className="flex items-center gap-2 py-2 px-3 rounded-lg" style={{ background: 'rgba(37,99,235,0.06)', border: '1px solid rgba(37,99,235,0.12)' }}>
                <span className="text-[13px] font-bold text-slate-800">$49</span>
                <span className="text-[11px] text-slate-500">one-time setup · included free on Pro plan</span>
              </div>

              {installDone ? (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 py-2.5 px-3 rounded-lg bg-emerald-50 border border-emerald-100">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" strokeWidth={1.8} />
                  <p className="text-[12px] font-medium text-slate-700">Request received. We'll be in touch within 1 business day.</p>
                </motion.div>
              ) : (
                <div className="space-y-2">
                  <div>
                    <Label className="text-[11px] font-medium text-slate-600">Website URL <span className="text-red-400">*</span></Label>
                    <Input className="mt-1 rounded-lg border-slate-200 bg-white text-sm" placeholder="https://yoursite.com" value={installForm.website} onChange={e => setInstallForm(f => ({ ...f, website: e.target.value }))} />
                  </div>
                  <div>
                    <Label className="text-[11px] font-medium text-slate-600">Your email <span className="text-red-400">*</span></Label>
                    <Input className="mt-1 rounded-lg border-slate-200 bg-white text-sm" placeholder="you@yourcompany.com" type="email" value={installForm.admin_email} onChange={e => setInstallForm(f => ({ ...f, admin_email: e.target.value }))} />
                  </div>
                  <button
                    type="button"
                    onClick={handleInstallSubmit}
                    disabled={installSubmitting || !installForm.website.trim() || !installForm.admin_email.trim()}
                    className="w-full py-2 rounded-lg text-[13px] font-semibold text-white transition-all active:scale-95 disabled:opacity-50"
                    style={{ background: '#2563EB', boxShadow: '0 4px 12px rgba(37,99,235,0.2)' }}
                  >
                    {installSubmitting ? <><Loader2 className="w-3.5 h-3.5 animate-spin inline mr-2" />Sending…</> : 'Request Professional Setup'}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Helper text */}
          <p className="text-[11px] text-slate-400 text-center leading-relaxed">
            Need custom integration or advanced styling?{' '}
            <a href="mailto:hello@quickquote.app" className="text-slate-500 underline underline-offset-2 hover:text-slate-700 transition-colors">Contact support</a> for custom development.
          </p>
        </div>

        {/* Powered by toggle */}
        <div className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3" style={{ boxShadow: '0 2px 8px rgba(15,23,42,0.06)' }}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[13px] font-semibold text-slate-700">Show "Powered by QuickQuote" badge?</p>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                QuickQuote is a paid subscription. Keeping the badge visible gives you a discount.
              </p>
            </div>
            <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 overflow-hidden text-[11px] font-semibold flex-shrink-0">
              <button
                type="button"
                onClick={() => setShowBadge(true)}
                className="px-3 py-1.5 transition-all"
                style={showBadge ? { background: 'rgba(37,99,235,0.1)', color: '#2563EB' } : { color: '#94a3b8' }}
              >Yes</button>
              <button
                type="button"
                onClick={() => setShowBadge(false)}
                className="px-3 py-1.5 transition-all"
                style={!showBadge ? { background: 'rgba(100,116,139,0.1)', color: '#475569' } : { color: '#94a3b8' }}
              >No</button>
            </div>
          </div>
          <div className="flex items-start gap-2 rounded-lg px-3 py-2.5 bg-amber-50 border border-amber-100">
            <span className="text-amber-500 text-xs mt-0.5 flex-shrink-0">💡</span>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {showBadge
                ? <>Keep the badge and get <strong>10% off</strong> your subscription. White-label (badge removed) is available on the Pro plan.</>
                : <>White-label mode (badge hidden) is available on the Pro plan. Showing the badge gives you <strong>10% off</strong> your subscription.</>
              }
            </p>
          </div>
        </div>


      </div>
    </StepShell>
  );
});

export default StepLaunch;