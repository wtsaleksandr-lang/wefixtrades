import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Copy, Check, ExternalLink, Edit2, Users, AlertTriangle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

function CopyButton({ text }) {
   const [copied, setCopied] = useState(false);
   const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
   return (
     <button onClick={copy} className="p-1.5 rounded hover:bg-slate-100 transition-colors flex-shrink-0" title="Copy">
       {copied ? <Check className="w-4 h-4 text-teal-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
     </button>
   );
 }

function UrlRow({ url }) {
  return (
    <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200">
      <span className="text-sm text-slate-700 flex-1 truncate">{url}</span>
      <CopyButton text={url} />
    </div>
  );
}

export default function SuccessScreen({ result, wizardData }) {
  const origin = window.location.origin;
  const calcUrl = `${origin}/Calculator?slug=${result.slug}`;
  const editUrl = `${origin}/EditCalculator?token=${result.edit_token}`;
  const leadsUrl = `${origin}/Leads?token=${result.edit_token}`;
  const expiryDate = new Date(result.token_expires_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric' });

  const embedCode = `<div id="quickquote" data-tool-id="${result.calculator_id}"></div>
<script async src="https://quickquote.tools/embed.js"><\/script>`;

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      {/* Top success bar */}
      <div className="h-1.5 bg-green-500" />

      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="text-center">
          <div className="w-14 h-14 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-3">
             <Check className="w-7 h-7 text-teal-600" />
           </div>
          <h2 className="text-xl font-bold text-slate-900">Your Calculator is Live! 🎉</h2>
          <p className="text-slate-500 text-sm mt-1">Here's everything you need to start collecting leads.</p>
        </div>

        {/* Calculator URL */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5">
            <ExternalLink className="w-3.5 h-3.5 text-teal-600" />
            <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Calculator URL</span>
          </div>
          <UrlRow url={calcUrl} />
          <a href={calcUrl} target="_blank" rel="noopener noreferrer">
            <Button size="sm" variant="outline" className="w-full mt-1">Open Calculator <ExternalLink className="ml-2 w-3 h-3" /></Button>
          </a>
        </div>

        {/* Embed code */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-teal-600" />
            <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Embed Code</span>
          </div>
          <div className="relative">
            <pre className="bg-slate-900 text-slate-300 text-xs p-3 rounded-lg overflow-x-auto whitespace-pre-wrap break-all">{embedCode}</pre>
            <div className="absolute top-1.5 right-1.5"><CopyButton text={embedCode} /></div>
          </div>
          <p className="text-xs text-slate-500">Paste this anywhere on your website to embed your quote calculator.</p>
        </div>

        {/* Edit link */}
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 space-y-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
            <span className="text-xs font-semibold text-amber-800">Edit Link — Save this!</span>
            <span className="text-xs text-amber-600 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200 ml-auto">Expires {expiryDate}</span>
          </div>
          <UrlRow url={editUrl} />
        </div>

        {/* Leads */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-teal-600" />
            <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Leads Dashboard</span>
          </div>
          <UrlRow url={leadsUrl} />
        </div>

        <div className="rounded-xl border border-teal-100 bg-teal-50 p-3 text-sm">
          <p className="text-teal-900 font-medium mb-2">📊 Trial Active (7 days)</p>
          <p className="text-xs text-teal-800 leading-relaxed">Your calculator is in trial mode. All features work normally. After 7 days, leads will stop unless you activate.</p>
        </div>

        {wizardData.owner_email && (
          <p className="text-center text-xs text-slate-500">
            ✉️ All links sent to <strong>{wizardData.owner_email}</strong>
          </p>
        )}

        <Link to={createPageUrl('Home')}>
          <Button variant="outline" className="w-full">Create Another Calculator</Button>
        </Link>
      </div>
    </div>
  );
}