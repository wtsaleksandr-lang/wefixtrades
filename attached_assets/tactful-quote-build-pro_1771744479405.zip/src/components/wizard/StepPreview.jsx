import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { getTemplate } from '../calculator/templateConfig';
import StepShell from './StepShell';

// ── Template mock selections ──────────────────────────────────────────────────
const TEMPLATE_SELECTIONS = {
  cleaning: [
    { label: 'Home size', value: '2 bedrooms / 1 bath' },
    { label: 'Frequency', value: 'Weekly service' },
    { label: 'Add-ons', value: 'Oven cleaning, Fridge' },
  ],
  lawn_care: [
    { label: 'Yard size', value: 'Medium (5,000–10,000 sq ft)' },
    { label: 'Service', value: 'Mow, edge & blow' },
    { label: 'Add-ons', value: 'Fertilization' },
  ],
  web_design: [
    { label: 'Project type', value: 'Business website' },
    { label: 'Pages', value: '5–10 pages' },
    { label: 'Add-ons', value: 'Blog, SEO package' },
  ],
  roofing: [
    { label: 'Roof size', value: '~1,200 sq ft' },
    { label: 'Material', value: 'Asphalt shingles' },
    { label: 'Add-ons', value: 'Gutters, underlayment' },
  ],
  moving: [
    { label: 'Home size', value: '2-bedroom apartment' },
    { label: 'Distance', value: 'Local move (< 50 mi)' },
    { label: 'Add-ons', value: 'Packing service' },
  ],
};
const DEFAULT_SELECTIONS = [
  { label: 'Service type', value: 'Standard package' },
  { label: 'Size / scope', value: 'Medium' },
  { label: 'Add-ons', value: 'None selected' },
];

// ── Animated count-up hook ────────────────────────────────────────────────────
function useCountUp(target, active, duration = 700) {
  const [display, setDisplay] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(null);

  useEffect(() => {
    if (!active || target === 0) { setDisplay(0); return; }
    const startValue = 0;
    startRef.current = null;
    const step = (ts) => {
      if (!startRef.current) startRef.current = ts;
      const elapsed = ts - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(startValue + (target - startValue) * eased));
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => rafRef.current && cancelAnimationFrame(rafRef.current);
  }, [target, active, duration]);

  return display;
}

// ── Main component ────────────────────────────────────────────────────────────
const StepPreview = forwardRef(function StepPreview({ data }, ref) {
  const [quoteAmount, setQuoteAmount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const template = getTemplate(data.template);

  useImperativeHandle(ref, () => ({ getData() { return {}; } }));

  const businessName = data.business_name || 'Your Business';
  const tagline = data.tagline;
  const ctaText = data.cta_button_text || 'Get My Free Quote';
  const selections = TEMPLATE_SELECTIONS[data.template] || DEFAULT_SELECTIONS;

  const animatedAmount = useCountUp(quoteAmount, showResult);

  // ── Pricing logic unchanged ──────────────────────────────────────────────
  const runSample = () => {
    if (loading) return;
    const cfg = data.template_config || template.defaultConfig;
    let amount = 0;
    switch (data.template) {
      case 'cleaning': amount = cfg.two_bed_price || 130; break;
      case 'lawn_care': amount = cfg.medium_price || 55; break;
      case 'web_design': amount = (cfg.base_price || 800) + (cfg.blog_fee || 200); break;
      case 'roofing': amount = Math.round((cfg.asphalt_per_sqft || 3.5) * 1200); break;
      case 'moving': amount = cfg.two_bed_base || 500; break;
      default: amount = 250;
    }
    setLoading(true);
    setShowResult(false);
    setTimeout(() => {
      setQuoteAmount(amount);
      setLoading(false);
      setShowResult(true);
    }, 480);
  };

  return (
    <StepShell title="Preview your calculator" subtitle="This is how visitors will see it. Test the sample quote.">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

        {/* ── LEVEL 1: Main preview card ────────────────────────────────── */}
        <div style={{
          background: '#ffffff',
          border: '1px solid rgba(15,23,42,0.06)',
          boxShadow: '0 20px 60px rgba(2,6,23,0.12), 0 8px 20px rgba(2,6,23,0.06)',
          borderRadius: 18,
          overflow: 'hidden',
        }}>

          {/* Header */}
          <div style={{
            background: 'linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)',
            boxShadow: 'inset 0 -1px 0 rgba(255,255,255,0.08)',
            padding: '18px 20px',
            color: '#fff',
          }}>
            {data.logo_url && (
              <img src={data.logo_url} alt={businessName}
                style={{ height: 28, marginBottom: 10, objectFit: 'contain' }}
                onError={e => { e.target.style.display = 'none'; }} />
            )}
            <div style={{
              fontWeight: 800, fontSize: 17, lineHeight: 1.2,
              letterSpacing: '-0.01em', color: '#ffffff',
              textShadow: '0 1px 4px rgba(0,0,0,0.20)',
            }}>
              {businessName}
            </div>
            {tagline && (
              <div style={{ color: 'rgba(255,255,255,0.80)', fontSize: 12, marginTop: 4, lineHeight: 1.4 }}>
                {tagline}
              </div>
            )}
            <div style={{
              color: 'rgba(255,255,255,0.85)',
              fontSize: 11.5,
              fontWeight: 600,
              letterSpacing: '0.09em',
              textTransform: 'uppercase',
              marginTop: 10,
              display: 'flex',
              alignItems: 'center',
              gap: 5,
            }}>
              <span>{template.emoji}</span>
              <span>{template.name} Calculator</span>
            </div>
          </div>

          {/* Body */}
          <div style={{ padding: '20px 18px', display: 'flex', flexDirection: 'column', gap: 16 }}>

            {/* Inputs */}
            <MockField label="Property / project type" placeholder="Select an option..." />
            <MockField label="Size or scope" placeholder="Choose size..." />

            {/* LEVEL 2: Your Selections ────────────────────────────── */}
            <div style={{
              background: '#f8fafc',
              border: '1px solid rgba(15,23,42,0.08)',
              borderRadius: 14,
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '8px 14px',
                background: 'rgba(37,99,235,0.06)',
                borderBottom: '1px solid rgba(37,99,235,0.10)',
                fontSize: 10,
                fontWeight: 700,
                letterSpacing: '0.10em',
                textTransform: 'uppercase',
                color: '#2563EB',
              }}>
                Your selections
              </div>
              <div>
                {selections.map(({ label, value }, i) => (
                  <div key={label} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '8px 14px',
                    borderBottom: i < selections.length - 1 ? '1px solid rgba(15,23,42,0.05)' : 'none',
                  }}>
                    <span style={{ fontSize: 11.5, color: '#64748B', fontWeight: 500 }}>{label}</span>
                    <span style={{ fontSize: 11.5, color: '#1E293B', fontWeight: 600, textAlign: 'right', maxWidth: '55%' }}>{value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* LEVEL 3: Estimated total panel ─────────────────────── */}
            <div>
              <div style={{
                fontSize: 10, fontWeight: 700, letterSpacing: '0.09em',
                textTransform: 'uppercase', color: '#94A3B8',
                marginBottom: 8, paddingLeft: 2,
              }}>
                Estimated total
              </div>
              <div style={{
                borderRadius: 14,
                padding: '16px',
                textAlign: 'center',
                transition: 'all 0.3s ease',
                background: showResult ? '#eef2ff' : 'rgba(15,23,42,0.03)',
                border: showResult ? '1px solid rgba(37,99,235,0.15)' : '1px solid rgba(15,23,42,0.07)',
                boxShadow: showResult ? '0 0 0 4px rgba(37,99,235,0.08)' : 'none',
              }}>
                {loading ? (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '4px 0' }}>
                    <Spinner />
                    <span style={{ fontSize: 12, color: '#64748B' }}>Calculating…</span>
                  </div>
                ) : showResult ? (
                  <>
                    <div style={{
                      fontSize: 32, fontWeight: 800, letterSpacing: '-0.5px', color: '#1D4ED8',
                      transition: 'all 0.3s ease',
                    }}>
                      ${animatedAmount.toLocaleString()}
                    </div>
                    <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>
                      Estimate · may vary based on final scope
                    </div>
                  </>
                ) : (
                  <div style={{ fontSize: 12, color: '#94A3B8', padding: '4px 0' }}>
                    Run the sample to see a quote
                  </div>
                )}
              </div>

              {/* Trust row */}
              <div style={{
                display: 'flex',
                justifyContent: 'center',
                gap: 16,
                marginTop: 10,
                flexWrap: 'wrap',
              }}>
                {['Instant estimate', 'Transparent pricing', 'No obligation'].map(t => (
                  <span key={t} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10.5, color: '#94A3B8', fontWeight: 500 }}>
                    <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                      <circle cx="6" cy="6" r="6" fill="rgba(37,99,235,0.10)" />
                      <path d="M3.5 6l1.8 1.8L8.5 4.5" stroke="#2563EB" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    {t}
                  </span>
                ))}
              </div>
            </div>

            {/* CTA button */}
            <CtaButton loading={loading} done={showResult} label={showResult ? ctaText : '▶ Run Sample Quote'} onClick={runSample} />
          </div>
        </div>

        {/* ── Business chip row ──────────────────────────────────────────── */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '11px 14px',
          background: '#ffffff',
          border: '1px solid rgba(15,23,42,0.08)',
          borderRadius: 16,
          boxShadow: '0 2px 10px rgba(15,23,42,0.06)',
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
            background: 'linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 15, boxShadow: '0 3px 10px rgba(30,64,175,0.28)',
          }}>
            {template.emoji}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#0F172A', lineHeight: 1.3 }}>
              {data.business_name || 'Your Business'}
              <span style={{ fontWeight: 500, color: '#475569' }}> · {template.name}</span>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 5, flexWrap: 'wrap' }}>
              <PillBadge label="Instant estimate" />
              <PillBadge label="Takes ~30s" />
            </div>
          </div>
        </div>

        <p style={{ fontSize: 11, color: '#94A3B8', textAlign: 'center' }}>
          Click "Run Sample Quote" to test the pricing logic.
        </p>
      </div>
    </StepShell>
  );
});

// ── Sub-components ────────────────────────────────────────────────────────────

function MockField({ label, placeholder }) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#475569', marginBottom: 8, letterSpacing: '0.02em' }}>
        {label}
      </div>
      <div
        tabIndex={0}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          height: 46,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 12px',
          background: '#FFFFFF',
          border: focused ? '1px solid #2563eb' : '1px solid rgba(15,23,42,0.13)',
          borderRadius: 10,
          boxShadow: focused
            ? '0 0 0 3px rgba(37,99,235,0.15)'
            : '0 2px 6px rgba(15,23,42,0.04)',
          transition: 'all 150ms ease',
          cursor: 'pointer',
          outline: 'none',
        }}
      >
        <span style={{ fontSize: 13, color: '#94A3B8' }}>{placeholder}</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m6 9 6 6 6-6"/>
        </svg>
      </div>
    </div>
  );
}

function CtaButton({ loading, done, label, onClick }) {
  const [hover, setHover] = useState(false);
  const [active, setActive] = useState(false);
  return (
    <button
      onClick={onClick}
      disabled={loading}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        width: '100%',
        height: 46,
        borderRadius: 12,
        fontSize: 14,
        fontWeight: 600,
        letterSpacing: '0.1px',
        color: '#ffffff',
        border: '1px solid rgba(255,255,255,0.14)',
        background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
        boxShadow: hover
          ? '0 12px 30px rgba(37,99,235,0.36), 0 4px 12px rgba(37,99,235,0.22)'
          : '0 8px 24px rgba(37,99,235,0.28), 0 3px 8px rgba(37,99,235,0.16)',
        transform: active ? 'scale(0.98)' : hover ? 'translateY(-1px)' : 'none',
        transition: 'all 150ms ease',
        cursor: loading ? 'not-allowed' : 'pointer',
        opacity: loading ? 0.8 : 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
      }}
    >
      {loading && <Spinner light />}
      {label}
    </button>
  );
}

function PillBadge({ label }) {
  return (
    <span style={{
      fontSize: 10.5,
      fontWeight: 600,
      color: '#2563EB',
      background: 'rgba(37,99,235,0.08)',
      border: '1px solid rgba(37,99,235,0.18)',
      borderRadius: 20,
      padding: '2px 9px',
      letterSpacing: '0.02em',
    }}>
      {label}
    </span>
  );
}

function Spinner({ light = false }) {
  return (
    <svg
      width="14" height="14" viewBox="0 0 24 24" fill="none"
      stroke={light ? 'rgba(255,255,255,0.8)' : '#94A3B8'}
      strokeWidth="2.5" strokeLinecap="round"
      style={{ animation: 'spin 0.7s linear infinite', flexShrink: 0 }}
    >
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
  );
}

export default StepPreview;