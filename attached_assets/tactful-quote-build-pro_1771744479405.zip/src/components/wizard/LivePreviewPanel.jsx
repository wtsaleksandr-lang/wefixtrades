import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, Maximize2 } from 'lucide-react';
import CalculatorWidget from '../calculator/CalculatorWidget';

/**
 * LivePreviewPanel
 * Shows a live, updating preview of the calculator as user configures it.
 * Updates smoothly with fade transitions when config changes.
 */
export default function LivePreviewPanel({ data, onOpenFullPreview }) {
  const [updateKey, setUpdateKey] = useState(0);
  const [prevDataHash, setPrevDataHash] = useState('');
  
  // Detect when data changes and trigger smooth update
  useEffect(() => {
    const hash = JSON.stringify({
      business_name: data.business_name,
      template: data.template,
      primary_color: data.primary_color,
      font: data.font,
      button_style: data.button_style,
      tagline: data.tagline,
      logo_url: data.logo_url,
      cta_button_text: data.cta_button_text,
      template_config: data.template_config,
      pricing_config: data.pricing_config,
    });
    
    if (hash !== prevDataHash) {
      setPrevDataHash(hash);
      setUpdateKey(k => k + 1);
    }
  }, [data, prevDataHash]);

  // Mock calculator object for preview
  const mockCalculator = {
    slug: 'preview',
    business_name: data.business_name || 'Your Business Name',
    template: data.template || 'cleaning',
    template_config: data.template_config || {},
    logo_url: data.logo_url || '',
    tagline: data.tagline || '',
    cta_button_text: data.cta_button_text || 'Get My Free Quote',
    lead_thank_you_message: data.lead_thank_you_message || "Thanks! We'll be in touch within 24 hours.",
    themeOverrides: {
      colors: {
        primary: data.primary_color || '#6366f1',
      },
      typography: {
        fontFamily: data.font || 'Inter',
      },
    },
  };

  return (
    <div className="sticky top-6 rounded-[18px] bg-[#F9FAFB] border border-[#E5E7EB] overflow-hidden flex flex-col h-fit max-h-[calc(100vh-48px)] flex-shrink-0">
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#E5E7EB] bg-white flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-[15px] font-semibold text-slate-900 truncate">
            {data.business_name || 'Preview'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">
            {data.business_type || data.template || 'Quote Tool'}
          </p>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
          <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-blue-50 border border-blue-100">
            <Eye className="w-3 h-3 text-blue-600" />
            <span className="text-[10px] font-semibold text-blue-600 uppercase tracking-wider">Live</span>
          </div>
          <button
            type="button"
            onClick={onOpenFullPreview}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-700 hover:bg-slate-100 transition-all active:scale-95"
            title="Open full preview"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Preview Content — scrollable */}
      <div className="flex-1 overflow-y-auto bg-[#F9FAFB]">
        <motion.div
          key={updateKey}
          initial={{ opacity: 0.8 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="p-3 min-h-full"
        >
          {/* Scaled down calculator preview */}
          <div className="origin-top" style={{ transform: 'scale(0.7)', transformOrigin: 'top center' }}>
            <div className="w-[600px] bg-white rounded-lg overflow-hidden border border-slate-200 shadow-sm">
              <CalculatorWidget calculator={mockCalculator} isEmbed={false} />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Footer hint */}
      <div className="px-4 py-2 bg-white border-t border-[#E5E7EB] text-[10px] text-slate-400 text-center">
        Updates in real-time
      </div>
    </div>
  );
}