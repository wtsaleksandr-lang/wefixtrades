// This component is no longer used — progress bar is built into the Wizard card.
// Kept as empty export for safety.
export default function WizardProgress() { return null; }