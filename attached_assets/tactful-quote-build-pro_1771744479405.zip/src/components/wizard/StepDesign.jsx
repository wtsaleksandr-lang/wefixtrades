import React, { useState, useImperativeHandle, forwardRef } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import StepShell from './StepShell';

const PRESET_THEMES = [
  { id: 'graphite', label: 'Graphite', color: '#374151' },
  { id: 'navy', label: 'Navy', color: '#1e3a8a' },
  { id: 'emerald', label: 'Emerald', color: '#0d9488' },
  { id: 'slate', label: 'Slate', color: '#475569' },
];

const FONTS = ['Inter', 'Georgia', 'Montserrat', 'Merriweather', 'Roboto Mono'];

const BUTTON_STYLES = [
  { id: 'rounded', label: 'Soft Rounded' },
  { id: 'square', label: 'Sharp' },
  { id: 'pill', label: 'Pill' },
];

const SURFACE_STYLES = [
  { id: 'solid', label: 'Solid' },
  { id: 'glass', label: 'Glassmorphic' },
  { id: 'elevated', label: 'Elevated' },
];

const RADIUS_OPTIONS = [
  { id: 'sm', label: 'Compact', px: '8px' },
  { id: 'md', label: 'Medium', px: '12px' },
  { id: 'lg', label: 'Large', px: '16px' },
];

const StepDesign = forwardRef(function StepDesign({ data, onChange }, ref) {
  const [primaryColor, setPrimaryColor] = useState(data.accent || '#0D9488');
  const [font, setFont] = useState(data.font || 'Inter');
  const [buttonStyle, setButtonStyle] = useState(data.buttonStyle || 'rounded');
  const [surfaceStyle, setSurfaceStyle] = useState(data.surfaceVariant || 'solid');
  const [radius, setRadius] = useState(data.radius || 'md');
  const [logoUrl, setLogoUrl] = useState(data.logoUrl || '');
  const [activeTheme, setActiveTheme] = useState('emerald');
  const [showColorPicker, setShowColorPicker] = useState(false);

  const applyTheme = (theme) => {
    setActiveTheme(theme.id);
    setPrimaryColor(theme.color);
  };

  const resetToDefault = () => {
    setPrimaryColor('#0D9488');
    setFont('Inter');
    setButtonStyle('rounded');
    setSurfaceStyle('solid');
    setRadius('md');
    setLogoUrl('');
    setActiveTheme('emerald');
    setShowColorPicker(false);
  };

  useImperativeHandle(ref, () => ({
    getData() {
      return {
        // Legacy fields for backward compatibility
        primary_color: primaryColor,
        font,
        button_style: buttonStyle,
        logo_url: logoUrl,
        // New structure: per-tool themeOverrides
        themeOverrides: {
          accent: primaryColor,
          font,
          buttonStyle,
          surfaceVariant: surfaceStyle,
          radius,
          logoUrl,
        },
      };
    }
  }));

  return (
    <StepShell title="Design your calculator" subtitle="Pick a theme or customize. All settings are optional.">
      <div className="space-y-5">
      {/* Theme selection */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Color Theme</Label>
        <div className="grid grid-cols-5 gap-3 mt-2">
          {PRESET_THEMES.map(theme => (
            <button
              key={theme.id}
              type="button"
              onClick={() => applyTheme(theme)}
              className={`flex flex-col items-center gap-2 p-3 rounded-lg transition-all ${
                activeTheme === theme.id 
                  ? 'border-2 bg-slate-50' 
                  : 'border border-slate-200 bg-white hover:border-slate-300'
              }`}
              style={{
                borderColor: activeTheme === theme.id ? theme.color : undefined,
              }}
            >
              <div className="w-8 h-8 rounded-sm" style={{ backgroundColor: theme.color }} />
              <span className="text-xs font-medium text-slate-700">{theme.label}</span>
            </button>
          ))}
          
          <button
            type="button"
            onClick={() => setShowColorPicker(!showColorPicker)}
            className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg transition-all ${
              activeTheme === 'custom'
                ? 'border-2 bg-slate-50'
                : 'border border-slate-200 bg-white hover:border-slate-300'
            }`}
            style={{
              borderColor: activeTheme === 'custom' ? primaryColor : undefined,
            }}
          >
            <div className="w-8 h-8 rounded-sm border border-slate-300" style={{ backgroundColor: showColorPicker ? primaryColor : '#ffffff' }} />
            <span className="text-xs font-medium text-slate-700">Custom</span>
          </button>
        </div>
        
        {showColorPicker && (
          <div className="mt-3 flex items-center gap-2">
            <input
              type="color"
              value={primaryColor}
              onChange={e => { setPrimaryColor(e.target.value); setActiveTheme('custom'); }}
              className="w-10 h-10 rounded-lg border border-slate-300 cursor-pointer p-1"
            />
            <span className="text-sm text-slate-600 font-mono">{primaryColor.toUpperCase()}</span>
          </div>
        )}
      </div>

      {/* Button style */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Button Style</Label>
        <div className="flex gap-2 mt-2">
          {BUTTON_STYLES.map(s => (
            <button
              key={s.id}
              type="button"
              onClick={() => setButtonStyle(s.id)}
              className={`flex-1 py-2 px-3 text-sm font-medium border transition-all ${
                buttonStyle === s.id 
                  ? 'border-slate-300 bg-slate-100 text-slate-900' 
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              } ${s.id === 'rounded' ? 'rounded-lg' : s.id === 'pill' ? 'rounded-full' : 'rounded-sm'}`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Radius */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Border Radius</Label>
        <div className="flex gap-2 mt-2">
          {RADIUS_OPTIONS.map(r => (
            <button
              key={r.id}
              type="button"
              onClick={() => setRadius(r.id)}
              className={`flex-1 py-2 px-3 text-sm font-medium border transition-all ${
                radius === r.id 
                  ? 'border-slate-300 bg-slate-100 text-slate-900' 
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              } rounded-lg`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Surface Style */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Surface Style</Label>
        <div className="flex gap-2 mt-2">
          {SURFACE_STYLES.map(s => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSurfaceStyle(s.id)}
              className={`flex-1 py-2 px-3 text-sm font-medium border transition-all ${
                surfaceStyle === s.id 
                  ? 'border-slate-300 bg-slate-100 text-slate-900' 
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              } rounded-lg`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Font */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Font</Label>
        <div className="flex flex-wrap gap-2 mt-2">
          {FONTS.map(f => (
            <button
              key={f}
              type="button"
              onClick={() => setFont(f)}
              className={`px-3 py-1.5 text-sm border rounded-lg transition-all ${
                font === f ? 'border-indigo-500 bg-indigo-50 text-indigo-700 font-medium' : 'border-slate-200 text-slate-600 hover:border-indigo-300'
              }`}
              style={{ fontFamily: f }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Logo */}
      <div>
        <Label style={{ fontSize: '11px', fontWeight: 400, color: '#64748B', fontFamily: 'Inter', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Logo URL <span style={{ textTransform: 'none', fontWeight: 400, color: '#64748B', fontSize: '11px' }}>(optional)</span></Label>
        <Input
          className="mt-1"
          value={logoUrl}
          onChange={e => setLogoUrl(e.target.value)}
          placeholder="https://yoursite.com/logo.png"
        />
      </div>

      {/* Reset Button */}
      <div className="pt-4 border-t border-slate-200">
        <button
          type="button"
          onClick={resetToDefault}
          className="w-full py-2.5 px-4 text-sm font-medium text-slate-600 border border-slate-300 rounded-lg hover:bg-slate-50 transition-all"
        >
          Reset to Default Theme
        </button>
      </div>
      </div>
    </StepShell>
  );
});

export default StepDesign;