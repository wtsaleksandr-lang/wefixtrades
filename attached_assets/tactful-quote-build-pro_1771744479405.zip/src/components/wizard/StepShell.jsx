/**
 * StepShell — shared step header component.
 * Provides consistent title/subtitle spacing across ALL wizard steps.
 * 
 * Props:
 *   title (string) — step title
 *   subtitle (string, optional) — step subtitle/description
 *   children — step body content
 */
import React from 'react';

export default function StepShell({ title, subtitle, children }) {
  return (
    <div className="flex flex-col h-full">
      {/* Title + Subtitle */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
          <div style={{ width: '3px', minHeight: '34px', background: '#2563EB', borderRadius: '2px', marginTop: '4px', flexShrink: 0 }} />
          <div>
            <h2 style={{
              fontSize: '26px',
              fontWeight: 800,
              color: '#0B1220',
              fontFamily: 'Inter',
              letterSpacing: '-0.3px',
              margin: 0,
              lineHeight: 1.2,
            }}>
              {title}
            </h2>
            {subtitle && (
              <p style={{
                fontSize: '13px',
                fontWeight: 400,
                color: 'rgba(15,23,42,0.65)',
                fontFamily: 'Inter',
                marginTop: '10px',
                marginBottom: 0,
                lineHeight: 1.5,
              }}>
                {subtitle}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Step body */}
      <div className="flex-1">
        {children}
      </div>
    </div>
  );
}