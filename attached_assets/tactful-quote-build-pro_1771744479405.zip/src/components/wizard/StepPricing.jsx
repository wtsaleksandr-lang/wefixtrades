import React, { useState, useImperativeHandle, forwardRef, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { TEMPLATES } from '../calculator/templateConfig';
import { getTradeData, OUTPUT_STYLES, HYBRID_STRUCTURES } from './pricing/tradeData';
import StepShell from './StepShell';
import PrebuiltMode from './pricing/PrebuiltMode';
import HybridMode from './pricing/HybridMode';
import AIMode from './pricing/AIMode';

const MODES = [
  { id: 'prebuilt', label: 'Prebuilt', desc: 'Fastest' },
  { id: 'hybrid', label: 'Hybrid', desc: 'Guided' },
  { id: 'ai', label: 'AI-Assisted', desc: 'Auto' },
];

function buildPricingConfig(mode, prebuilt, hybrid, aiState, tradeData) {
  if (mode === 'prebuilt') {
    const models = tradeData.prebuiltModels;
    const model = models.find(m => m.id === prebuilt.modelId) || models[0];
    return {
      pricingType: model.id,
      unitName: prebuilt.unitName || model.defaults.unitName,
      baseFee: parseFloat(prebuilt.baseFee) || null,
      perUnitRate: parseFloat(prebuilt.perUnitRate) || null,
      minCharge: parseFloat(prebuilt.minCharge) || null,
      addOns: [],
      difficultyTiers: null,
      outputStyle: tradeData.outputStyleDefault,
      notes: null,
    };
  }
  if (mode === 'hybrid') {
    return {
      pricingType: hybrid.structure || 'flat_rate',
      unitName: hybrid.unitName || tradeData.unitLabel,
      baseFee: parseFloat(hybrid.baseFee) || null,
      perUnitRate: parseFloat(hybrid.perUnitRate) || null,
      minCharge: parseFloat(hybrid.minCharge) || null,
      addOns: (hybrid.addons || []).map(a => ({ name: a.name, type: a.type, value: parseFloat(a.value) || 0 })),
      difficultyTiers: hybrid.useDifficulty ? hybrid.diffTiers : null,
      outputStyle: hybrid.outputStyle || tradeData.outputStyleDefault,
      notes: null,
    };
  }
  if (mode === 'ai') {
    const r = aiState.generatedResult;
    if (r) {
      return {
        pricingType: r.pricingType,
        unitName: r.unitName,
        baseFee: r.baseFee || null,
        perUnitRate: r.perUnitRate || null,
        minCharge: r.minCharge || parseFloat(aiState.aiMinCharge) || null,
        addOns: r.addOns || [],
        difficultyTiers: null,
        outputStyle: r.outputStyle || tradeData.outputStyleDefault,
        notes: r.notes,
      };
    }
    return {
      pricingType: 'custom',
      unitName: tradeData.unitLabel,
      baseFee: parseFloat(aiState.aiMinCharge) || null,
      perUnitRate: null,
      minCharge: parseFloat(aiState.aiMinCharge) || null,
      addOns: (aiState.aiAddons || []).map(a => ({ name: a.name, type: a.type, value: parseFloat(a.value) || 0 })),
      difficultyTiers: null,
      outputStyle: tradeData.outputStyleDefault,
      notes: aiState.formulaText || null,
    };
  }
  return {};
}

const panelVariants = {
  enter: { opacity: 0, y: 8 },
  center: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -6 },
};

const StepPricing = forwardRef(function StepPricing({ data, onChange }, ref) {
  const templateId = data.selected_trade?.template || data.template || 'cleaning';
  const templateDef = TEMPLATES.find(t => t.id === templateId) || TEMPLATES[0];
  const tradeData = getTradeData(templateId);

  const [mode, setMode] = useState(data.pricing_setup_mode || 'prebuilt');
  const dirRef = useRef(0);

  // Per-mode state — preserved when user switches between modes
  const defaultModel = tradeData.prebuiltModels[0];
  const [prebuilt, setPrebuilt] = useState({
    modelId: defaultModel.id,
    baseFee: defaultModel.defaults.baseFee,
    perUnitRate: defaultModel.defaults.perUnitRate,
    unitName: defaultModel.defaults.unitName,
    minCharge: defaultModel.defaults.minCharge,
    ...(data.prebuilt_state || {}),
  });

  const [hybrid, setHybrid] = useState({
    structure: tradeData.hybridDefaults.structure,
    unitName: tradeData.hybridDefaults.unitName,
    baseFee: tradeData.hybridDefaults.baseFee,
    perUnitRate: tradeData.hybridDefaults.perUnitRate,
    minCharge: tradeData.hybridDefaults.minCharge,
    addons: [],
    useDifficulty: false,
    outputStyle: tradeData.outputStyleDefault,
    ...(data.hybrid_state || {}),
  });

  const [aiState, setAiState] = useState({
    questionsText: '',
    formulaText: '',
    aiMinCharge: '',
    aiAddons: [],
    generatedResult: null,
    accepted: false,
    ...(data.ai_state || {}),
  });

  const MODEORDER = ['prebuilt', 'hybrid', 'ai'];

  const switchMode = (newMode) => {
    dirRef.current = MODEORDER.indexOf(newMode) > MODEORDER.indexOf(mode) ? 1 : -1;
    setMode(newMode);
  };

  // When AI mode says "edit in hybrid" — switch to hybrid with prefilled values
  const handleEditInHybrid = (result) => {
    if (result) {
      setHybrid(prev => ({
        ...prev,
        structure: result.pricingType || prev.structure,
        unitName: result.unitName || prev.unitName,
        baseFee: result.baseFee ?? prev.baseFee,
        perUnitRate: result.perUnitRate ?? prev.perUnitRate,
        minCharge: result.minCharge ?? prev.minCharge,
        addons: (result.addOns || []).map((a, i) => ({ ...a, id: i + Date.now() })),
        outputStyle: result.outputStyle || prev.outputStyle,
      }));
    }
    dirRef.current = -1;
    setMode('hybrid');
  };

  useImperativeHandle(ref, () => ({
    getData() {
      const pricingConfig = buildPricingConfig(mode, prebuilt, hybrid, aiState, tradeData);
      return {
        pricing_setup_mode: mode,
        prebuilt_state: prebuilt,
        hybrid_state: hybrid,
        ai_state: aiState,
        pricing_config: pricingConfig,
        // Legacy compat fields
        template_config: data.template_config || {},
        pricing_model: pricingConfig.pricingType,
      };
    }
  }));

  return (
    <StepShell
      title="Pricing Setup"
      subtitle="Pick a model. We'll generate your quote logic."
    >
      {/* Mode selector tabs */}
      <div style={{
        display: 'flex',
        gap: 4,
        background: '#f1f5f9',
        borderRadius: 14,
        padding: 4,
        marginBottom: 20,
      }}>
        {MODES.map(m => (
          <button
            key={m.id}
            type="button"
            onClick={() => switchMode(m.id)}
            style={{
              flex: 1,
              padding: '9px 6px',
              borderRadius: 10,
              border: 'none',
              cursor: 'pointer',
              transition: 'all 180ms ease',
              background: mode === m.id ? '#ffffff' : 'transparent',
              boxShadow: mode === m.id ? '0 2px 8px rgba(15,23,42,0.1)' : 'none',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <span style={{ fontSize: 13, fontWeight: 700, color: mode === m.id ? '#1E293B' : '#94A3B8', transition: 'color 180ms' }}>{m.label}</span>
            <span style={{ fontSize: 10, fontWeight: 500, color: mode === m.id ? '#2563EB' : '#CBD5E1', transition: 'color 180ms', letterSpacing: '0.04em' }}>{m.desc}</span>
          </button>
        ))}
      </div>

      {/* Animated mode panels */}
      <AnimatePresence mode="wait" custom={dirRef.current} initial={false}>
        <motion.div
          key={mode}
          custom={dirRef.current}
          variants={panelVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ duration: 0.18, ease: 'easeOut' }}
        >
          {mode === 'prebuilt' && (
            <PrebuiltMode
              tradeData={tradeData}
              state={prebuilt}
              onChange={setPrebuilt}
            />
          )}
          {mode === 'hybrid' && (
            <HybridMode
              tradeData={tradeData}
              state={hybrid}
              onChange={setHybrid}
            />
          )}
          {mode === 'ai' && (
            <AIMode
              tradeData={tradeData}
              state={aiState}
              onChange={setAiState}
              onEditInHybrid={handleEditInHybrid}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </StepShell>
  );
});

export default StepPricing;