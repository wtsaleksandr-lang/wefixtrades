import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, ArrowLeft, Check } from 'lucide-react';
import { TEMPLATES } from '../calculator/templateConfig';

export default function StepTemplate({ data, onNext, onBack }) {
  const [selected, setSelected] = useState(data.template || data.business_type || 'cleaning');

  const handleNext = () => {
    const template = TEMPLATES.find(t => t.id === selected) || TEMPLATES[0];
    const hasExistingConfig = data.template_config && Object.keys(data.template_config).length > 0 && data.template === selected;
    onNext({
      template: selected,
      template_config: hasExistingConfig ? data.template_config : template.defaultConfig
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <p className="text-sm text-slate-500 mb-4">Choose the template that best fits your business. Pricing is pre-filled and customizable.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {TEMPLATES.map(template => (
            <button
              key={template.id}
              onClick={() => setSelected(template.id)}
              className={`p-4 rounded-xl border-2 text-left transition-all ${selected === template.id ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 hover:border-indigo-300 bg-white'}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{template.emoji}</span>
                  <div>
                    <div className="font-semibold text-slate-800">{template.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{template.description}</div>
                  </div>
                </div>
                {selected === template.id && (
                  <div className="w-5 h-5 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0 ml-2 mt-0.5">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}><ArrowLeft className="mr-2 w-4 h-4" /> Back</Button>
          <Button onClick={handleNext} className="bg-indigo-600 hover:bg-indigo-700">Continue <ArrowRight className="ml-2 w-4 h-4" /></Button>
        </div>
      </CardContent>
    </Card>
  );
}