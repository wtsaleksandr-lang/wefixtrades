import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Monitor, Smartphone } from 'lucide-react';
import CalculatorWidget from '../calculator/CalculatorWidget';

export default function FullPreviewModal({ data, onClose }) {
  const [viewport, setViewport] = useState('desktop');

  const mockCalculator = {
    slug: 'preview',
    business_name: data.business_name || 'Your Business Name',
    template: data.template || 'cleaning',
    template_config: data.template_config || {},
    logo_url: data.logo_url || '',
    tagline: data.tagline || '',
    cta_button_text: data.cta_button_text || 'Get My Free Quote',
    lead_thank_you_message: data.lead_thank_you_message || "Thanks! We'll be in touch within 24 hours.",
    themeOverrides: {
      colors: {
        primary: data.primary_color || '#6366f1',
      },
      typography: {
        fontFamily: data.font || 'Inter',
      },
    },
  };

  const getViewportWidth = () => viewport === 'desktop' ? 1200 : 375;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.15 }}
        onClick={onClose}
        style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)' }}
      >
        <motion.div
          className="relative bg-white rounded-xl overflow-hidden flex flex-col max-h-[90vh]"
          style={{ width: '80%', maxWidth: '1300px' }}
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.94 }}
          transition={{ duration: 0.18, ease: 'easeOut' }}
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-4 bg-white border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Full Preview</h2>
              <p className="text-sm text-slate-400 mt-0.5">{data.business_name || 'Preview'}</p>
            </div>
            <div className="flex items-center gap-3">
              {/* Viewport toggle */}
              <div className="flex items-center gap-1.5 p-1 rounded-lg bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setViewport('desktop')}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all"
                  style={{
                    background: viewport === 'desktop' ? 'white' : 'transparent',
                    color: viewport === 'desktop' ? '#1E293B' : '#64748B',
                    boxShadow: viewport === 'desktop' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                  }}
                >
                  <Monitor className="w-3.5 h-3.5" /> Desktop
                </button>
                <button
                  type="button"
                  onClick={() => setViewport('mobile')}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all"
                  style={{
                    background: viewport === 'mobile' ? 'white' : 'transparent',
                    color: viewport === 'mobile' ? '#1E293B' : '#64748B',
                    boxShadow: viewport === 'mobile' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                  }}
                >
                  <Smartphone className="w-3.5 h-3.5" /> Mobile
                </button>
              </div>

              {/* Close */}
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all active:scale-90"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Preview frame */}
          <div className="flex-1 overflow-auto bg-slate-50 p-8 flex items-start justify-center">
            <motion.div
              key={viewport}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex-shrink-0"
              style={{
                width: viewport === 'desktop' ? '100%' : 'auto',
              }}
            >
              <div
                className="bg-white rounded-xl overflow-hidden shadow-lg border border-slate-200"
                style={{
                  width: `${getViewportWidth()}px`,
                }}
              >
                <div style={{ maxHeight: 'calc(90vh - 140px)', overflowY: 'auto' }}>
                  <CalculatorWidget calculator={mockCalculator} isEmbed={false} />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Footer hint */}
          <div className="px-6 py-3 bg-white border-t border-slate-100 text-center text-xs text-slate-400">
            This is a preview of how your calculator will look to customers
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}