import * as React from "react"
import { designTokens } from "@/components/designTokens"
import { cn } from "@/lib/utils"
import { getTransition } from "@/components/designTokens"

const Input = React.forwardRef(({ className, type, ...props }, ref) => {
        return (
          (<input
            type={type}
            className={cn(
              "flex w-full text-sm transition-all file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
              "border bg-white placeholder:text-slate-400",
              className
            )}
            style={{
              height: '40px',
              padding: `${designTokens.spacing.md} ${designTokens.spacing.lg}`,
              borderRadius: designTokens.radius.md,
              borderColor: designTokens.colors.border,
              borderWidth: '1px',
              fontSize: '14px',
              fontWeight: 400,
              transition: getTransition('fast'),
              backgroundColor: designTokens.colors.surface,
              ...props.style,
            }}
            onFocus={(e) => {
              e.target.style.borderColor = designTokens.colors.blue;
              e.target.style.boxShadow = `0 0 0 3px ${designTokens.colors.blueTint}`;
            }}
            onBlur={(e) => {
              e.target.style.borderColor = designTokens.colors.border;
              e.target.style.boxShadow = 'none';
            }}
            ref={ref}
            {...props} />)
        );
      })
Input.displayName = "Input"

export { Input }