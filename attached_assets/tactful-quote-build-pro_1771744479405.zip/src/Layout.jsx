import React from 'react';
import { useLocation } from 'react-router-dom';

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const isEmbed = new URLSearchParams(location.search).get('embed') === 'true';

  // Calculator page in embed mode: bare output, no wrapper
  if (currentPageName === 'Calculator' && isEmbed) {
    return <>{children}</>;
  }

  return <div className="min-h-screen">{children}</div>;
}