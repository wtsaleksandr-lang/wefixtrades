import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, AlertTriangle, Check, Copy, ExternalLink, RefreshCw, Lock } from 'lucide-react';

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <button onClick={copy} className="p-1.5 rounded hover:bg-slate-100 flex-shrink-0">
      {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
    </button>
  );
}

function UrlRow({ url }) {
  return (
    <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200">
      <span className="text-sm text-slate-700 flex-1 truncate">{url}</span>
      <CopyButton text={url} />
    </div>
  );
}

const PRESET_COLORS = ['#6366f1', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

export default function EditCalculator() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get('token');

  const [calculator, setCalculator] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editData, setEditData] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isDuplicating, setIsDuplicating] = useState(false);
  const [duplicateResult, setDuplicateResult] = useState(null);

  useEffect(() => {
    if (!token) { setError('No edit token provided.'); setLoading(false); return; }
    load();
  }, [token]);

  const load = async () => {
    const res = await base44.functions.invoke('getCalculator', { token });
    if (res.data?.calculator) {
      setCalculator(res.data.calculator);
      setEditData(res.data.calculator);
    } else {
      setError(res.data?.error || 'Invalid token.');
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setIsSaving(true);
    await base44.functions.invoke('updateCalculator', { token, updates: editData });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setIsSaving(false);
  };

  const handleDuplicate = async () => {
    setIsDuplicating(true);
    const res = await base44.functions.invoke('duplicateCalculator', { token });
    if (res.data?.success) setDuplicateResult(res.data);
    else setError(res.data?.error || 'Failed to duplicate.');
    setIsDuplicating(false);
  };

  const set = (key, val) => setEditData(prev => ({ ...prev, [key]: val }));

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-slate-400" /></div>;

  if (error) return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center"><AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-slate-800 mb-2">Access Error</h2>
        <p className="text-slate-500">{error}</p>
      </div>
    </div>
  );

  const origin = window.location.origin;
  const calcUrl = `${origin}/Calculator?slug=${calculator.slug}`;
  const leadsUrl = `${origin}/Leads?token=${token}`;
  const isExpired = calculator.is_token_expired;

  if (isExpired) {
    return (
      <div className="min-h-screen bg-slate-50 px-4 py-12">
        <div className="max-w-xl mx-auto">
          <Card className="border-amber-200">
            <CardContent className="p-8 text-center">
              <Lock className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-slate-900 mb-2">Edit Access Expired</h2>
              <p className="text-slate-600 mb-2">The 7-day edit window for <strong>{calculator.business_name}</strong> has ended.</p>
              <p className="text-sm text-slate-500 mb-5">Your calculator is still live. Duplicate it to get a fresh 7-day edit period.</p>
              <div className="mb-5 text-left">
                <Label className="text-xs text-slate-500 mb-1 block">Current Calculator URL</Label>
                <UrlRow url={calcUrl} />
              </div>
              {duplicateResult ? (
                <div className="bg-green-50 border border-green-200 rounded-xl p-5 text-left space-y-3">
                  <h3 className="font-semibold text-green-800">✅ Duplicated Successfully!</h3>
                  <div>
                    <Label className="text-xs text-green-700">New Calculator URL</Label>
                    <UrlRow url={`${origin}/Calculator?slug=${duplicateResult.new_slug}`} />
                  </div>
                  <div>
                    <Label className="text-xs text-green-700">New Edit Link (7 days)</Label>
                    <UrlRow url={`${origin}/EditCalculator?token=${duplicateResult.new_token}`} />
                  </div>
                  <div>
                    <Label className="text-xs text-green-700">New Leads Dashboard</Label>
                    <UrlRow url={`${origin}/Leads?token=${duplicateResult.new_token}`} />
                  </div>
                </div>
              ) : (
                <Button onClick={handleDuplicate} disabled={isDuplicating || calculator.is_duplicated} className="w-full bg-indigo-600 hover:bg-indigo-700">
                  {isDuplicating ? <><Loader2 className="mr-2 w-4 h-4 animate-spin" /> Duplicating...</> : <><RefreshCw className="mr-2 w-4 h-4" /> Duplicate & Get New Edit Period</>}
                </Button>
              )}
              {calculator.is_duplicated && !duplicateResult && (
                <p className="text-sm text-slate-500 mt-3">This calculator has already been duplicated.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const expiryDate = new Date(calculator.token_expires_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900">Edit Calculator</h1>
          <p className="text-slate-500 text-sm mt-1">{calculator.business_name} · Edit access expires {expiryDate}</p>
        </div>

        <div className="flex gap-2 mb-6 flex-wrap">
          <a href={calcUrl} target="_blank" rel="noopener noreferrer">
            <Button size="sm" variant="outline"><ExternalLink className="mr-1.5 w-3.5 h-3.5" /> View Calculator</Button>
          </a>
          <a href={leadsUrl}>
            <Button size="sm" variant="outline">View Leads</Button>
          </a>
        </div>

        <div className="space-y-4">
          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold text-slate-800">Business Details</h3>
              <div>
                <Label>Business Name</Label>
                <Input className="mt-1" value={editData.business_name || ''} onChange={e => set('business_name', e.target.value)} />
              </div>
              <div>
                <Label>Tagline</Label>
                <Input className="mt-1" value={editData.tagline || ''} onChange={e => set('tagline', e.target.value)} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold text-slate-800">Branding</h3>
              <div>
                <Label>Brand Color</Label>
                <div className="flex gap-2 mt-2 flex-wrap items-center">
                  {PRESET_COLORS.map(color => (
                    <button key={color} onClick={() => set('primary_color', color)}
                      className={`w-8 h-8 rounded-full border-2 transition-all ${editData.primary_color === color ? 'border-slate-800 scale-110' : 'border-transparent hover:scale-105'}`}
                      style={{ backgroundColor: color }} />
                  ))}
                  <input type="color" value={editData.primary_color || '#6366f1'} onChange={e => set('primary_color', e.target.value)}
                    className="w-8 h-8 rounded-full border-2 border-slate-300 cursor-pointer p-0.5 bg-transparent" />
                </div>
              </div>
              <div>
                <Label>Logo URL</Label>
                <Input className="mt-1" value={editData.logo_url || ''} onChange={e => set('logo_url', e.target.value)} placeholder="https://..." />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold text-slate-800">Lead Form</h3>
              <div>
                <Label>CTA Button Text</Label>
                <Input className="mt-1" value={editData.cta_button_text || ''} onChange={e => set('cta_button_text', e.target.value)} />
              </div>
              <div>
                <Label>Thank You Message</Label>
                <Textarea className="mt-1" value={editData.lead_thank_you_message || ''} onChange={e => set('lead_thank_you_message', e.target.value)} rows={2} />
              </div>
              <div>
                <Label>Your Email (for lead notifications)</Label>
                <Input className="mt-1" type="email" value={editData.owner_email || ''} onChange={e => set('owner_email', e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </div>

        <Button onClick={handleSave} disabled={isSaving} className="w-full mt-6 bg-indigo-600 hover:bg-indigo-700 h-12">
          {isSaving ? <><Loader2 className="mr-2 w-4 h-4 animate-spin" /> Saving...</> :
            saved ? <><Check className="mr-2 w-4 h-4" /> Saved!</> : 'Save Changes'}
        </Button>
      </div>
    </div>
  );
}