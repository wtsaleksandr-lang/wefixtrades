/**
 * EmbedWizard — bare embed entry point for the QuickQuote wizard.
 *
 * Route: /EmbedWizard
 * Usage: load in an iframe — renders ONLY the widget, no header, no background, no padding.
 *
 * iframe example:
 *   <iframe src="https://yourapp.com/EmbedWizard" style="width:100%;border:none;" />
 */

import React from 'react';
import { base44 } from '@/api/base44Client';
import WizardCard from '../components/wizard/WizardCard';

const onInvoke = async (functionName, payload) => {
  const res = await base44.functions.invoke(functionName, payload);
  return res.data;
};

export default function EmbedWizard() {
  return (
    <div
      style={{
        width: '100%',
        minHeight: 0,
        background: 'transparent',
        padding: 0,
        margin: 0,
        boxSizing: 'border-box',
      }}
    >
      <WizardCard embed onInvoke={onInvoke} />
    </div>
  );
}