import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ExternalLink, Loader2, AlertCircle } from 'lucide-react';
import { getEffectiveTheme } from '@/components/themeUtils';

export default function QuoteHosted() {
  const { slug } = useParams();
  const [searchParams] = useSearchParams();
  const [tool, setTool] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        // Fetch tool by slug
        const tools = await base44.asServiceRole.entities.Calculator.filter({ slug }, '-created_date', 1);
        if (!tools || tools.length === 0) {
          setError('Quote tool not found');
          setLoading(false);
          return;
        }

        const calc = tools[0];
        setTool(calc);

        // Fetch status via function
        const statusResp = await base44.functions.invoke('getToolStatus', { id: calc.id });
        setStatus(statusResp.data);
      } catch (err) {
        setError(err.message || 'Failed to load quote tool');
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
      </div>
    );
  }

  if (error || !tool) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 px-4">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-slate-800 mb-2">Quote Tool Not Found</h1>
          <p className="text-slate-500">{error || 'This quote tool is no longer available.'}</p>
        </div>
      </div>
    );
  }

  const canSubmit = status?.can_submit ?? true;
  const trialExpired = status?.trial_expired || false;
  const trialBanner = trialExpired && !canSubmit ? 'Trial expired — Activate subscription to remove this message.' : null;
  const effectiveTheme = getEffectiveTheme(tool.themeOverrides);

  return (
    <div className="min-h-screen py-8 px-4" style={{ background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)', fontFamily: effectiveTheme.typography.fontFamily }}>
      {/* SEO Meta Tags */}
      <head>
        <title>Instant Quote | {tool.business_name}</title>
        <meta name="description" content={`Get an instant quote from ${tool.business_name}`} />
      </head>

      <div className="max-w-2xl mx-auto">
        {/* Trial Expired Banner — soft enforcement */}
        {trialBanner && (
          <div className="rounded-2xl px-6 py-4 mb-6 text-center" style={{ background: 'rgba(239,68,68,0.05)', borderColor: effectiveTheme.colors.danger, borderWidth: '1px' }}>
            <p className="text-sm font-semibold mb-3" style={{ color: effectiveTheme.colors.danger }}>{trialBanner}</p>
            <a
              href={`/api/billing/checkout?tool_id=${tool.id}`}
              className="inline-block px-5 py-2.5 text-white font-semibold rounded-xl text-sm transition-all active:scale-95 hover:shadow-lg"
              style={{ backgroundColor: effectiveTheme.colors.primary, boxShadow: effectiveTheme.shadows.button }}
            >
              Activate (1 minute)
            </a>
          </div>
        )}

        {/* Header with Trust Elements */}
        <div className="text-center mb-8">
          {tool.logo_url && (
            <img src={tool.logo_url} alt={tool.business_name} className="h-16 mx-auto mb-4 object-contain" />
          )}
          <h1 className="text-3xl font-bold mb-2" style={{ color: effectiveTheme.colors.textPrimary, fontFamily: effectiveTheme.typography.fontFamily }}>{tool.business_name}</h1>
          {tool.tagline && (
            <p className="text-lg mb-4" style={{ color: effectiveTheme.colors.textSecondary, fontFamily: effectiveTheme.typography.fontFamily }}>{tool.tagline}</p>
          )}
          
          {/* Trust Actions: Phone + Website */}
          <div className="flex gap-3 justify-center flex-wrap mt-4">
            {tool.owner_phone && (
              <a
                href={`tel:${tool.owner_phone}`}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition-all"
                style={{
                  backgroundColor: effectiveTheme.colors.primaryLight,
                  color: effectiveTheme.colors.primary,
                  fontFamily: effectiveTheme.typography.fontFamily,
                }}
              >
                📞 {tool.owner_phone}
              </a>
            )}
            {tool.website_url && (
              <a
                href={tool.website_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition-all"
                style={{
                  backgroundColor: effectiveTheme.colors.primaryLight,
                  color: effectiveTheme.colors.primary,
                  fontFamily: effectiveTheme.typography.fontFamily,
                }}
              >
                🌐 Visit Website
              </a>
            )}
          </div>
        </div>

        {/* Calculator Card */}
        <div
          className="rounded-2xl shadow-lg p-8 mb-6"
          style={{
            borderTop: `4px solid ${effectiveTheme.colors.primary}`,
            backgroundColor: effectiveTheme.colors.surface,
            fontFamily: effectiveTheme.typography.fontFamily,
          }}
        >
          <div id="calculator-embed" data-tool-id={tool.id}>
            {/* Calculator widget will render here */}
            <p className="text-center py-8" style={{ color: effectiveTheme.colors.textMuted }}>Loading quote calculator...</p>
          </div>
        </div>



        {/* Footer */}
        {tool.show_powered_by_badge && (
          <div className="text-center text-xs pt-6" style={{ borderTop: `1px solid ${effectiveTheme.colors.border}`, color: effectiveTheme.colors.textMuted, fontFamily: effectiveTheme.typography.fontFamily }}>
            <p>Powered by <span className="font-semibold">QuickQuote</span></p>
          </div>
        )}
      </div>

      {/* Load embed script */}
      <script src="https://quickquote.tools/embed.js" async></script>
    </div>
  );
}