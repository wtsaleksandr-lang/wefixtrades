import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import CalculatorWidget from '../components/calculator/CalculatorWidget';
import { Loader2 } from 'lucide-react';

export default function Calculator() {
  const params = new URLSearchParams(window.location.search);
  const slug = params.get('slug');
  const isEmbed = params.get('embed') === 'true';

  const [calculator, setCalculator] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!slug) { window.location.href = '/Wizard'; return; }
    const load = async () => {
      const res = await base44.functions.invoke('getCalculator', { slug });
      if (res.data?.calculator) {
        setCalculator(res.data.calculator);
        // Fire-and-forget view tracking
        base44.functions.invoke('trackView', { calculator_id: res.data.calculator.id });
      } else {
        setError(res.data?.error || 'Calculator not found.');
      }
      setLoading(false);
    };
    load();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 bg-slate-50">
        <div className="text-center">
          <div className="text-5xl mb-4">😕</div>
          <h2 className="text-xl font-semibold text-slate-800 mb-2">Calculator Not Found</h2>
          <p className="text-slate-500 mb-6">{error}</p>
          <a
            href="/Wizard"
            className="inline-block px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #0284c7 0%, #0ea5e9 100%)' }}
          >
            Create a Calculator →
          </a>
        </div>
      </div>
    );
  }

  return <CalculatorWidget calculator={calculator} isEmbed={isEmbed} />;
}