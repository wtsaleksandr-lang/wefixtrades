/**
 * Wizard page — thin shell around <WizardCard>.
 *
 * To run outside Base44, swap the `onInvoke` function below with your own
 * HTTP fetch call, e.g.:
 *   const onInvoke = (name, payload) =>
 *     fetch(`/api/${name}`, { method: 'POST', body: JSON.stringify(payload) })
 *       .then(r => r.json());
 *
 * Environment variables needed (document in your .env):
 *   VITE_API_BASE_URL — base URL for backend functions (if self-hosting)
 */

import React from 'react';
import { base44 } from '@/api/base44Client';
import { designTokens } from '@/components/designTokens';
import WizardCard from '../components/wizard/WizardCard';

// Adapter: translates WizardCard's generic onInvoke into a Base44 call.
// Replace this function when running outside Base44.
const onInvoke = async (functionName, payload) => {
  const res = await base44.functions.invoke(functionName, payload);
  return res.data;
};

export default function Wizard() {
  // Read ?embed=1 or ?embed=true from the URL
  const isEmbed = ['1', 'true'].includes(
    new URLSearchParams(window.location.search).get('embed')
  );

  if (isEmbed) {
    // Bare card, no outer padding or background — fits cleanly in an iframe/div
    return (
      <div className="w-full">
        <WizardCard embed onInvoke={onInvoke} />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-start"
      style={{
        background: 'linear-gradient(180deg, #E2E8F0 0%, #CBD5E1 100%)',
        paddingTop: '40px',
        paddingBottom: '40px',
        paddingLeft: '24px',
        paddingRight: '24px',
      }}
    >
      {/* Hero header */}
      <div className="text-center mb-6 w-full max-w-[960px] mx-auto">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-800 tracking-tight">Build Your Instant Quote System</h1>
        <p className="mt-2 text-sm text-slate-500">Launch today. Start capturing qualified leads.</p>
      </div>
      <div style={{ width: '100%', maxWidth: '960px', margin: '0 auto', background: 'transparent', border: 'none', outline: 'none', boxShadow: 'none' }}>
                <WizardCard onInvoke={onInvoke} />
              </div>
    </div>
  );
}